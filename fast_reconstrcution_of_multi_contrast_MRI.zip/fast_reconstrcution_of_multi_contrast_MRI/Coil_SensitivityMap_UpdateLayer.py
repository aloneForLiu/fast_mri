import torch
import torch.fft
import torch.nn as nn


class Aclass(nn.Module):
    def __init__(self, device):
        super(Aclass, self).__init__()
        self.device = device
        self.lambd = nn.Parameter(torch.tensor(0.1), requires_grad=True)
        
    def myAtA(self, SensitivityMap, Input_SensitivityMap):
        coilComb = Input_SensitivityMap[0, :, :, :] + self.lambd * SensitivityMap

        return coilComb

    def body(self, p, x, r, rTr, Input_SensitivityMap):
        Ap = self.myAtA(p, Input_SensitivityMap)
        alpha = rTr / (torch.sum(torch.conj(p[0::1, :, :]) * Ap[0::1, :, :], dim=(1, 2))).real
        alpha = alpha.view(alpha.size()[0], 1, 1)
        x = x + alpha * p
        r = r - alpha * Ap
        rTrNew = (torch.sum(torch.conj(r[0::1, :, :]) * r[0::1, :, :], dim=(1, 2))).real
        beta = rTrNew / rTr
        beta = beta.view(alpha.size()[0], 1, 1)
        p = r + beta * p

        return x, r, p, rTrNew

    def forward(self, img_SensitivityMap, Input_SensitivityMap):
        x = torch.zeros_like(img_SensitivityMap)
        i = 0
        r = img_SensitivityMap
        p = img_SensitivityMap
        rTr = torch.sum(torch.conj(r[0::1, :, :]) * r[0::1, :, :], dim=(1, 2)).real
        while i < 10 and torch.mean(rTr) > 1e-10:
            x, r, p, rTr = self.body(p, x, r, rTr, Input_SensitivityMap)
            i = i + 1
        x = x.cuda()
        return x


def Coil_SensitivityMap_UpdateLayer(SensitivityMap, Input_SensitivityMap, device):
    SensitivityMap = torch.squeeze(SensitivityMap, dim=0)
    
    Input_SensitivityMap = torch.squeeze(Input_SensitivityMap, dim=0)
    A = Aclass(device)
    rhs = Input_SensitivityMap[0, :, :, :] + A.lambd * SensitivityMap

    image_SensitivityMap = A(rhs, Input_SensitivityMap)

    image_SensitivityMap = image_SensitivityMap.cuda()

    return image_SensitivityMap
