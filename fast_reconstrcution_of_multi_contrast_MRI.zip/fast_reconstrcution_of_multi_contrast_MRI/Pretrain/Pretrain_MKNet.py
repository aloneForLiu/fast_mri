import yaml
from types import SimpleNamespace
import logging


import torch
from tqdm import tqdm
from K_space.Mask_KspaceNet import Mask_KspaceNet
from pprint import pprint
# from generator_model import WNet
from Data.dataset import MRIDataset
from Loss import netLoss
from torch.utils.data import DataLoader
from modelsize import modelsize


def train(args):
    # Init Generator network
    P_model = Mask_KspaceNet(in_channels1=4 * args.channel_for_1, in_channels2=4 * args.channel_for_2)
    size_P = modelsize(P_model)
    P_optimizer = torch.optim.Adam(P_model.parameters(), lr=args.lr, betas=(0.5, 0.999))
    G_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(P_optimizer, 'min', patience=27)

    P_model.to(device=args.device)

    # Init Dataloaders
    if args.dataset == 'MRI':
        train_dataset = MRIDataset(args, t_num=208, mode=0)

    else:
        logging.error("Data type not supported")
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False,
                              num_workers=args.train_num_workers, pin_memory=True)

    loss = netLoss(args)
    for epoch in range(0, 400):
        P_model.train()
        progress = 0
        with tqdm(desc=f'Epoch {epoch + 1}/{400}', unit=' imgs') as pbar:  # 创建一个进度条
            for batch in train_loader:
                target_Kspace = batch['target_Kspace'].to(device=args.device, dtype=torch.float32)
                MASK = batch['MASK'].to(device=args.device, dtype=torch.float32)

                _, _, _, _, _, _, _, _, M10 = P_model(target_Kspace, MASK)
                k_loss = loss.k_space_loss(M10, target_Kspace, MASK)
                P_optimizer.zero_grad()
                k_loss.backward()
                P_optimizer.step()
                progress += 80 * target_Kspace.shape[0] / len(train_dataset)
                pbar.set_postfix(**{'k_loss': k_loss.item(), 'lr_P': P_optimizer.state_dict()['param_groups'][0]['lr']})
                pbar.update(target_Kspace.shape[0])  # current batch size
        G_scheduler.step(k_loss)
    torch.save(P_model.state_dict(), args.output_dir + f'Pretrain_MKNet.pth')

def get_args():
    with open('../config.yaml') as f:
        data = yaml.load(f, Loader=yaml.FullLoader)   #python通过open方式读取文件数据，再通过load函数将数据转化为列表或字典
        #yaml 5.1之前的版本，原来的写法：yaml.load(file)yaml 5.1之后的版本，新的写法：yaml.load(file,Loader=yaml.FullLoader)
    args = SimpleNamespace(**data)   ## 这里的**不可以少,表示命名关键字参数   使用.运算符访问字典

    pprint(data) #pprint函数时pprint模块下方法，是一种标准、格式化输出方式。
    return args

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    args = get_args()
    # Set device and GPU (currently only single GPU training is supported
    logging.info(f'Using device {args.device}')

    train(args)









