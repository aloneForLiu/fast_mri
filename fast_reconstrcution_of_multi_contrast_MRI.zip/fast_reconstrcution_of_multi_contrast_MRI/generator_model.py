""" Full assembly of the parts to form the complete network """
from Image.TNet import T_S_TransformerIR
from K_space.K_spaceNet import *
import torch as torch
from DataConsistencyLayer import *
from Coil_SensitivityMap_UpdateLayer import *
from Mask_Pattern.memc_loupe import Memc_LOUPE
from Parameter_mapping import *
from Image.ImageNet import *
import os
import yaml
from types import SimpleNamespace
import logging
import nibabel as nib
import sys
import shutil

class WNet(nn.Module):
    def weights_init(self, m):
        classname = m.__class__.__name__
        if classname.find('Conv3d') != -1:
            nn.init.normal_(m.weight, 0.0, 0.02)
        elif classname.find('BatchNorm') != -1:
            nn.init.normal_(m.weight, 1.0, 0.02)
            nn.init.zeros_(m.bias)

    def __init__(self, args):
        super(WNet, self).__init__()

        self.args = args
        self.bilinear = args.bilinear
        self.batch_size = args.batch_size
        self.device = args.device
        self.args.device = args.device
        self.encode_1 = args.channel_for_1
        self.noise_val = args.noise_val

        self.Memc_LOUPE_Model = Memc_LOUPE(input_shape=[1, 224, 256], slope=5, sample_slope=40, device=self.device, sparsity=0.125, noise_val=self.noise_val)

        self.kspace_Unet = K_spaceNet(n_channels_in=24, n_channels_out=24, bilinear=self.bilinear).apply(self.weights_init)

        self.img_UNet = T_S_TransformerIR(in_chans=2, input_resolution0=[12, 112, 128], input_resolution1=[16, 56, 64], embed_dim=48, depths=[4], num_heads=[6], window_size=8)

    def forward(self, kspace_mc, Mask, epoch, option):
        
        last_tensor_mask, Kspace, Input_I, SensitivityMap, image_mc = self.Memc_LOUPE_Model(kspace_mc, option, Mask)

        # K-cnn1
        Kspace = Kspace.view(-1, kspace_mc.size()[1], kspace_mc.size()[3], kspace_mc.size()[4])
        rec_Kspace1 = self.kspace_Unet(Kspace)
        rec_Kspace1 = rec_Kspace1.view(-1, 2, int(kspace_mc.size()[1] / 2), kspace_mc.size()[3], kspace_mc.size()[4])

        DC_rec_img1 = DataConsistencyLayermethod_kspace(rec_Kspace1, self.device)

        # Image-transformer1
        refine_Img1, _, _ = self.img_UNet(DC_rec_img1)
        rec_img1 = torch.tanh_(refine_Img1)
        ima_rai1 = rec_img1[:, 0, :, :, :] + 1j * rec_img1[:, 1, :, :, :]
        ima_rai1 = ima_rai1.view(SensitivityMap.size()[0], 1, SensitivityMap.size()[2], SensitivityMap.size()[3])
        sensiti_img1 = ima_rai1 * SensitivityMap
        image_Net1 = torch.mean(sensiti_img1, dim=0).view(1, kspace_mc.size()[2], kspace_mc.size()[3], kspace_mc.size()[4])
        imge_Net_realAndimag1 = torch.cat([image_Net1.real, image_Net1.imag], dim=1)
        # get coil image form U-Net
        image_Net_out1 = self.Memc_LOUPE_Model.SensitivityMapNet(imge_Net_realAndimag1)
        image_Net_out_real1 = image_Net_out1[:, 0:64, :, :]
        image_Net_out_imag1 = image_Net_out1[:, 64:128, :, :]
        image_Net_out_coil1 = image_Net_out_real1 + 1j * image_Net_out_imag1
        combine_image_out1 = torch.sqrt(torch.sum(torch.square(torch.abs(image_Net_out_coil1[0, :, :, :])), dim=0))
        # Sensitivity Map
        SensitivityMap_new1 = image_Net_out_coil1 / (combine_image_out1.view(1, 1, kspace_mc.size()[3], kspace_mc.size()[4]))
        SensitivityMap_new1 = Coil_SensitivityMap_UpdateLayer(SensitivityMap_new1, SensitivityMap, option)
        SensitivityMap_new1 = SensitivityMap_new1.repeat(12, 1, 1, 1)
        Input_I_new1 = torch.sum(image_mc[0::1, :, :, :] * SensitivityMap_new1.conj(), dim=1)

        DC_rec_Kspace1 = DataConsistencyLayermethod_image(rec_img1, self.device, last_tensor_mask, SensitivityMap_new1, Input_I_new1, option)

        # K-cnn2
        DC_rec_Kspace1 = DC_rec_Kspace1.view(-1, kspace_mc.size()[1], kspace_mc.size()[3], kspace_mc.size()[4])

        rec_Kspace2 = self.kspace_Unet(DC_rec_Kspace1)
        rec_Kspace2 = rec_Kspace2.view(-1, 2, int(kspace_mc.size()[1] / 2), kspace_mc.size()[3], kspace_mc.size()[4])

        DC_rec_img2 = DataConsistencyLayermethod_kspace(rec_Kspace2, self.device)

        # Image-transformer2
        refine_Img2, _, _ = self.img_UNet(DC_rec_img2)
        rec_img2 = torch.tanh_(refine_Img2)

        ima_rai2 = rec_img2[:, 0, :, :, :] + 1j * rec_img2[:, 1, :, :, :]
        ima_rai2 = ima_rai2.view(SensitivityMap.size()[0], 1, SensitivityMap.size()[2], SensitivityMap.size()[3])
        sensiti_img2 = ima_rai2 * SensitivityMap_new1
        image_Net2 = torch.mean(sensiti_img2, dim=0).view(1, kspace_mc.size()[2], kspace_mc.size()[3], kspace_mc.size()[4])
        imge_Net_realAndimag2 = torch.cat([image_Net2.real, image_Net2.imag], dim=1)
        # get coil image form U-Net
        image_Net_out2 = self.Memc_LOUPE_Model.SensitivityMapNet(imge_Net_realAndimag2)
        image_Net_out_real2 = image_Net_out2[:, 0:64, :, :]
        image_Net_out_imag2 = image_Net_out2[:, 64:128, :, :]
        image_Net_out_coil2 = image_Net_out_real2 + 1j * image_Net_out_imag2
        combine_image_out2 = torch.sqrt(torch.sum(torch.square(torch.abs(image_Net_out_coil2[0, :, :, :])), dim=0))
        # Sensitivity Map
        SensitivityMap_new2 = image_Net_out_coil2 / (combine_image_out2.view(1, 1, kspace_mc.size()[3], kspace_mc.size()[4]))
        SensitivityMap_new2 = Coil_SensitivityMap_UpdateLayer(SensitivityMap_new2, SensitivityMap, option)
        SensitivityMap_new2 = SensitivityMap_new2.repeat(12, 1, 1, 1)
        Input_I_new2 = torch.sum(image_mc[0::1, :, :, :] * SensitivityMap_new2.conj(), dim=1)

        DC_rec_Kspace2 = DataConsistencyLayermethod_image(rec_img2, self.device, last_tensor_mask, SensitivityMap_new2, Input_I_new2, option)

        # K-cnn3
        DC_rec_Kspace2 = DC_rec_Kspace2.view(-1, kspace_mc.size()[1], kspace_mc.size()[3], kspace_mc.size()[4])
        rec_Kspace3 = self.kspace_Unet(DC_rec_Kspace2)
        rec_Kspace3 = rec_Kspace3.view(-1, 2, int(kspace_mc.size()[1] / 2), kspace_mc.size()[3], kspace_mc.size()[4])

        DC_rec_img3 = DataConsistencyLayermethod_kspace(rec_Kspace3, self.device)

        # Image-transformer3
        refine_Img3, _, _ = self.img_UNet(DC_rec_img3)
        rec_img3 = torch.tanh_(refine_Img3)

        ima_rai3 = rec_img3[:, 0, :, :, :] + 1j * rec_img3[:, 1, :, :, :]
        ima_rai3 = ima_rai3.view(SensitivityMap.size()[0], 1, SensitivityMap.size()[2], SensitivityMap.size()[3])
        sensiti_img3 = ima_rai3 * SensitivityMap_new2
        image_Net3 = torch.mean(sensiti_img3, dim=0).view(1, kspace_mc.size()[2], kspace_mc.size()[3], kspace_mc.size()[4])
        imge_Net_realAndimag3 = torch.cat([image_Net3.real, image_Net3.imag], dim=1)
        # get coil image form U-Net
        image_Net_out3 = self.Memc_LOUPE_Model.SensitivityMapNet(imge_Net_realAndimag3)
        image_Net_out_real3 = image_Net_out3[:, 0:64, :, :]
        image_Net_out_imag3 = image_Net_out3[:, 64:128, :, :]
        image_Net_out_coil3 = image_Net_out_real3 + 1j * image_Net_out_imag3
        combine_image_out3 = torch.sqrt(torch.sum(torch.square(torch.abs(image_Net_out_coil3[0, :, :, :])), dim=0))
        # Sensitivity Map
        SensitivityMap_new3 = image_Net_out_coil3 / (combine_image_out3.view(1, 1, kspace_mc.size()[3], kspace_mc.size()[4]))
        SensitivityMap_new3 = Coil_SensitivityMap_UpdateLayer(SensitivityMap_new3, SensitivityMap, option)
        SensitivityMap_new3 = SensitivityMap_new3.repeat(12, 1, 1, 1)
        Input_I_new3 = torch.sum(image_mc[0::1, :, :, :] * SensitivityMap_new3.conj(), dim=1)

        DC_rec_Kspace3 = DataConsistencyLayermethod_image(rec_img3, self.device, last_tensor_mask, SensitivityMap_new3, Input_I_new3, option)

        # K-cnn4
        DC_rec_Kspace3 = DC_rec_Kspace3.view(-1, kspace_mc.size()[1], kspace_mc.size()[3], kspace_mc.size()[4])
        rec_Kspace4 = self.kspace_Unet(DC_rec_Kspace3)
        rec_Kspace4 = rec_Kspace4.view(-1, 2, int(kspace_mc.size()[1] / 2), kspace_mc.size()[3], kspace_mc.size()[4])

        DC_rec_img4 = DataConsistencyLayermethod_kspace(rec_Kspace4, self.device)

        # Image-transformer4
        refine_Img4, _, _ = self.img_UNet(DC_rec_img4)
        rec_img4 = torch.tanh_(refine_Img4)

        ima_rai4 = rec_img4[:, 0, :, :, :] + 1j * rec_img4[:, 1, :, :, :]
        ima_rai4 = ima_rai4.view(SensitivityMap.size()[0], 1, SensitivityMap.size()[2], SensitivityMap.size()[3])
        sensiti_img4 = ima_rai4 * SensitivityMap_new3
        image_Net4 = torch.mean(sensiti_img4, dim=0).view(1, kspace_mc.size()[2], kspace_mc.size()[3], kspace_mc.size()[4])
        imge_Net_realAndimag4 = torch.cat([image_Net4.real, image_Net4.imag], dim=1)
        # get coil image form U-Net
        image_Net_out4 = self.Memc_LOUPE_Model.SensitivityMapNet(imge_Net_realAndimag4)
        image_Net_out_real4 = image_Net_out3[:, 0:64, :, :]
        image_Net_out_imag4 = image_Net_out3[:, 64:128, :, :]
        image_Net_out_coil4 = image_Net_out_real4 + 1j * image_Net_out_imag4
        combine_image_out4 = torch.sqrt(torch.sum(torch.square(torch.abs(image_Net_out_coil4[0, :, :, :])), dim=0))
        # Sensitivity Map
        SensitivityMap_new4 = image_Net_out_coil4 / (combine_image_out4.view(1, 1, kspace_mc.size()[3], kspace_mc.size()[4]))
        SensitivityMap_new4 = Coil_SensitivityMap_UpdateLayer(SensitivityMap_new4, SensitivityMap, option)
        SensitivityMap_new4 = SensitivityMap_new4.repeat(12, 1, 1, 1)
        Input_I_new4 = torch.sum(image_mc[0::1, :, :, :] * SensitivityMap_new4.conj(), dim=1)

        DC_rec_Kspace4 = DataConsistencyLayermethod_image(rec_img4, self.device, last_tensor_mask, SensitivityMap_new4, Input_I_new4, option)

        # K-cnn5
        DC_rec_Kspace4 = DC_rec_Kspace4.view(-1, kspace_mc.size()[1], kspace_mc.size()[3], kspace_mc.size()[4])
        rec_Kspace5 = self.kspace_Unet(DC_rec_Kspace4)
        rec_Kspace5 = rec_Kspace5.view(-1, 2, int(kspace_mc.size()[1] / 2), kspace_mc.size()[3], kspace_mc.size()[4])

        DC_rec_img5 = DataConsistencyLayermethod_kspace(rec_Kspace5, self.device)
        rec_Kspace5 = rec_Kspace5.view(-1, kspace_mc.size()[1], kspace_mc.size()[3], kspace_mc.size()[4])
        # Image-transformer5
        refine_Img5, attn_S, attn_T = self.img_UNet(DC_rec_img5)
        rec_img5 = torch.tanh_(refine_Img5)

        rec_img5 = rec_img5.view(-1, kspace_mc.size()[1], kspace_mc.size()[3], kspace_mc.size()[4])

        return rec_img5, rec_Kspace5, last_tensor_mask, SensitivityMap, attn_S, attn_T, SensitivityMap_new4, SensitivityMap_new3, SensitivityMap_new2, SensitivityMap_new1, SensitivityMap
