import torch
import torch.nn as nn
import torch.nn.functional as F
from SSIM_Loss import SSIM


class netLoss():

    def __init__(self, args, masked_kspace_flag=False):
        self.args = args
        self.masked_kspace_flag = masked_kspace_flag
        self.args.device = args.device

        self.ImL2_weights = args.loss_weights[0]
        self.ImL1_weights = args.loss_weights[1]
        self.KspaceL2_weights = args.loss_weights[2]
        self.ssim_weight = args.loss_weights[3]

        self.T2S_ImL2_weights = args.T2S_loss_weights[0]
        self.T2S_ImL1_weights = args.T2S_loss_weights[1]
        self.T2S_ssim_weight = args.T2S_loss_weights[2]

        self.PDM_ImL2_weights = args.PDM_loss_weights[0]
        self.PDM_ImL1_weights = args.PDM_loss_weights[1]
        self.PDM_ssim_weight = args.PDM_loss_weights[2]

        self.T1M_ImL2_weights = args.T1M_loss_weights[0]
        self.T1M_ImL1_weights = args.T1M_loss_weights[1]
        self.T1M_ssim_weight = args.T1M_loss_weights[2]

        self.ImL2Loss = nn.MSELoss()
        self.ImL1Loss = nn.SmoothL1Loss()

        self.AdverLoss = nn.BCEWithLogitsLoss()  # BCEWithLogitsLoss()自带sigmoid步骤
        if self.masked_kspace_flag:
            self.KspaceL2Loss = nn.MSELoss(reduction='sum')  #reduction='sum'输出将被求和
        else:
            self.KspaceL2Loss = nn.MSELoss()

    def img_space_loss(self,pred_Im, tar_Im):
        return self.ImL1Loss(pred_Im, tar_Im), self.ImL2Loss(pred_Im, tar_Im)

    def SSIM_loss(self, pred_Im, tar_Im):
        ssim = SSIM(device=self.args.device)
        ssim_loss = ssim(pred_Im, tar_Im)
        return ssim_loss

    def SSIM_loss_para(self, pred_Im, tar_Im):
        ssim = SSIM(device=self.args.device)
        ssim_loss = ssim(pred_Im, tar_Im)
        return ssim_loss

    def k_space_loss(self, pred_K, tar_K):

        return self.KspaceL2Loss(pred_K, tar_K)

    def gen_adver_loss(self, D_fake):
        real_ = torch.tensor(1.0).expand_as(D_fake).cuda()   #tensor_1.expand(size)：把tensor_1扩展成size的形状 tensor_1.expand_as(tensor_2) ：把tensor_1扩展成和tensor_2一样的形状
        return self.AdverLoss(D_fake, real_)

    def disc_adver_loss(self, D_real, D_fake):
        real_ = torch.tensor(1.0).expand_as(D_real).cuda()
        fake_ = torch.tensor(0.0).expand_as(D_fake).cuda()
        real_loss = self.AdverLoss(D_real,real_)
        fake_loss = self.AdverLoss(D_fake,fake_)
        return real_loss, fake_loss

    def calc_gen_loss(self, pred_Im, pred_k, tar_Im, tark):
        ImL1,ImL2 = self.img_space_loss(pred_Im, tar_Im)
        K_spaceL2 = self.k_space_loss(pred_k, tark)
        ssim = self.SSIM_loss(pred_Im, tar_Im)
        fullLoss = self.ImL2_weights*ImL2 + self.ImL1_weights*ImL1 + K_spaceL2 * self.KspaceL2_weights + self.ssim_weight*(1 - ssim)
        return fullLoss, ImL2, ImL1, K_spaceL2, 1 - ssim

    def calc_disc_loss(self,D_real,D_fake):
        real_loss,fake_loss = self.disc_adver_loss(D_real,D_fake)
        return real_loss, fake_loss, 0.5*(real_loss + fake_loss)

    def calc_T2S_loss(self, pred_T2S, tar_T2S):
        T2S_loss = self.ImL2Loss(pred_T2S, tar_T2S) * self.T2S_ImL2_weights + (1 - self.SSIM_loss_para(pred_T2S, tar_T2S)) * self.T2S_ssim_weight + self.ImL1Loss(pred_T2S, tar_T2S) * self.T2S_ImL1_weights
        return T2S_loss, self.ImL2Loss(pred_T2S, tar_T2S)

    def calc_PDM_loss(self, pred_PDM, tar_PDM):
        PDM_loss = self.ImL2Loss(pred_PDM, tar_PDM) * self.PDM_ImL2_weights + (1 - self.SSIM_loss_para(pred_PDM, tar_PDM)) * self.PDM_ssim_weight + self.ImL1Loss(pred_PDM, tar_PDM) * self.PDM_ImL1_weights
        return PDM_loss,  self.ImL2Loss(pred_PDM, tar_PDM)

    def calc_T1M_loss(self, pred_T1M, tar_T1M):
        T1M_loss = self.ImL2Loss(pred_T1M, tar_T1M) * self.T1M_ImL2_weights + (1 - self.SSIM_loss_para(pred_T1M, tar_T1M)) * self.T1M_ssim_weight + self.ImL1Loss(pred_T1M, tar_T1M) * self.T1M_ImL1_weights
        return T1M_loss, self.ImL2Loss(pred_T1M, tar_T1M)

    def GDL_loss(self, pred_Im, tar_Im, alpha):

        batch_size = pred_Im.size()[0]
        filter_x = torch.zeros([1, pred_Im.size()[1], 2, 1]).cuda()
        filter_x[:, :, 0, :], filter_x[:, :, 1, :] = -1, 1
        filter_y = torch.zeros([1,pred_Im.size()[1], 1, 2]).cuda()
        filter_y[:, :, :, 0], filter_y[:, :, :, 1] = -1, 1

        X_dx = torch.abs(F.conv2d(pred_Im, filter_x, stride=1, padding=[0, 0]))
        Y_dx = torch.abs(F.conv2d(tar_Im, filter_x, stride=1, padding=[0, 0]))
        X_dy = torch.abs(F.conv2d(pred_Im, filter_y, stride=1, padding=[0, 0]))
        Y_dy = torch.abs(F.conv2d(tar_Im, filter_y, stride=1, padding=[0, 0]))
        loss_gdl = torch.sum(torch.abs(X_dx - Y_dx) ** alpha) + torch.sum(torch.abs(X_dy - Y_dy) ** alpha)
        loss = loss_gdl / batch_size
        loss = loss / (pred_Im.size()[1] / 2)

        return loss

def set_grad(network, requires_grad):
        for param in network.parameters():
            param.requires_grad = requires_grad


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True


