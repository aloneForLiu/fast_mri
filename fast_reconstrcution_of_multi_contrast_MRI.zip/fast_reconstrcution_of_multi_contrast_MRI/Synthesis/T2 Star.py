import numpy as np
import nibabel as nib
import os as os
import matplotlib.pyplot as plt
from scipy.optimize import leastsq
from skimage.metrics import structural_similarity
from skimage.metrics import peak_signal_noise_ratio, normalized_root_mse
import nibabel as nib

delta_TE = 3.27
image = '/home/liuyx/fast reconstruction of multi-contrast MRI/get_vd_mask/5/output/DCUNET/ZERO2/'
Ground_truth = '/home/liuyx/fast reconstruction of multi-contrast MRI/get_vd_mask/5/T2S_dicom_GT/'

us_vol_data = np.zeros([16, 192, 224], dtype=complex)
us_vol_data2 = np.zeros([16, 192, 224], dtype=complex)

T2_Star1 = np.zeros([192, 224])
T2_Star2 = np.zeros([192, 224])
eps = 1e-8

Xi = np.zeros([7, 256, 256], dtype=complex)
Yi = np.zeros([7, 256, 256], dtype=complex)
raw_affine = [[1, 0, 0, -122.7],
                  [0, 1, 0, -104.2],
                  [0, 0, 2, -65.31],
                  [0, 0, 0, 1]]
#  需要拟合的函数func :指定函数的形状
def func(p, x):
    k = p
    return k * x

#  偏差函数：x,y都是列表:这里的x,y更上面的Xi,Yi中是一一对应的
def error(p, x, y):
    return func(p, x) - y

#  k的初始值,可以任意设定,经过几次试验,发现p0的值会影响cost的值
p0 = 0.1

for i in range(8):
    src_us_file = os.path.join(image, str(i) + '_' + str(20) + 'Rec.nii.gz')
    # src_us_file = os.path.join(Ground_truth, str(i + 1) + '_' + str(40) + '.nii.gz')
    src_us_file2 = os.path.join(image, str(i + 8) + '_' + str(20) + 'Rec.nii.gz')
    src_us_vol = nib.load(src_us_file)
    us_vol_data[i] = src_us_vol.get_fdata()
    src_us_vol2 = nib.load(src_us_file2)
    us_vol_data2[i] = src_us_vol2.get_fdata()

us_vol_data[us_vol_data < 0.08] = 0 + 0j
us_vol_data2[us_vol_data2 < 0.08] = 0 + 0j

for i in range(192):
    for j in range(224):
        Xi = np.array([us_vol_data[0, i, j], us_vol_data[1, i, j], us_vol_data[2, i, j], us_vol_data[3, i, j], us_vol_data[4, i, j], us_vol_data[5, i, j], us_vol_data[6, i, j]])
        Yi = np.array([us_vol_data[1, i, j], us_vol_data[2, i, j], us_vol_data[3, i, j], us_vol_data[4, i, j], us_vol_data[5, i, j], us_vol_data[6, i, j], us_vol_data[7, i, j]])

        Para = leastsq(error, p0, args=(np.abs(Xi), np.abs(Yi)))
        # print(Para)
        T2_Star1[i, j] = - delta_TE / np.minimum(np.log(np.abs(Para[0]) + eps), - eps)

for i in range(192):
    for j in range(224):
        Xi = np.array([us_vol_data2[0, i, j], us_vol_data2[1, i, j], us_vol_data2[2, i, j], us_vol_data2[3, i, j], us_vol_data2[4, i, j], us_vol_data2[5, i, j], us_vol_data2[6, i, j]])
        Yi = np.array([us_vol_data2[1, i, j], us_vol_data2[2, i, j], us_vol_data2[3, i, j], us_vol_data2[4, i, j], us_vol_data2[5, i, j], us_vol_data2[6, i, j], us_vol_data2[7, i, j]])

        Para = leastsq(error, p0, args=(np.abs(Xi), np.abs(Yi)))
        # print(Para)
        T2_Star2[i, j] = - delta_TE / np.minimum(np.log(np.abs(Para[0]) + eps), - eps)
#
T2_Star = (np.abs(T2_Star1) + np.abs(T2_Star2)) / 2
print(np.max(T2_Star))
T2_Star[T2_Star < 0] = np.abs(T2_Star[T2_Star < 0])
T2_Star[T2_Star > 2000] = 0
T2_Star = (T2_Star - np.min(T2_Star)) / (np.max(T2_Star) - np.min(T2_Star))

# plt.imshow(T2_Star.transpose(1, 0), cmap='gray',    origin='lower')
# plt.show()

def _error(actual: np.ndarray, predicted: np.ndarray):
    """ Simple error """
    return actual - predicted


def mse(actual: np.ndarray, predicted: np.ndarray):
    """ Mean Squared Error """
    return np.mean(np.square(_error(actual, predicted)))


def rmse(actual: np.ndarray, predicted: np.ndarray):
    """ Root Mean Squared Error """
    return np.sqrt(mse(actual, predicted))


def nrmse_matrix(actual: np.ndarray, predicted: np.ndarray):
    """ Normalized Root Mean Squared Error """
    return rmse(actual, predicted) / (actual.max() - actual.min())

g_path = os.path.join(Ground_truth, '292_dicom_GT.nii.gz')
g_imagenii = nib.load(g_path)
g_image = g_imagenii.get_fdata()
# g_image = (g_image - np.min(g_image)) / (np.max(g_image) - np.min(g_image))
ssim = structural_similarity(g_image, T2_Star)
psnr = peak_signal_noise_ratio(g_image, T2_Star, data_range=1)
nrmse = nrmse_matrix(g_image, T2_Star)
print('ssim:' + str(ssim) + '|' + 'psnr:' + str(psnr) + '|' + 'nrmse:' + str(nrmse))

T2_Star = nib.Nifti1Image(T2_Star, raw_affine)
nib.save(T2_Star, '/home/liuyx/' + 'Rec_T2S2' + '.nii.gz')


