from skimage.metrics import structural_similarity
from skimage.metrics import peak_signal_noise_ratio, normalized_root_mse
import nibabel as nib
import os as os

Ground_truth = r'C:/Users/test/Desktop/parameter/get_vd_mask/5/PDW/Ground truth/'
image = r'C:/Users/test/Desktop/parameter/get_vd_mask/5/PDW/Zero-filled/'
raw_affine = [[0.8447, 0, 0, -108.3],
                  [0, 0.8447, 0, -106.1],
                  [0, 0, 2, -43.59],
                  [0, 0, 0, 1]]

g_path = os.path.join(Ground_truth, 'Rec.nii.gz')
g_imagenii = nib.load(g_path)
g_image = g_imagenii.get_fdata()


i_path = os.path.join(image, 'Rec.nii.gz')
i_imagenii = nib.load(i_path)
i_image = i_imagenii.get_fdata()

ssim = structural_similarity(g_image, i_image)
psnr = peak_signal_noise_ratio(g_image, i_image, data_range=1)
nrmse = normalized_root_mse(g_image, i_image)
print('ssim:' + str(ssim) + '|' + 'psnr:' + str(psnr) + '|' + 'nrmse:' + str(nrmse))

Decrease = g_image - i_image
Decrease_img = nib.Nifti1Image(Decrease, raw_affine)
Decrease_img.to_filename(os.path.join(image, 'Dec' + '.nii.gz'))