import os as os

import numpy as np
import nibabel as nib

us_vol_data = np.zeros([6, 256, 256], dtype=complex)
PDWgt = np.zeros([6, 256, 256])
T1Wgt = np.zeros([6, 256, 256])
case_path = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/output/NoMKNet_Attention/ZERO/'
Ground_truth = r'D:/download/data/UID_245527714669115/'
Zero_filled = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/output/Zero-filled/ZERO/'
PDW = np.zeros([256, 256])
T1W = np.zeros([256, 256])
raw_affine = [[0.8447, 0, 0, -108.3],
                    [0, 0.8447, 0, -106.1],
                    [0, 0, 2, -43.59],
                    [0, 0, 0, 1]]

#    PDW
for i in range(6):
    src_us_file = os.path.join(Zero_filled, str(i) + '_' + str(20) + 'Rec.nii.gz')
    # src_us_file = os.path.join(Ground_truth, str(i + 1) + '_' + str(40) + '.nii.gz')
    src_us_vol = nib.load(src_us_file)
    us_vol_data[i] = src_us_vol.get_fdata()
# # #     # src_us_file = os.path.join(Ground_truth, str(i+1) + '_' + str(40) + '.npy')
# # #     # gt = np.load(src_us_file)
# # #     # us_vol_data[i, :, :] = gt[0, :, :] + 1j * gt[1, :, :]
    PDWgt[i, :, :] = np.abs(us_vol_data[i, :, :])
    PDW = PDW + PDWgt[i]
print(PDW)
PDW = PDW / 6
PDW = nib.Nifti1Image(PDW, raw_affine)
nib.save(PDW,  'C:/Users/test/Desktop/parameter/get_vd_mask/5/PDW/Zero-filled/' + 'Rec' + '.nii.gz')

# #   T1W
for i in range(6):
    src_us_file = os.path.join(Zero_filled, str(i+6) + '_' + str(20) + 'Rec.nii.gz')
    # src_us_file = os.path.join(Ground_truth, str(i + 7) + '_' + str(40) + '.nii.gz')
    src_us_vol = nib.load(src_us_file)
    us_vol_data[i] = src_us_vol.get_fdata()
    T1Wgt[i, :, :] = np.abs(us_vol_data[i, :, :])
    T1W = T1W + T1Wgt[i]
# # #     # src_us_file = os.path.join(Ground_truth, str(i+9) + '_' + str(40) + '.npy')
# # #     # gt = np.load(src_us_file)
# # #     # us_vol_data[i, :, :] = gt[0, :, :] + 1j * gt[1, :, :]

print(T1W)
T1W = T1W / 6
T1W = nib.Nifti1Image(T1W, raw_affine)
nib.save(T1W, 'C:/Users/test/Desktop/parameter/get_vd_mask/5/T1W/Zero-filled/' + 'Rec' + '.nii.gz')
