import os as os
import matplotlib.pyplot as plt
import numpy as np
import nibabel as nib
import cv2 as cv
import torch as torch
import torch.nn as nn
import numpy as np
from scipy import stats
from scipy.stats import spearmanr
from Mask_Pattern.common_masks import *
import math
eps = 1e-8

# case_path = r'D:/download/fast reconstruction of multi-contrast MRI//get_vd_mask/5/output/DCUNET/ZERO/'
#
# os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
#
# src_us_file = os.path.join(case_path, str(11) + '_' + str(32) + 'Rec.nii.gz')
# src_us_vol = nib.load(src_us_file)
# src_us_vol = src_us_vol.get_fdata()
# plt.imshow(src_us_vol, cmap='gray')
# plt.show()
# img_sos_allksp = np.fft.fftshift(np.fft.fft2(src_us_vol))  # 变为k空间
# a_fshift = np.log(np.abs(img_sos_allksp) + eps)  # 取振幅
# ph_fshift = np.angle(img_sos_allksp)  # 取相位
# k_real = np.exp(a_fshift) * np.cos(ph_fshift)  # 整合复数的实部
# k_imag = np.exp(a_fshift) * np.sin(ph_fshift)  # 整合复数的虚部
# k1 = 20 * np.log(cv.magnitude(k_real, k_imag))
# plt.imshow(k1, cmap='gray')
# plt.show()


# a = torch.rand(2,3)
# print(a)
# b = a.unsqueeze(1)
# print(b)
# c = a.unsqueeze(2)
# print(c)
# print(b-c)
# attn_mask = (b-c).masked_fill((b-c) != 0, float(-100.0)).masked_fill((b-c) == 0, float(0.0))
# print(attn_mask)
#
# a = [[1+1j, 1+1j], [2+1j, 1+1j]]
# b = np.fft.fftshift(np.fft.fft2(a))
# print(b)
# c = np.fft.ifft2(np.fft.ifftshift(b))
# print(c==a)
# # a_fshift = np.log(np.abs(b) + eps)  # 取振幅
# # ph_fshift = np.angle(a)  # 取相位
# # k_real = np.exp(a_fshift) * np.cos(ph_fshift)  # 整合复数的实部
# # k_imag = np.exp(a_fshift) * np.sin(ph_fshift)  # 整合复数的虚部
# # print(np.fft.ifft2(k_real + 1j * k_imag))

# a = np.random.uniform(size=[2, 2])
# print(a)
# # b = a.view(-1, 256, 256)
# # print(b.size())
# image_mc = np.fft.fftshift(np.fft.fft2(a))
# print(image_mc)
# df = np.fft.ifft2(np.fft.ifftshift(image_mc))
# print(df)
# print(a==df)
# # image_mc = image_mc.view(16, 32, 256, 256)
# # c = b.view(16, 32, 256, 256)
# # print(image_mc)
# # print(a==image_mc)
#
# a = [[3 + 4j, 6+7j, 2+2j], [2+3j, 8+9j, 5+5j], [3+3j, 9+9j, 7+5j]]
# print(type(a))
# f = (np.fft.fft2(a))
# d = np.abs(np.fft.ifft2((f)))
# print(d)
# c = np.fft.ifft2(np.fft.ifftshift(f))
# print(c)

# a = np.matrix([[3 + 4j, 6+7j, 2+2j], [2+3j, 8+9j, 5+5j], [3+3j, 9+9j, 7+5j]])
# print(a*a)
# print(np.abs(a)*a)
# print(np.fft.fft2(a*a))
# print(np.fft.fft2(np.abs(a)*a))

# a = torch.tensor(1+1j)
# b = torch.tensor(2+0j)
# c = (torch.abs(a)>torch.abs(b))+0
# print(c)

raw_affine = [[1, 0, 0, -122.7],
              [0, 1, 0, -104.2],
              [0, 0, 2, -65.31],
              [0, 0, 0, 1]]
#
# case_path_gt = r'D:/download/data/UID_Mancheng/'
# case_path_zf = r'D:/download/data/UID_Mancheng/'
#
# src_us_file = os.path.join(case_path_gt, str(12) + '_' + str(35) + '.nii.gz')
# src_us_vol = nib.load(src_us_file)
# src_us_vol = src_us_vol.get_fdata()
#
# src_us_file2 = os.path.join(case_path_zf, '12_Zero_filled.nii.gz')
# src_us_vol2 = nib.load(src_us_file2)
# src_us_vol2 = src_us_vol2.get_fdata()
# decrease = src_us_vol - src_us_vol2
#
# Decrease_img = nib.Nifti1Image(decrease, raw_affine)
# Decrease_img.to_filename(os.path.join(case_path_gt, str(12) + '_' + str(35) + 'Dec' + '.nii.gz'))
# def _error(actual: np.ndarray, predicted: np.ndarray):
#     """ Simple error """
#     return actual - predicted
#
#
# def mse(actual: np.ndarray, predicted: np.ndarray):
#     """ Mean Squared Error """
#     return np.mean(np.square(_error(actual, predicted)))
#
#
# def rmse(actual: np.ndarray, predicted: np.ndarray):
#     """ Root Mean Squared Error """
#     return np.sqrt(mse(actual, predicted))
#
#
# def nrmse_matrix(actual: np.ndarray, predicted: np.ndarray):
#     """ Normalized Root Mean Squared Error """
#     return rmse(actual, predicted) / (actual.max() - actual.min())
#
#
# case_path_mask = r'D:/download/data/UID_Mancheng/'
# mc_kspace = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/mc_kspace/'
# src_us_file = os.path.join(case_path_mask, '11_0_0_OPT_Mask.nii.gz')
# src_us_vol = nib.load(src_us_file)
# src_us_vol = src_us_vol.get_fdata()
# # src_us_vol = src_us_vol.reshape(1, 192, 224)
# kspace_mc = os.path.join(mc_kspace, str(292) + '.kspace.npy')
# kspace_mc = np.load(kspace_mc)
# # src_us_vol = cartesian_mask([192, 224], rate=8)
# # rc_us_vol = src_us_vol.reshape(1, 192, 224)
# real = kspace_mc[22, :, :, :] * src_us_vol
# imag = kspace_mc[23, :, :, :] * src_us_vol
# # k1 = 20 * np.log(cv.magnitude(real[0, :, :], imag[0, :, :]))
# # k1 = k1 * src_us_vol
# # plt.imshow(k1.transpose(1, 0), cmap='gray')
# # plt.show()
# image_mc = np.fft.ifft2(real[0::1, :, :] + 1j * imag[0::1, :, :])
# combine_image_out = np.sqrt(np.sum(np.square(np.abs(image_mc)), axis=0))
# Zero_filled = nib.Nifti1Image(combine_image_out, raw_affine)
# Zero_filled.to_filename(os.path.join(case_path_mask, str(12) + '_' + 'Zero_filled' + '.nii.gz'))

# from skimage.metrics import structural_similarity, peak_signal_noise_ratio, normalized_root_mse
# case_path_gt = r'D:/download/data/UID_Mancheng/'
# case_path_zf = r'D:/download/data/UID_Mancheng/'
# g_path = os.path.join(case_path_gt, '1_35.nii.gz')
# g_imagenii = nib.load(g_path)
# g_image = g_imagenii.get_fdata()
#
# i_path = os.path.join(case_path_zf, '1_Zero_filled.nii.gz')
# i_imagenii = nib.load(i_path)
# i_image = i_imagenii.get_fdata()
#
# ssim = structural_similarity(g_image, i_image)
# psnr = peak_signal_noise_ratio(g_image, i_image, data_range=1)
# nrmse = nrmse_matrix(g_image, i_image)
# print('ssim:' + str(ssim) + '|' + 'psnr:' + str(psnr) + '|' + 'nrmse:' + str(nrmse))

# case_path_gt = r'D:/download/data/UID_Mancheng/'
# case_path_zf = r'D:/download/data/UID_Mancheng/'
#
# src_us_file = os.path.join(case_path_gt, 'our1-3.nii.gz')
# src_us_vol = nib.load(src_us_file)
# src_us_vol = src_us_vol.get_fdata()
#
# src_us_file2 = os.path.join(case_path_zf, 'loupe1-3.nii.gz')
# src_us_vol2 = nib.load(src_us_file2)
# src_us_vol2 = src_us_vol2.get_fdata()
#
#
# def cal_p_value(a, b):
#     t3, p3 = stats.ttest_rel(a, b)  # paired t-test
#     if math.isnan(p3):
#         p3 = 0
#     return t3, p3
#
#
# t, p = stats.ttest_rel(src_us_vol, src_us_vol2)
# print(p)

# Mask_output_test = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/output/DCUNET/TWO/Mask/'
# for i in range(16):
#     src_us_file = os.path.join(Mask_output_test, str(i) + '_' + str(0) + '_' + str(0) + '_' + 'OPT_Mask' + '.nii.gz')
#     src_us_vol = nib.load(src_us_file)
#     src_us_vol = src_us_vol.get_fdata()
#     src_us_vol = np.flip(src_us_vol)
#     plt.imshow(src_us_vol.transpose(1, 0), cmap='gray')
#     plt.show()

# import yaml
# from types import SimpleNamespace
# import logging
# import os
# import sys
# import shutil
#
# import torch
# from tqdm import tqdm
# from pprint import pprint
#
# from generator_model import WNet
# from torch.utils.tensorboard import SummaryWriter
# from Data.dataset import MRIDataset
# from Loss import netLoss, set_grad
# from torch.utils.data import DataLoader
# from Parameter_mapping.Parameter_mapping_PDW import PNet
# from Parameter_mapping.Parameter_mapping_T1W import TNet
# from Parameter_mapping.Parameter_mapping_T2S import T2SNet
# from Parameter_mapping.Parameter_mapping_PDM import PDMNet
# from Parameter_mapping.Parameter_mapping_T1M import T1MNet
# from eval import eval_net
# import torch.nn as nn
# import numpy as np
# from modelsize import modelsize
#
# case_path_gt = r'D:/download/data/UID_Mancheng/'
#
# def get_args():
#     with open('D:/download/fast reconstruction of multi-contrast MRI/config.yaml') as f:
#         data = yaml.load(f, Loader=yaml.FullLoader)   #python通过open方式读取文件数据，再通过load函数将数据转化为列表或字典
#         #yaml 5.1之前的版本，原来的写法：yaml.load(file)yaml 5.1之后的版本，新的写法：yaml.load(file,Loader=yaml.FullLoader)
#     args = SimpleNamespace(**data)   ## 这里的**不可以少,表示命名关键字参数   使用.运算符访问字典
#
#     pprint(data) #pprint函数时pprint模块下方法，是一种标准、格式化输出方式。
#     return args
#
#
# args = get_args()
#
# G_model = WNet(args)
# P_model = PNet(args)
# T_model = TNet(args)
# T2S_model = T2SNet(args)
# PDM_model = PDMNet(args)
# T1M_model = T1MNet(args)
# valid_dataset = MRIDataset(args, t_num=40, mode=1)
# val_loader = DataLoader(valid_dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.val_num_workers, pin_memory=True)
# checkpoint = torch.load(case_path_gt + f'CP_epoch.pth', map_location='cuda')  # 从文件中加载一个用torch.save()保存的对象
# loss = netLoss(args)
# G_model.load_state_dict(checkpoint['G_model_state_dict'])
# G_model.to(device=args.device)
#
# P_model.load_state_dict(checkpoint['P_model_state_dict'])
# P_model.to(device=args.device)
#
# T_model.load_state_dict(checkpoint['T_model_state_dict'])
# T_model.to(device=args.device)
#
# T2S_model.load_state_dict(checkpoint['T2S_model_state_dict'])
# T2S_model.to(device=args.device)
#
# PDM_model.load_state_dict(checkpoint['PDM_model_state_dict'])
# PDM_model.to(device=args.device)
#
# T1M_model.load_state_dict(checkpoint['T1M_model_state_dict'])
# T1M_model.to(device=args.device)


# def eval():
#     val_FullLoss, val_ImL2, val_ImL1, val_PSNR, val_SSIM, val_NRMSE, PDW_PSNR, T2S_PSNR, T1W_PSNR, PDM_PSNR, T1M_PSNR, PDW_SSIM, T2S_SSIM, T1W_SSIM, \
#     PDM_SSIM, T1M_SSIM, PDW_NRMSE, T2S_NRMSE, \
#     T1W_NRMSE, PDM_NRMSE, T1M_NRMSE, val_T2S, val_PDM, val_T1M = \
#     eval_net(G_model, P_model, T2S_model, T_model, PDM_model, T1M_model, val_loader, loss, args, 60)
#     print(val_PSNR)
#     print(val_SSIM, val_NRMSE, PDW_PSNR, T2S_PSNR, T1W_PSNR, PDM_PSNR, T1M_PSNR, PDW_SSIM, T2S_SSIM, T1W_SSIM, PDM_SSIM, T1M_SSIM, PDW_NRMSE, T2S_NRMSE, T1W_NRMSE, PDM_NRMSE, T1M_NRMSE, val_T2S, val_PDM, val_T1M)
#
#
# eval()


import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
# 设置
pd.options.display.notebook_repr_html=False  # 表格显示
plt.rcParams['figure.dpi'] = 300  # 图形分辨率
sns.set_theme(style='whitegrid')  # 图形主题

# 加载数据
flights = pd.read_csv(r'D:/download/data/UID_Mancheng/data.csv')
flights.head()

# 长型数据多折线图
ax = sns.lineplot(data=flights, x='Iteration Number', y='PSNR', sizes=10, hue='Data', style='Data', linewidth=3, markers=True)
ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
ax.set_xticklabels([0, 1, 2, 3, 4, 5], fontsize=24)
ax.set_xlabel('Iteration Number', fontsize=24)
y = [24, 28, 32, 36, 40]
# y = [0.82, 0.86, 0.90, 0.94, 0.98]
# y = [0.01, 0.02, 0.03, 0.04, 0.05]
ax.set_yticks(y)
ax.set_yticklabels(y, fontsize=24)
ax.set_ylabel('PSNR', fontsize=24)
ax.set_title('R=8', fontsize=24)
ax.legend(loc='upper right', fontsize=16)
plt.show()

#
# case_path_gt = r'D:/download/data/UID_Mancheng/'
# case_path_zf = r'D:/download/data/UID_Mancheng/'
#
# src_us_file = os.path.join(case_path_gt, str(9) + '_' + str(35) + 'Dec.nii.gz')
# src_us_vol = nib.load(src_us_file)
# src_us_vol = src_us_vol.get_fdata()
#
# font = {'family': 'Times New Roman',
# 'weight' : 'normal',
# 'size'   : 30,
# }
# plt.imshow(np.flip(src_us_vol).transpose(1, 0), alpha=1, interpolation='nearest', cmap='Blues')
# cbar = plt.colorbar()
# plt.show()
# # cbar.set_ticks(np.linspace(0, 100000, 0.3))  # 设置色标刻度范围

