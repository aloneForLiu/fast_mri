import torch as torch
import torch.nn as nn
from Parameter_mapping.MLP import MLP_T1M, MLP_T2SNet
from Parameter_mapping.MLP import Inverse_ParaNet
from Image.ImageNet import ImageNet


class T1MNet(nn.Module):
    def __init__(self, args):
        super(T1MNet, self).__init__()
        self.args = args
        self.batch_size = args.batch_size
        self.args.device = args.device

        self.encode_1 = args.channel_for_1
        self.encode_2 = args.channel_for_2

        self.T1M_Net = MLP_T2SNet(in_channel=4 * self.encode_2, out_channel=96, channel=96)
        # self.T1M_Net = ImageNet(n_channels=4 * self.encode_1, n_classes=1, scale_factor=1)

    def forward(self, T1M_img):

        Output = self.T1M_Net(T1M_img)

        return Output