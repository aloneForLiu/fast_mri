from Parameter_mapping.Parameter_mapping_Net import *
from timm.models.layers import DropPath

class MLP_PDW(nn.Module):

    def __init__(self, in_channel=None, out_channel=None):
        super(MLP_PDW, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.convlast = Convlast(self.out_channel, self.in_channel)
        self.last = Convlast(self.in_channel, 1)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)
            x2 = self.last(x2)
        return x1, x2

class Inverse_ParaNet(nn.Module):

    def __init__(self, in_channel=None, mid_channel=None, out_channel=None):
        super(Inverse_ParaNet, self).__init__()
        self.in_channel = in_channel
        self.mid_channel = mid_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.mid_channel)
        self.convlast = Convlast(self.mid_channel, self.out_channel)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)
        return x1, x2

class MLP_PDM(nn.Module):

    def __init__(self, in_channel=None, out_channel=None):
        super(MLP_PDM, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.convlast = Convlast(self.out_channel, self.in_channel)
        self.last = Convlast(self.in_channel, 1)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)
            x2 = self.last(x2)
        return x1, x2

class MLP_T2S(nn.Module):

    def __init__(self, in_channel=None, out_channel=None):
        super(MLP_T2S, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.convlast = Convlast(self.out_channel, self.in_channel)
        self.last = Convlast(self.in_channel, 1)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)
            x2 = self.last(x2)
        return x1, x2

class MLP_T1W(nn.Module):
    def __init__(self, in_channel=None, out_channel=None):
        super(MLP_T1W, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.convlast = Convlast(self.out_channel, self.in_channel)
        self.last = Convlast(self.in_channel, 1)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)
            x2 = self.last(x2)
        return x1, x2

class MLP_T1M(nn.Module):
    def __init__(self, in_channel=None, out_channel=None):
        super(MLP_T1M, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.convlast = Convlast(self.out_channel, self.in_channel)
        self.last = Convlast(self.in_channel, 1)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)
            x2 = self.last(x2)
        return x1, x2


class MLP_Net(nn.Module):
    def __init__(self, in_channel=None, out_channel=None, channel=None, drop_path=0.,):
        super(MLP_Net, self).__init__()
        self.channel = channel
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.patch_embed1 = PatchEmbed()
        self.layer_nom1 = nn.LayerNorm(self.out_channel)
        self.MLP1 = Mlp(self.out_channel, 2 * self.out_channel)
        self.patch_un_embed1 = PatchUnEmbed(self.out_channel)
        self.drop_path1 = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.patch_embed2 = PatchEmbed()
        self.layer_nom2 = nn.LayerNorm(self.channel)
        self.MLP2 = Mlp(self.channel, 2 * self.channel)
        self.patch_un_embed2 = PatchUnEmbed(self.channel)
        self.drop_path2 = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.convlast = Convlast(self.out_channel, self.in_channel)
        self.last = Convlast(self.in_channel, 1)

    def forward(self, x):
        x = self.convfirst(x)
        x_size = [x.size()[2], x.size()[3]]
        x = self.patch_embed1(x)
        x = self.layer_nom1(x)
        x = self.MLP1(x)
        x = self.drop_path1(x)
        x = self.patch_un_embed1(x, x_size)
        x = self.patch_embed2(x)
        x = self.layer_nom2(x)
        x = self.MLP2(x)
        x = self.drop_path2(x)
        x = self.patch_un_embed2(x, x_size)
        x = self.convlast(x)
        x = self.last(x)
        return x

class MLP_T2SNet(nn.Module):
    def __init__(self, in_channel=None, out_channel=None, channel=None, drop_path=0., ):
        super(MLP_T2SNet, self).__init__()
        self.channel = channel
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.patch_embed1 = PatchEmbed()
        self.layer_nom1 = nn.LayerNorm(self.channel)
        self.MLP1 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed1 = PatchUnEmbed(self.channel)
        self.drop_path1 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.patch_embed2 = PatchEmbed()
        self.layer_nom2 = nn.LayerNorm(self.channel)
        self.MLP2 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed2 = PatchUnEmbed(self.channel)
        self.drop_path2 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.patch_embed3 = PatchEmbed()
        self.layer_nom3 = nn.LayerNorm(self.channel)
        self.MLP3 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed3 = PatchUnEmbed(self.channel)
        self.drop_path3 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.patch_embed4 = PatchEmbed()
        self.layer_nom4 = nn.LayerNorm(self.channel)
        self.MLP4 = Mlp(self.channel, 4 * self.channel)
        self.fc1 = nn.Linear(self.channel, 16)
        self.fc2 = nn.Linear(16, 1)
        self.patch_un_embed4 = PatchUnEmbed(1)
        self.drop_path4 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x):
        x = self.convfirst(x)
        x_size = [x.size()[2], x.size()[3]]
        x = self.patch_embed1(x)
        x = self.layer_nom1(x)
        x = self.MLP1(x)
        x = self.drop_path1(x)
        x = self.patch_un_embed1(x, x_size)

        x = self.patch_embed2(x)
        x = self.layer_nom2(x)
        x = self.MLP2(x)
        x = self.drop_path2(x)
        x = self.patch_un_embed2(x, x_size)

        x = self.patch_embed3(x)
        x = self.layer_nom3(x)
        x = self.MLP3(x)
        x = self.drop_path3(x)
        x = self.patch_un_embed3(x, x_size)

        x = self.patch_embed4(x)
        x = self.layer_nom4(x)
        x = self.MLP4(x)
        x = self.fc1(x)
        x = self.fc2(x)
        x = self.drop_path4(x)
        x = self.patch_un_embed4(x, x_size)

        return x

class MLP_PDMNet(nn.Module):
    def __init__(self, channel=None, drop_path=0., ):
        super(MLP_PDMNet, self).__init__()
        self.channel = channel
        self.patch_embed1 = PatchEmbed()
        self.layer_nom1 = nn.LayerNorm(self.channel)
        self.MLP1 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed1 = PatchUnEmbed(self.channel)
        self.drop_path1 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.patch_embed2 = PatchEmbed()
        self.layer_nom2 = nn.LayerNorm(self.channel)
        self.MLP2 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed2 = PatchUnEmbed(self.channel)
        self.drop_path2 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.patch_embed3 = PatchEmbed()
        self.layer_nom3 = nn.LayerNorm(self.channel)
        self.MLP3 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed3 = PatchUnEmbed(self.channel)
        self.drop_path3 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.patch_embed4 = PatchEmbed()
        self.layer_nom4 = nn.LayerNorm(self.channel)
        self.MLP4 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed4 = PatchUnEmbed(self.channel)
        self.drop_path4 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x):
        x_size = [x.size()[2], x.size()[3]]
        x = self.patch_embed1(x)
        x = self.layer_nom1(x)
        x = self.MLP1(x)
        x = self.drop_path1(x)
        x = self.patch_un_embed1(x, x_size)

        x = self.patch_embed2(x)
        x = self.layer_nom2(x)
        x = self.MLP2(x)
        x = self.drop_path2(x)
        x = self.patch_un_embed2(x, x_size)

        x = self.patch_embed3(x)
        x = self.layer_nom3(x)
        x = self.MLP3(x)
        x = self.drop_path3(x)
        x = self.patch_un_embed3(x, x_size)

        x = self.patch_embed4(x)
        x = self.layer_nom4(x)
        x = self.MLP4(x)
        x = self.drop_path4(x)
        x = self.patch_un_embed4(x, x_size)

        return x

class MLP_T1MNet(nn.Module):
    def __init__(self, channel=None, drop_path=0., ):
        super(MLP_T1MNet, self).__init__()
        self.channel = channel
        self.patch_embed1 = PatchEmbed()
        self.layer_nom1 = nn.LayerNorm(self.channel)
        self.MLP1 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed1 = PatchUnEmbed(self.channel)
        self.drop_path1 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.patch_embed2 = PatchEmbed()
        self.layer_nom2 = nn.LayerNorm(self.channel)
        self.MLP2 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed2 = PatchUnEmbed(self.channel)
        self.drop_path2 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.patch_embed3 = PatchEmbed()
        self.layer_nom3 = nn.LayerNorm(self.channel)
        self.MLP3 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed3 = PatchUnEmbed(self.channel)
        self.drop_path3 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.patch_embed4 = PatchEmbed()
        self.layer_nom4 = nn.LayerNorm(self.channel)
        self.MLP4 = Mlp(self.channel, 4 * self.channel)
        self.patch_un_embed4 = PatchUnEmbed(self.channel)
        self.drop_path4 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x):
        x_size = [x.size()[2], x.size()[3]]
        x = self.patch_embed1(x)
        x = self.layer_nom1(x)
        x = self.MLP1(x)
        x = self.drop_path1(x)
        x = self.patch_un_embed1(x, x_size)

        x = self.patch_embed2(x)
        x = self.layer_nom2(x)
        x = self.MLP2(x)
        x = self.drop_path2(x)
        x = self.patch_un_embed2(x, x_size)

        x = self.patch_embed3(x)
        x = self.layer_nom3(x)
        x = self.MLP3(x)
        x = self.drop_path3(x)
        x = self.patch_un_embed3(x, x_size)

        x = self.patch_embed4(x)
        x = self.layer_nom4(x)
        x = self.MLP4(x)
        x = self.drop_path4(x)
        x = self.patch_un_embed4(x, x_size)

        return x