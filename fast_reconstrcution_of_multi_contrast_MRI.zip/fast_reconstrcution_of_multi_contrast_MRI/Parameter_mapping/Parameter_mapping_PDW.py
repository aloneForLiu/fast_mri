import torch as torch
import torch.nn as nn
from Parameter_mapping.MLP import MLP_PDW, MLP_Net
from Parameter_mapping.MLP import Inverse_ParaNet
from Image.ImageNet import ImageNet


class PNet(nn.Module):
    def __init__(self, args):
        super(PNet, self).__init__()
        self.args = args
        self.batch_size = args.batch_size
        self.args.device = args.device

        self.encode_1 = args.channel_for_1
        self.encode_2 = args.channel_for_2

        # self.PDW_Net = MLP_Net(in_channel=self.encode_1, out_channel=48, channel=48)
        # self.PDW_Net = ImageNet(n_channels=2 * self.encode_1, n_classes=1, scale_factor=1)

    def forward(self, rec_img):
        tot = 0
        PDW_img = torch.zeros((self.batch_size, int(rec_img.size()[1] / 2), rec_img.size()[2], rec_img.size()[3])).to(device=self.args.device, dtype=torch.float32)
        for i in range(int(rec_img.size()[1] / 2)):
            PDW_img[:, i, :, :] = rec_img[:, i, :, :]

        for i in range(int(rec_img.size()[1] / 4)):
            tot = tot + torch.abs(PDW_img[:, 2 * i, :, :] + 1j * PDW_img[:, 2 * i + 1, :, :])

        # Output_PDW = self.PDW_Net(PDW_img)

        return tot / int(rec_img.size()[1] / 4)