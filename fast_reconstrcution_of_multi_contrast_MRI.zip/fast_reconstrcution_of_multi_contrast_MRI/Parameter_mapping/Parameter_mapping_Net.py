import numpy as np
import torch
import torch.nn as nn
from timm.models.layers import to_2tuple


class Mlp(nn.Module):
    def __init__(self, in_features=None, hidden_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        self.in_features = in_features
        self.hidden_features = hidden_features
        self.fc1 = nn.Linear(self.in_features, self.hidden_features)
        self.fc2 = nn.Linear(self.hidden_features, self.in_features)
        self.act = act_layer()
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)

        return x


class Mlp_T2S(nn.Module):
    def __init__(self, in_features=None, hidden_features=None, act_layer=nn.GELU, drop=0.1):
        super().__init__()
        self.in_features = in_features
        self.hidden_features = hidden_features
        self.fc1 = nn.Linear(self.in_features, self.hidden_features)
        self.fc2 = nn.Linear(self.hidden_features, self.hidden_features)
        self.act = act_layer()
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.act(x)

        return x


class mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None):
        super().__init__()
        self.in_features = in_features
        self.hidden_features = hidden_features
        self.fc1 = nn.Linear(self.in_features, self.hidden_features)
        self.act = nn.GELU()

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        return x


class PatchEmbed(nn.Module):
    r""" Image to Patch Embedding"""

    def __init__(self):
        super().__init__()

    def forward(self, x):
        x = x.flatten(2).transpose(1, 2)
        return x


class PatchUnEmbed(nn.Module):
    r""" Image to Patch Unembedding"""

    def __init__(self, embed_dim):
        super().__init__()
        self.embed_dim = embed_dim

    def forward(self, x, x_size):
        B, HW, C = x.shape
        x = x.transpose(1, 2).view(B, C, x_size[0], x_size[1])
        return x


class Convfirst(nn.Module):
    def __init__(self, ch_in, ch_out):
        super(Convfirst, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch_in, ch_out, kernel_size=1, stride=1, padding=0, bias=True),
        )

    def forward(self, x):
        return self.conv(x)


class Convlast(nn.Module):
    def __init__(self, ch_in, ch_out):
        super(Convlast, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch_in, ch_out, kernel_size=1, stride=1, padding=0, bias=True),
        )

    def forward(self, x):
        return self.conv(x)

