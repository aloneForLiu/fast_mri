import torch
import torch.nn as nn
from K_space.unet_parts import DoubleConv

class Up1(nn.Module):
    def __init__(self, in_channels, out_channels, bilinear=True):
        super(Up1, self).__init__()
        if bilinear:
            self.up1 = nn.Upsample(scale_factor=(2, 2), mode='bilinear', align_corners=True)
            self.up2 = nn.Upsample(scale_factor=(3, 3), mode='bilinear', align_corners=True)
            self.up3 = nn.Upsample(scale_factor=(4, 4), mode='bilinear', align_corners=True)
            self.up4 = nn.Upsample(scale_factor=(5, 5), mode='bilinear', align_corners=True)
            self.adavpool2d1 = nn.AvgPool2d((2, 2))
            self.adavpool2d2 = nn.AvgPool2d((3, 3))
            self.adavpool2d3 = nn.AvgPool2d((4, 4))
            self.adavpool2d4 = nn.AvgPool2d((5, 5))
            self.con1 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.con2 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.con3 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.con4 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.avgpool_conv = nn.Sequential(
                nn.ConvTranspose2d(in_channels + in_channels // 4, in_channels + in_channels // 4, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=True, groups=in_channels + in_channels // 4),
                nn.Conv2d(in_channels + in_channels // 4, in_channels // 2, kernel_size=1, stride=1, padding=0, bias=True),
                nn.InstanceNorm2d(in_channels // 2),
                nn.LeakyReLU(0.2),
            )
            self.conv = DoubleConv(in_channels, out_channels)
    def forward(self, x1, x2):
        xup1 = self.up1(x1)
        xup1 = self.con1(xup1)
        xup1 = self.adavpool2d1(xup1)
        xup2 = self.up2(x1)
        xup2 = self.con2(xup2)
        xup2 = self.adavpool2d2(xup2)
        xup3 = self.up3(x1)
        xup3 = self.con3(xup3)
        xup3 = self.adavpool2d3(xup3)
        xup4 = self.up4(x1)
        xup4 = self.con4(xup4)
        xup4 = self.adavpool2d4(xup4)
        x = torch.cat([xup4, xup3, xup2, xup1, x1], dim=1)
        x = self.avgpool_conv(x)
        x = torch.cat([x2, x], dim=1)
        x = self.conv(x)
        return x

class Up2(nn.Module):
    def __init__(self, in_channels, out_channels, bilinear=True):
        super(Up2, self).__init__()
        if bilinear:
            self.up1 = nn.Upsample(scale_factor=(2, 2), mode='bilinear', align_corners=True)
            self.up2 = nn.Upsample(scale_factor=(3, 3), mode='bilinear', align_corners=True)
            self.up3 = nn.Upsample(scale_factor=(4, 4), mode='bilinear', align_corners=True)
            self.adavpool2d1 = nn.AvgPool2d((2, 2))
            self.adavpool2d2 = nn.AvgPool2d((3, 3))
            self.adavpool2d3 = nn.AvgPool2d((4, 4))
            self.con1 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.con2 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.con3 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.avgpool_conv = nn.Sequential(
                nn.ConvTranspose2d(in_channels + in_channels * 3 // 16, in_channels + in_channels * 3 // 16,
                                   kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=True, groups=in_channels + in_channels * 3 // 16),
                nn.Conv2d(in_channels + in_channels * 3 // 16, in_channels // 2, kernel_size=1, stride=1, padding=0, bias=True),
                nn.InstanceNorm2d(in_channels // 2),
                nn.LeakyReLU(0.2))
            self.conv = DoubleConv(in_channels, out_channels)



    def forward(self, x1, x2):
        xup1 = self.up1(x1)
        xup1 = self.con1(xup1)
        xup1 = self.adavpool2d1(xup1)
        xup2 = self.up2(x1)
        xup2 = self.con2(xup2)
        xup2 = self.adavpool2d2(xup2)
        xup3 = self.up3(x1)
        xup3 = self.con3(xup3)
        xup3 = self.adavpool2d3(xup3)
        x = torch.cat([xup3, xup2, xup1, x1], dim=1)
        x = self.avgpool_conv(x)
        x = torch.cat([x2, x], dim=1)
        return self.conv(x)

class Up3(nn.Module):
    def __init__(self, in_channels, out_channels, bilinear=True):
        super(Up3, self).__init__()
        if bilinear:
            self.up1 = nn.Upsample(scale_factor=(2, 2), mode='bilinear', align_corners=True)
            self.up2 = nn.Upsample(scale_factor=(3, 3), mode='bilinear', align_corners=True)
            self.adavpool2d1 = nn.AvgPool2d((2, 2))
            self.adavpool2d2 = nn.AvgPool2d((3, 3))
            self.con1 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.con2 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.avgpool_conv = nn.Sequential(
                nn.ConvTranspose2d(in_channels + in_channels * 2 // 16, in_channels + in_channels * 2 // 16,
                                   kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=True, groups=in_channels + in_channels * 2 // 16),
                nn.Conv2d(in_channels + in_channels * 2 // 16, in_channels // 2, kernel_size=1, stride=1, padding=0,
                bias=True),
                nn.InstanceNorm2d(in_channels // 2),
                nn.LeakyReLU(0.2))
            self.conv = DoubleConv(in_channels, out_channels)

    def forward(self, x1, x2):
        xup1 = self.up1(x1)
        xup1 = self.con1(xup1)
        xup1 = self.adavpool2d1(xup1)
        xup2 = self.up2(x1)
        xup2 = self.con2(xup2)
        xup2 = self.adavpool2d2(xup2)
        x = torch.cat([xup2, xup1, x1], dim=1)
        x = self.avgpool_conv(x)
        x = torch.cat([x2, x], dim=1)
        return self.conv(x)

class Up4(nn.Module):

    def __init__(self, in_channels, out_channels, bilinear=True):
        super(Up4, self).__init__()
        if bilinear:
            self.up1 = nn.Upsample(scale_factor=(2, 2), mode='bilinear', align_corners=True)
            self.adavpool2d1 = nn.AvgPool2d((2, 2))
            self.con1 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
            self.avgpool_conv = nn.Sequential(
                nn.ConvTranspose2d(in_channels + in_channels * 1 // 16, in_channels + in_channels * 1 // 16,
                                   kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=True, groups=in_channels + in_channels * 1 // 16),
                nn.Conv2d(in_channels + in_channels * 1 // 16, in_channels // 2, kernel_size=1, stride=1, padding=0,
                bias=True),
                nn.InstanceNorm2d(in_channels // 2),
                nn.LeakyReLU(0.2))
            self.conv = DoubleConv(in_channels, out_channels)

    def forward(self, x1, x2):
        xup1 = self.up1(x1)
        xup1 = self.con1(xup1)
        xup1 = self.adavpool2d1(xup1)
        x = torch.cat([xup1, x1], dim=1)
        x = self.avgpool_conv(x)
        x = torch.cat([x2, x], dim=1)
        return self.conv(x)


class Up(nn.Module):
    """Upscaling then double conv"""

    def __init__(self, in_channels, out_channels, bilinear=True):
        super(Up, self).__init__()
        # if bilinear, use the normal convolutions to reduce the number of channels
        if bilinear:
            self.up = nn.Upsample(scale_factor=(2, 2), mode='bilinear', align_corners=True)
            self.conv = DoubleConv(in_channels, out_channels, in_channels // 2)
        else:
            self.up = nn.ConvTranspose2d(in_channels, in_channels // 2, kernel_size=2, stride=2)
            self.conv = DoubleConv(in_channels, out_channels)

    def forward(self, x1, x2):
        x1 = self.up(x1)
        x = torch.cat([x2, x1], dim=1)
        return self.conv(x)