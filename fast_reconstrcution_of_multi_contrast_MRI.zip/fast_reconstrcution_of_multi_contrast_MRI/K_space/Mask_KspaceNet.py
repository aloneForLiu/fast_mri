""" The Pre-trained network based on UNet"""
from K_space.Mask_Kspace import *

class Mask_KspaceNet(nn.Module):
    """U-Net  #https://github.com/milesial/Pytorch-UNet
    """
    def __init__(self, in_channels1, in_channels2):
        self.in_channels1 = in_channels1
        self.in_channels2 = in_channels2
        super(Mask_KspaceNet, self).__init__()
        self.change_channel1 = change_channel(in_channel=self.in_channels1, out_channel=32)
        self.change_channel2 = change_channel(in_channel=self.in_channels2, out_channel=32)
        self.Mask_K_space_Down0 = Mask_K_space_Down_one(32, 64)
        self.Mask_K_space_Down1 = Mask_K_space_Down(64, 128)
        self.Mask_K_space_Down2 = Mask_K_space_Down(128, 256)
        self.Mask_K_space_Down3 = Mask_K_space_Down(256, 512)
        self.Mask_K_space_Down4 = Mask_K_space_Down(512, 1024)
        self.Mask_K_space_UP1 = Mask_K_space_UP(1024, 512)
        self.Mask_K_space_UP2 = Mask_K_space_UP(512, 256)
        self.Mask_K_space_UP3 = Mask_K_space_UP(256, 128)
        self.Mask_K_space_UP4 = Mask_K_space_UP(128, 64)
        self.Mask_K_space_UP5 = Mask_K_space_UP_Last(64, 32)

    def forward(self, kspace, mask):
        for i in range(mask.size()[1]):
            kspace[:, 2*i:2*i+2, :, :] = mask[:, i, :, :] * kspace[:, 2*i:2*i+2, :, :]
        if kspace.size()[1] == self.in_channels1:
            Output_kspace, _ = self.change_channel1(kspace, None)
        if kspace.size()[1] == self.in_channels2:
            Output_kspace, _ = self.change_channel2(kspace, None)
        MK1 = self.Mask_K_space_Down0(Output_kspace)
        MK2 = self.Mask_K_space_Down1(MK1)
        MK3 = self.Mask_K_space_Down2(MK2)
        MK4 = self.Mask_K_space_Down3(MK3)
        MK5 = self.Mask_K_space_Down4(MK4)
        MK6 = self.Mask_K_space_UP1(MK5, MK4)
        MK7 = self.Mask_K_space_UP2(MK6, MK3)
        MK8 = self.Mask_K_space_UP3(MK7, MK2)
        MK9 = self.Mask_K_space_UP4(MK8, MK1)
        MK10 = self.Mask_K_space_UP5(MK9)
        if kspace.size()[1] == self.in_channels1:
            _, Output = self.change_channel1(None, MK10)
        if kspace.size()[1] == self.in_channels2:
            _, Output = self.change_channel2(None, MK10)
        return MK1, MK2, MK3, MK4, MK6, MK7, MK8, MK9, Output

class change_channel(nn.Module):

    def __init__(self, in_channel=None, out_channel=None):
        super(change_channel, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.convlast = Convlast(self.out_channel, self.in_channel)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)
        return x1, x2


