import torch
import torch.nn as nn
from K_space.unet_parts import DoubleConv
class DownAvg1(nn.Module):

    def __init__(self, in_channels, out_channels):
        super(DownAvg1, self).__init__()
        self.con1 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        self.con2 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        self.con3 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        self.con4 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        """ DW CONV """
        self.avgpool_conv = nn.Sequential(
            nn.Conv2d(in_channels + in_channels // 4, in_channels + in_channels // 4, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=True, groups=in_channels + in_channels // 4),
            nn.Conv2d(in_channels + in_channels // 4, out_channels, kernel_size=1, stride=1, padding=0, bias=True),
            nn.InstanceNorm2d(out_channels),
            nn.LeakyReLU(0.2))
        self.adavpool2d1 = nn.AvgPool2d((2, 2))
        self.adavpool2d2 = nn.AvgPool2d((4, 4))
        self.adavpool2d3 = nn.AvgPool2d((8, 8))
        self.adavpool2d4 = nn.AvgPool2d((16, 16))
        self.up1 = nn.Upsample(scale_factor=(2, 2), mode='bilinear', align_corners=True)
        self.up2 = nn.Upsample(scale_factor=(4, 4), mode='bilinear', align_corners=True)
        self.up3 = nn.Upsample(scale_factor=(8, 8), mode='bilinear', align_corners=True)
        self.up4 = nn.Upsample(scale_factor=(16, 16), mode='bilinear', align_corners=True)



    def forward(self, x):

        x1 = self.adavpool2d1(x)
        x1 = self.con1(x1)
        x2 = self.adavpool2d2(x)
        x2 = self.con2(x2)
        x3 = self.adavpool2d3(x)
        x3 = self.con3(x3)
        x4 = self.adavpool2d4(x)
        x4 = self.con4(x4)
        x1 = self.up1(x1)
        x2 = self.up2(x2)
        x3 = self.up3(x3)
        x4 = self.up4(x4)
        x = torch.cat([x4, x3, x2, x1, x], dim=1)
        x = self.avgpool_conv(x)

        return x

class DownAvg2(nn.Module):

    def __init__(self, in_channels, out_channels):
        super(DownAvg2, self).__init__()
        self.con1 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        self.con2 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        self.con3 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        """ DW CONV """
        self.avgpool_conv = nn.Sequential(
            nn.Conv2d(in_channels + in_channels * 3 // 16, in_channels + in_channels * 3 // 16, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1),
                      bias=True, groups=in_channels + in_channels * 3 // 16),
            nn.Conv2d(in_channels + in_channels * 3 // 16, out_channels, kernel_size=1, stride=1, padding=0, bias=True),
            nn.InstanceNorm2d(out_channels),
            nn.LeakyReLU(0.2))
        self.adavpool2d1 = nn.AvgPool2d((2, 2))
        self.adavpool2d2 = nn.AvgPool2d((4, 4))
        self.adavpool2d3 = nn.AvgPool2d((8, 8))
        self.up1 = nn.Upsample(scale_factor=(2, 2), mode='bilinear', align_corners=True)
        self.up2 = nn.Upsample(scale_factor=(4, 4), mode='bilinear', align_corners=True)
        self.up3 = nn.Upsample(scale_factor=(8, 8), mode='bilinear', align_corners=True)

    def forward(self, x):

        x1 = self.adavpool2d1(x)
        x1 = self.con1(x1)
        x2 = self.adavpool2d2(x)
        x2 = self.con2(x2)
        x3 = self.adavpool2d3(x)
        x3 = self.con3(x3)
        x1 = self.up1(x1)
        x2 = self.up2(x2)
        x3 = self.up3(x3)
        x = torch.cat([x3, x2, x1, x], dim=1)
        x = self.avgpool_conv(x)

        return x




class DownAvg3(nn.Module):

    def __init__(self, in_channels, out_channels):
        super(DownAvg3, self).__init__()

        self.con1 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        self.con2 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        """ DW CONV """
        self.avgpool_conv = nn.Sequential(
            nn.Conv2d(in_channels + in_channels * 2 // 16, in_channels + in_channels * 2 // 16, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1),
                      bias=True, groups=in_channels + in_channels * 2 // 16),
            nn.Conv2d(in_channels + in_channels * 2 // 16, out_channels, kernel_size=1, stride=1, padding=0, bias=True),
            nn.InstanceNorm2d(out_channels),
            nn.LeakyReLU(0.2))
        self.adavpool2d1 = nn.AvgPool2d((2, 2))
        self.adavpool2d2 = nn.AvgPool2d((4, 4))

        self.up1 = nn.Upsample(scale_factor=(2, 2), mode='bilinear', align_corners=True)
        self.up2 = nn.Upsample(scale_factor=(4, 4), mode='bilinear', align_corners=True)


    def forward(self, x):

        x1 = self.adavpool2d1(x)
        x1 = self.con1(x1)
        x2 = self.adavpool2d2(x)
        x2 = self.con2(x2)
        x1 = self.up1(x1)
        x2 = self.up2(x2)
        x = torch.cat([x2, x1, x], dim=1)
        x = self.avgpool_conv(x)

        return x



class DownAvg4(nn.Module):

    def __init__(self, in_channels, out_channels):
        super(DownAvg4, self).__init__()
        self.con1 = nn.Conv2d(in_channels, in_channels // 16, kernel_size=1)
        """ DW CONV """
        self.avgpool_conv = nn.Sequential(
            nn.Conv2d(in_channels + in_channels * 1 // 16, in_channels + in_channels * 1 // 16, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1),
                      bias=True, groups=in_channels + in_channels * 1 // 16,),
            nn.Conv2d(in_channels + in_channels * 1 // 16, out_channels, kernel_size=1, stride=1, padding=0, bias=True),
            nn.InstanceNorm2d(out_channels),
            nn.LeakyReLU(0.2))
        self.adavpool2d1 = nn.AvgPool2d((2, 2))
        self.up1 = nn.Upsample(scale_factor=(2, 2), mode='bilinear', align_corners=True)

    def forward(self, x):

        x1 = self.adavpool2d1(x)
        x1 = self.con1(x1)
        x1 = self.up1(x1)
        x = torch.cat([x1, x], dim=1)
        x = self.avgpool_conv(x)

        return x



class Down(nn.Module):
    """Downscaling with maxpool then double conv"""

    def __init__(self, in_channels, out_channels):
        super(Down, self).__init__()
        self.maxpool_conv = nn.Sequential(
            nn.MaxPool2d((2, 2)),
            DoubleConv(in_channels, out_channels)
        )

    def forward(self, x):
        return self.maxpool_conv(x)