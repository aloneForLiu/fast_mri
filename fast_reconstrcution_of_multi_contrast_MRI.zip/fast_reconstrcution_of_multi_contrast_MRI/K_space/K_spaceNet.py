import torch

from K_space.unet_parts import OutConv, FirstConv, Convfirst, Convlast
from K_space.Kspace_Up import Up
from K_space.Kspace_Down import Down
import torch.nn as nn


class K_spaceNet(nn.Module):
    def __init__(self, n_channels_in, n_channels_out, bilinear=True):
        super(K_spaceNet, self).__init__()
        self.n_channels_in = n_channels_in
        self.n_channels_out = n_channels_out
        self.bilinear = bilinear
        self.inc = FirstConv(self.n_channels_in, 128)
        self.down1 = Down(128, 256)
        self.down2 = Down(256, 512)
        self.down3 = Down(512, 1024)
        self.down4 = Down(1024, 2048)
        self.up1 = Up(2048, 1024, self.bilinear)
        self.up2 = Up(1024, 512, self.bilinear)
        self.up3 = Up(512, 256, self.bilinear)
        self.up4 = Up(256, 128, self.bilinear)
        self.outc = OutConv(128, self.n_channels_out)

    def forward(self, kspace):
        x1 = self.inc(kspace)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)
        out = self.outc(x)

        return out

class k_change_channel(nn.Module):

    def __init__(self, in_channel=None, out_channel=None):
        super(k_change_channel, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.convlast = Convlast(self.out_channel, self.in_channel)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)

        return x1, x2