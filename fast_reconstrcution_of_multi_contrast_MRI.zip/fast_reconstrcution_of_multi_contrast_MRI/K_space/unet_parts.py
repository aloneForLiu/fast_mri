import torch.nn as nn

class change_channel(nn.Module):

    def __init__(self, in_channel=None, out_channel=None):
        super(change_channel, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.convlast = Convlast(self.out_channel, self.in_channel)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)

        return x1, x2


class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels, mid_channels=None):
        super(DoubleConv, self).__init__()
        if not mid_channels:
            mid_channels = out_channels
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1),
            nn.InstanceNorm2d(mid_channels),
            nn.LeakyReLU(0.2, False),
            nn.Conv2d(mid_channels, out_channels, kernel_size=3, padding=1),
            nn.InstanceNorm2d(out_channels),
            nn.LeakyReLU(0.2, False)
        )

    def forward(self, x):
        return self.double_conv(x)


class FirstConv(nn.Module):
    def __init__(self, in_channels, out_channels, mid_channels=None):
        super(FirstConv, self).__init__()
        if not mid_channels:
            mid_channels = out_channels
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1),
            nn.InstanceNorm2d(mid_channels),
            nn.LeakyReLU(0.2, False),
            nn.Conv2d(mid_channels, out_channels, kernel_size=3, padding=1),
            nn.InstanceNorm2d(out_channels),
            nn.LeakyReLU(0.2, False)
        )

    def forward(self, x):
        return self.double_conv(x)



class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        return self.conv(x)


class Convfirst(nn.Module):
    def __init__(self, ch_in, ch_out):
        super(Convfirst, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch_in, ch_out, kernel_size=1, stride=1, padding=0, bias=True))

    def forward(self, x):
        return self.conv(x)

class Convlast(nn.Module):
    def __init__(self, ch_in, ch_out):
        super(Convlast, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch_in, ch_out, kernel_size=1, stride=1, padding=0, bias=True))

    def forward(self, x):
        return self.conv(x)