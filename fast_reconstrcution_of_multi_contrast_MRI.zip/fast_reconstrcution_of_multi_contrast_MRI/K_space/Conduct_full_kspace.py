import torch

'''Acceleration factors'''
M = 5
def Conduct_kspace(Conv_kspace, Mask_kspace):

    # figure out [0,1] matrix
    Ratio_matrix = torch.abs(Mask_kspace / Conv_kspace)
    mean = torch.mean(Ratio_matrix, dim=1) * 2 / M
    Ratio_matrix[Ratio_matrix > mean] = 0
    Ratio_matrix[Ratio_matrix != 0] = 1

    Work_kspace = Conv_kspace * Ratio_matrix + Mask_kspace * (1 - Ratio_matrix)

    return Work_kspace




