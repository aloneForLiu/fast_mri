import yaml
from types import SimpleNamespace
import logging
import os
import sys
import shutil

import torch
from tqdm import tqdm
from pprint import pprint
import nibabel as nib
from generator_model import WNet
from torch.utils.tensorboard import SummaryWriter
from Data.dataset import MRIDataset
from Loss import netLoss, set_grad
from torch.utils.data import DataLoader
from Parameter_mapping.Parameter_mapping_PDW import PNet
from Parameter_mapping.Parameter_mapping_T1W import TNet
from Parameter_mapping.Parameter_mapping_T2S import T2SNet
from Parameter_mapping.Parameter_mapping_PDM import PDMNet
from Parameter_mapping.Parameter_mapping_T1M import T1MNet
from eval import eval_net
import torch.nn as nn
import numpy as np
from modelsize import modelsize
eps = 1e-8

os.environ['CUDA_LAUNCH_BLOCKING'] = '0,1'
def train(args):
    # Preprocessing
    logging.info('Preprocessing is beginning')
    print(os.environ["CUDA_VISIBLE_DEVICES"])

    logging.info('Preprocessing is successful')

    # Init Generator network
    G_model = WNet(args)
    device_ids = [0, 1]
    G_model = torch.nn.DataParallel(G_model, device_ids=device_ids)
   
    size_G = modelsize(G_model)

    print(torch.version.cuda)
    print(torch.__version__)
    print(torch.cuda.is_available())

    # logging.info(f'Network:\n'
                # f'\t{"bilinear" if G_model.bilinear else "Transposed conv"} upscaling')
    G_optimizer = torch.optim.Adam(G_model.parameters(), lr=args.lr_G, betas=(0.5, 0.999))

    def clip_gradient(optimizer, grad_clip):    #梯度截取
        """
        Clips gradients computed during backpropagation to avoid explosion of gradients.

        :param optimizer: optimizer with the gradients to be clipped
        :param grad_clip: clip value
        """
        for group in optimizer.param_groups:
            for param in group["params"]:
                if param.grad is not None:
                    param.grad.data.clamp_(-grad_clip, grad_clip)

    G_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(G_optimizer, 'min', verbose=True, patience=8)   #该方法中提供了多种基于epoch训练次数进行学习率调整的方法
    G_model.cuda()

    # Init parameter mapping network
    P_model = PNet(args)
    #P_model = torch.nn.DataParallel(P_model)
    P_model.cuda()

    T_model = TNet(args)
    #T_model = torch.nn.DataParallel(T_model)
    T_model.cuda()

    T2S_model = T2SNet(args)
    T2S_model = torch.nn.DataParallel(T2S_model)
    size_T2S = modelsize(T2S_model)
    T2S_optimizer = torch.optim.Adam(T2S_model.parameters(), lr=args.lr_T2S, betas=(0.5, 0.999))
    T2S_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(T2S_optimizer, 'min', verbose=True, patience=18)
    T2S_model.cuda()

    PDM_model = PDMNet(args)
    PDM_model = torch.nn.DataParallel(PDM_model)
    size_PDM = modelsize(PDM_model)
    PDM_optimizer = torch.optim.Adam(PDM_model.parameters(), lr=args.lr_PDM, betas=(0.5, 0.999))
    PDM_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(PDM_optimizer, 'min', verbose=True, patience=13)
    PDM_model.cuda()

    T1M_model = T1MNet(args)
    T1M_model = torch.nn.DataParallel(T1M_model)
    size_T1M = modelsize(T1M_model)
    T1M_optimizer = torch.optim.Adam(T1M_model.parameters(), lr=args.lr_T1M, betas=(0.5, 0.999))
    T1M_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(T1M_optimizer, 'min', verbose=True, patience=18)
    T1M_model.cuda()

    # Init Dataloaders
    if args.dataset == 'MRI':
        train_dataset = MRIDataset(args, t_num=680, mode=0)
        valid_dataset = MRIDataset(args, t_num=40, mode=1)
    else:
        logging.error("Data type not supported")

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.train_num_workers, pin_memory=True)
    val_loader = DataLoader(valid_dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.val_num_workers, pin_memory=True)

    # Init tensorboard writer
    if args.tb_write_losses:
        writer = SummaryWriter(log_dir=args.output_dir + '/tensorboard')   #tensorboard 可视化loss

    # Init loss object
    loss = netLoss(args)

    # Load checkpoint
    if args.load_cp:
        checkpoint = torch.load(args.output_dir + f'CP_epoch.pth',
                                map_location=args.device)  # 从文件中加载一个用torch.save()保存的对象
        G_model.load_state_dict(checkpoint['G_model_state_dict'])

        P_model.load_state_dict(checkpoint['P_model_state_dict'])

        T_model.load_state_dict(checkpoint['T_model_state_dict'])

        T2S_model.load_state_dict(checkpoint['T2S_model_state_dict'])

        PDM_model.load_state_dict(checkpoint['PDM_model_state_dict'])

        T1M_model.load_state_dict(checkpoint['T1M_model_state_dict'])

        if args.resume_training:
            start_epoch = int(checkpoint['epoch'])
            G_optimizer.load_state_dict(checkpoint['G_optimizer_state_dict'])
            PDM_optimizer.load_state_dict(checkpoint['PDM_optimizer_state_dict'])
            T1M_optimizer.load_state_dict(checkpoint['T1M_optimizer_state_dict'])

            G_scheduler.load_state_dict(checkpoint['G_scheduler_state_dict'])
            T2S_scheduler.load_state_dict(checkpoint['T2S_scheduler_state_dict'])
            PDM_scheduler.load_state_dict(checkpoint['PDM_scheduler_state_dict'])
            T1M_scheduler.load_state_dict(checkpoint['T1M_scheduler_state_dict'])
            logging.info(
                f'Models, optimizer and scheduler loaded from {args.load_cp}')  # logging.info是输出日志的信息 logging.info('输出信息')
        else:
            logging.info(f'Models only load from {args.load_cp}')
    else:
        start_epoch = 0
    #Start training

    logging.info(f'''Starting training:
        Epochs:          {args.epochs_n}
        Batch size:      {args.batch_size}
        Learning rate:   {args.lr_G}
        Device:          {args.device}
    ''')

    best_ssim = 0.

    try: #Catch keyboard interrupt and save state
        for epoch in range(start_epoch, args.epochs_n):
            G_model.train()
            T2S_model.train()
            PDM_model.train()
            T1M_model.train()
            progress = 0
            with tqdm(desc=f'Epoch {epoch + 1}/{args.epochs_n}', unit=' imgs') as pbar:   ##创建一个进度条
                # Train loop
                for batch in train_loader:
                    kspace_mc = batch['kspace_mc'].to(dtype=torch.float32).cuda()
                    target_Kspace = batch['target_Kspace'].to(dtype=torch.float32).cuda()
                    target_img = batch['target_img'].to(dtype=torch.float32).cuda()
                    Mask = batch['Mask'].to(device=args.device, dtype=torch.float32)
                    PDW = batch['PDW'].to(dtype=torch.float32).cuda()
                    T2S = batch['T2S'].to(dtype=torch.float32).cuda()
                    T1W = batch['T1W'].to(dtype=torch.float32).cuda()
                    PDM = batch['PDM'].to(dtype=torch.float32).cuda()
                    T1M = batch['T1M'].to(dtype=torch.float32).cuda()

                    PDW = PDW.view(-1, 1, PDW.size()[1], PDW.size()[2])
                    T2S = T2S.view(-1, 1, T2S.size()[1], T2S.size()[2])
                    T1W = T1W.view(-1, 1, T1W.size()[1], T1W.size()[2])
                    PDM = PDM.view(-1, 1, PDM.size()[1], PDM.size()[2])
                    T1M = T1M.view(-1, 1, T1M.size()[1], T1M.size()[2])

                    # Forward G:
                    rec_img5, rec_Kspace5, last_tensor_mask, _, _, _, _, _, _, _, _ = G_model(kspace_mc, Mask, epoch, option=1)
                    Output_PDW = P_model(rec_img5)
                    # Create output dir
                    Mask_output_test = '/hpc/data/home/bme/v-liuyx1/The_latest/fast_reconstrcution_of_multi_contrast_MRI_Newdata/output/CG_Coil/J=1/change_sample/8x/'
                    try:
                        os.mkdir(Mask_output_test + '_' + str(epoch) + '_' + 'trainMask')
                        logging.info('Created checkpoint directory')
                    except OSError:
                        pass
                    tensor_mask = last_tensor_mask.squeeze()
                    tensor_mask = tensor_mask.cpu().detach().numpy()
                    for i in range(tensor_mask.shape[0]):
                        for j in range(tensor_mask.shape[1]):
                          save_Mask = nib.Nifti1Image(tensor_mask[i, j, 0, :, :], np.diag([1, 1, 1, 1]))
                          save_Mask.to_filename(os.path.join(Mask_output_test + '_' + str(epoch) + '_' + 'trainMask', str(i) + '_' + str(j) + '_Mask.nii.gz'))
                    print(Output_PDW.size())
                    
                    FullLoss, ImL22, ImL12, K_spaceL2, De_ssim2 = loss.calc_gen_loss(rec_img5, rec_Kspace5, target_img, target_Kspace)
                    

                    # Forward T2S for T2S loss:
                    if args.Parameter_training:
                        Output_T2S = T2S_model(rec_img5.detach())
                        if args.T2Smodel_training:
                            T2S_loss, _ = loss.calc_T2S_loss(Output_T2S, T2S)

                        # Train/stop Train T2S criteria
                        train_T2S = epoch >= 0

                    if args.T2Smodel_training:
                        set_grad(T2S_model, False)  # No T2S update

                    # Forward PDM for PDM loss:
                    if args.Parameter_training:
                        Output_PDM = PDM_model(rec_img5.detach())
                        if args.PDMmodel_training:
                            PDM_loss, _ = loss.calc_PDM_loss(Output_PDM, PDM)

                        # Train/stop Train PDM criteria
                        train_PDM = epoch >= 0

                    if args.PDMmodel_training:
                        set_grad(PDM_model, False)  # No PDM update

                    # Forward T1M for T1M loss:
                    if args.Parameter_training:
                        Output_T1M = T1M_model(rec_img5.detach())
                        if args.T1Mmodel_training:
                            T1M_loss, _ = loss.calc_T1M_loss(Output_T1M, T1M)

                        # Train/stop Train T1M criteria
                        train_T1M = epoch >= 0

                    if args.T1Mmodel_training:
                        set_grad(T1M_model, False)  # No T1M update

                    # Optimize parameters
                    # Update G

                    G_optimizer.zero_grad(set_to_none=True)

                    FullLoss.backward()
                    # clip_gradient(G_optimizer, 1)

                    for param in G_model.parameters():
                        if param.grad is not None:
                            param.grad.data = torch.where(torch.isnan(param.grad.data), torch.full_like(param.grad.data, eps), param.grad.data)

                    torch.nn.utils.clip_grad_norm_(G_model.parameters(), max_norm=5)

                    G_optimizer.step()

                    # Update T2S
                    if args.T2Smodel_training:
                        set_grad(T2S_model, True)  # enable backprop for T2S
                        if train_T2S:
                            T2S_optimizer.zero_grad(set_to_none=True)
                            T2S_loss.backward()
                            T2S_optimizer.step()

                    # Update PDM
                    if args.PDMmodel_training:
                        set_grad(PDM_model, True)  # enable backprop for PDM
                        if train_PDM:
                            PDM_optimizer.zero_grad(set_to_none=True)
                            PDM_loss.backward()
                            PDM_optimizer.step()

                    # Update T1M
                    if args.T1Mmodel_training:
                        set_grad(T1M_model, True)  # enable backprop for T1M
                        if train_T1M:
                            T1M_optimizer.zero_grad(set_to_none=True)
                            T1M_loss.backward()
                            T1M_optimizer.step()

                    # Update progress bar
                    progress += 80 * target_Kspace.shape[0] / len(train_dataset)

                    pbar.set_postfix(
                            **{'FullLoss': FullLoss.item(), 'ImL2': ImL22.item(), 'ImL1': ImL12.item(),
                               'K_spaceL2': K_spaceL2.item(),
                               'T2S_loss': T2S_loss.item(),  'PDM_loss': PDM_loss.item(), 'T1M_loss': T1M_loss.item(),
                                'De_ssim': De_ssim2.item(), 'Train T2S': train_T2S,  'Train PDM': train_PDM, 'Train T1M': train_T1M,
                                'Prctg of train set': progress, 'lr_G': G_optimizer.state_dict()['param_groups'][0]['lr'],
                               'lr_T2S': T2S_optimizer.state_dict()['param_groups'][0]['lr'],  'lr_PDM': PDM_optimizer.state_dict()['param_groups'][0]['lr'],
                               'lr_T1M': T1M_optimizer.state_dict()['param_groups'][0]['lr']})
                    pbar.update(target_Kspace.shape[0])  # current batch size

                # Schedular update
                G_scheduler.step(FullLoss)
                if train_T2S:
                    T2S_scheduler.step(T2S_loss)
                if train_PDM:
                    PDM_scheduler.step(PDM_loss)
                if train_T1M:
                    T1M_scheduler.step(T1M_loss)

            # On epoch end
            # Validation
            if epoch >= 0:
                val_FullLoss, val_ImL2, val_ImL1, val_PSNR, val_SSIM, val_NRMSE, PDW_PSNR, T2S_PSNR, T1W_PSNR, PDM_PSNR, T1M_PSNR, PDW_SSIM, T2S_SSIM, T1W_SSIM, \
                PDM_SSIM, T1M_SSIM, PDW_NRMSE, T2S_NRMSE, \
                T1W_NRMSE, PDM_NRMSE, T1M_NRMSE, val_T2S, val_PDM, val_T1M = \
                    eval_net(G_model, P_model, T2S_model, T_model, PDM_model, T1M_model, val_loader, loss, args, epoch)
                logging.info(
                    'Validation full score: {}, ImL2: {}, ImL1: {}, PSNR: {}, SSIM: {}, NRMSE: {}, PDW_PSNR: {}, T2S_PSNR: {}, T1W_PSNR: {}, PDM_PSNR: {}, T1M_PSNR: {}, PDW_SSIM: {}, T2S_SSIM: {}, T1W_SSIM: {}, PDM_SSIM: {},'
                    'T1M_SSIM: {}, PDW_NRMSE: {}, T2S_NRMSE: {}, T1W_NRMSE: {}, PDM_NRMSE: {}, T1M_NRMSE: {}, '
                    ' val_T2S: {},  val_PDM: {}, val_T1M: {}'.format(
                        val_FullLoss,
                        val_ImL2,
                        val_ImL1,
                        val_PSNR,
                        val_SSIM, val_NRMSE, PDW_PSNR, T2S_PSNR, T1W_PSNR, PDM_PSNR, T1M_PSNR, PDW_SSIM, T2S_SSIM, T1W_SSIM, PDM_SSIM, T1M_SSIM, PDW_NRMSE, T2S_NRMSE, T1W_NRMSE, PDM_NRMSE, T1M_NRMSE, val_T2S, val_PDM, val_T1M))

            #Write to TB:
            if args.tb_write_losses:
                writer.add_scalar('train/FullLoss', FullLoss.item(), epoch)
                writer.add_scalar('train/ImL2', ImL22.item(), epoch)
                writer.add_scalar('train/ImL1', ImL12.item(), epoch)
                writer.add_scalar('train/K_spaceL2', K_spaceL2.item(), epoch)
                writer.add_scalar('train/De_ssim', De_ssim2.item(), epoch)
                writer.add_scalar('train/T2S_loss', T2S_loss.item(), epoch)
                writer.add_scalar('train/PDM_loss', PDM_loss.item(), epoch)
                writer.add_scalar('train/T1M_loss', T1M_loss.item(), epoch)
                writer.add_scalar('train/learning_rate_G', G_optimizer.param_groups[0]['lr'], epoch)
                writer.add_scalar('train/learning_rate_T2S', T2S_optimizer.param_groups[0]['lr'], epoch)
                writer.add_scalar('train/learning_rate_PDM', PDM_optimizer.param_groups[0]['lr'], epoch)
                writer.add_scalar('train/learning_rate_T1M', T1M_optimizer.param_groups[0]['lr'], epoch)
                if epoch >= 0:
                    writer.add_scalar('validation/FullLoss', val_FullLoss, epoch)
                    writer.add_scalar('validation/ImL2', val_ImL2, epoch)
                    writer.add_scalar('validation/ImL1', val_ImL1, epoch)
                    writer.add_scalar('validation/PSNR', val_PSNR, epoch)
                    writer.add_scalar('validation/SSIM', val_SSIM, epoch)
                    writer.add_scalar('validation/NRMSE', val_NRMSE, epoch)
                    writer.add_scalar('validation/PDW_PSNR', PDW_PSNR, epoch)
                    writer.add_scalar('validation/T2S_PSNR', T2S_PSNR, epoch)
                    writer.add_scalar('validation/T1W_PSNR', T1W_PSNR, epoch)
                    writer.add_scalar('validation/PDM_PSNR', PDM_PSNR, epoch)
                    writer.add_scalar('validation/T1M_PSNR', T1M_PSNR, epoch)
                    writer.add_scalar('validation/PDW_SSIM', PDW_SSIM, epoch)
                    writer.add_scalar('validation/T2S_SSIM', T2S_SSIM, epoch)
                    writer.add_scalar('validation/T1W_SSIM', T1W_SSIM, epoch)
                    writer.add_scalar('validation/PDM_SSIM', PDM_SSIM, epoch)
                    writer.add_scalar('validation/T1M_SSIM', T1M_SSIM, epoch)
                    writer.add_scalar('validation/PDW_NRMSE', PDW_NRMSE, epoch)
                    writer.add_scalar('validation/T2S_NRMSE', T2S_NRMSE, epoch)
                    writer.add_scalar('validation/T1W_NRMSE', T1W_NRMSE, epoch)
                    writer.add_scalar('validation/PDM_NRMSE', PDM_NRMSE, epoch)
                    writer.add_scalar('validation/T1M_NRMSE', T1M_NRMSE, epoch)
                    writer.add_scalar('validation/val_T2S', val_T2S, epoch)
                    writer.add_scalar('validation/val_PDM', val_PDM, epoch)
                    writer.add_scalar('validation/val_T1M', val_T1M, epoch)

            #Save Checkpoint
            if epoch > 100:
                if best_ssim < val_SSIM:
                    best_ssim = val_SSIM
                    torch.save({
                        'epoch': epoch,
                        'G_model_state_dict': G_model.state_dict(),
                        'G_optimizer_state_dict': G_optimizer.state_dict(),
                        'G_scheduler_state_dict': G_scheduler.state_dict(),
                        'P_model_state_dict': P_model.state_dict(),
                        'T2S_model_state_dict': T2S_model.state_dict(),
                        'T2S_optimizer_state_dict': T2S_optimizer.state_dict(),
                        'T2S_scheduler_state_dict': T2S_scheduler.state_dict(),
                        'T_model_state_dict': T_model.state_dict(),
                        'PDM_model_state_dict': PDM_model.state_dict(),
                        'PDM_optimizer_state_dict': PDM_optimizer.state_dict(),
                        'PDM_scheduler_state_dict': PDM_scheduler.state_dict(),
                        'T1M_model_state_dict': T1M_model.state_dict(),
                        'T1M_optimizer_state_dict': T1M_optimizer.state_dict(),
                        'T1M_scheduler_state_dict': T1M_scheduler.state_dict(),

                    }, args.output_dir + f'CP_epoch.pth')
                    logging.info(f'Checkpoint saved !')
                logging.info(f'Checkpoint saved !')

                if epoch + 1 == 150:
                    torch.save({
                        'epoch': epoch,
                        'G_model_state_dict': G_model.state_dict(),
                        'G_optimizer_state_dict': G_optimizer.state_dict(),
                        'G_scheduler_state_dict': G_scheduler.state_dict(),
                        'P_model_state_dict': P_model.state_dict(),
                        'T2S_model_state_dict': T2S_model.state_dict(),
                        'T2S_optimizer_state_dict': T2S_optimizer.state_dict(),
                        'T2S_scheduler_state_dict': T2S_scheduler.state_dict(),
                        'T_model_state_dict': T_model.state_dict(),
                        'PDM_model_state_dict': PDM_model.state_dict(),
                        'PDM_optimizer_state_dict': PDM_optimizer.state_dict(),
                        'PDM_scheduler_state_dict': PDM_scheduler.state_dict(),
                        'T1M_model_state_dict': T1M_model.state_dict(),
                        'T1M_optimizer_state_dict': T1M_optimizer.state_dict(),
                        'T1M_scheduler_state_dict': T1M_scheduler.state_dict(),

                    }, args.output_dir + f'CP_epoch{epoch + 1}.pth')
                    logging.info(f'Checkpoint {epoch + 1} saved !')

    except KeyboardInterrupt:
        logging.info('Saved interrupt')
        if epoch + 1 == 150:
            torch.save({
                'epoch': epoch,
                'G_model_state_dict': G_model.state_dict(),
                'G_optimizer_state_dict': G_optimizer.state_dict(),
                'G_scheduler_state_dict': G_scheduler.state_dict(),
                'P_model_state_dict': P_model.state_dict(),
                'T2S_model_state_dict': T2S_model.state_dict(),
                'T2S_optimizer_state_dict': T2S_optimizer.state_dict(),
                'T2S_scheduler_state_dict': T2S_scheduler.state_dict(),
                'T_model_state_dict': T_model.state_dict(),
                'PDM_model_state_dict': PDM_model.state_dict(),
                'PDM_optimizer_state_dict': PDM_optimizer.state_dict(),
                'PDM_scheduler_state_dict': PDM_scheduler.state_dict(),
                'T1M_model_state_dict': T1M_model.state_dict(),
                'T1M_optimizer_state_dict': T1M_optimizer.state_dict(),
                'T1M_scheduler_state_dict': T1M_scheduler.state_dict(),

            }, args.output_dir + f'CP_epoch{epoch + 1}_INTERRUPTED.pth')
            logging.info('Saved interrupt')
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
    writer.close()


def get_args():
    with open('/hpc/data/home/bme/v-liuyx1/The_latest/fast_reconstrcution_of_multi_contrast_MRI_Newdata/config.yaml') as f:
        data = yaml.load(f, Loader=yaml.FullLoader)   #python通过open方式读取文件数据，再通过load函数将数据转化为列表或字典
        #yaml 5.1之前的版本，原来的写法：yaml.load(file)yaml 5.1之后的版本，新的写法：yaml.load(file,Loader=yaml.FullLoader)
    args = SimpleNamespace(**data)   ## 这里的**不可以少,表示命名关键字参数   使用.运算符访问字典

    pprint(data) #pprint函数时pprint模块下方法，是一种标准、格式化输出方式。
    return args


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    args = get_args()

    # Create output dir
    try:
        os.mkdir(args.output_dir)
        logging.info('Created checkpoint directory')
    except OSError:
        pass

    # Set device and GPU (currently only single GPU training is supported
    logging.info(f'Using device {args.device}')


    train(args)

