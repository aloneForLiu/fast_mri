from Image.T_S_Transformer import *
import numpy as np


class T_S_TransformerIR(nn.Module):
    def __init__(self, in_chans=2, input_resolution0=None, input_resolution1=None, 
                 embed_dim=48, depths=[4], num_heads=[6],
                 window_size=8, mlp_ratio=4., qkv_bias=True, qk_scale=None,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0.1,
                 norm_layer=nn.LayerNorm, patch_norm=True,
                 use_checkpoint=False):

        super(T_S_TransformerIR, self).__init__()
        num_in_ch = in_chans
        num_out_ch = in_chans
        self.window_size = window_size  # 8

        # feature extraction
        self.conv_first1 = nn.Conv3d(num_in_ch, embed_dim // 4, (1, 1, 1), (1, 1, 1), (0, 0, 0))  # in 1 out 48
        self.conv_first2 = nn.Conv3d(embed_dim // 4, embed_dim // 2, (1, 4, 4), (1, 2, 2), (0, 1, 1))  # in 1 out 48
        self.conv_first3 = nn.Conv3d(embed_dim // 2, embed_dim, (1, 4, 4), (1, 2, 2), (0, 1, 1))  # in 1 out 48
        self.conv_first4 = nn.Conv3d(embed_dim, embed_dim * 2, (1, 4, 4), (1, 2, 2), (0, 1, 1))  # in 1 out 48
        self.conv1 = nn.Sequential(
            nn.Conv3d(embed_dim // 4, embed_dim // 2, kernel_size=(1, 4, 4), stride=(1, 2, 2), padding=(0, 1, 1), bias=True),
            nn.InstanceNorm3d(embed_dim // 2),
            nn.LeakyReLU(0.2, False),
            nn.Conv3d(embed_dim // 2, embed_dim // 2, (1, 3, 3), (1, 1, 1), (0, 1, 1)),
            nn.InstanceNorm3d(embed_dim // 2),
            nn.LeakyReLU(0.2, False)
        )
        self.conv2 = nn.Sequential(
            nn.Conv3d(embed_dim // 2, embed_dim, kernel_size=(1, 4, 4), stride=(1, 2, 2), padding=(0, 1, 1), bias=True),
            nn.InstanceNorm3d(embed_dim),
            nn.LeakyReLU(0.2, False),
            nn.Conv3d(embed_dim,embed_dim, (1, 3, 3), (1, 1, 1), (0, 1, 1)),
            nn.InstanceNorm3d(embed_dim),
            nn.LeakyReLU(0.2, False)
        )
        self.conv3 = nn.Sequential(
            nn.Conv3d(embed_dim, embed_dim * 2, kernel_size=(1, 4, 4), stride=(1, 2, 2), padding=(0, 1, 1), bias=True),
            nn.InstanceNorm3d(embed_dim * 2),
            nn.LeakyReLU(0.2, False),
            nn.Conv3d(embed_dim * 2,embed_dim * 2, (1, 3, 3), (1, 1, 1), (0, 1, 1)),
            nn.InstanceNorm3d(embed_dim * 2),
            nn.LeakyReLU(0.2, False)
        )

        self.num_layers = len(depths)  # [4]
        self.embed_dim = embed_dim  # 48
        self.patch_norm = patch_norm  # True
        self.num_features = embed_dim  # 48
        self.mlp_ratio = mlp_ratio  # 4

        # split image into non-overlapping patches
        self.patch_embed0 = PatchEmbed(embed_dim=embed_dim // 2)
        self.patch_embed1 = PatchEmbed(embed_dim=embed_dim)
        self.patch_embed2 = PatchEmbed(embed_dim=embed_dim * 2)

        # merge non-overlapping patches into image
        self.patch_unembed0 = PatchUnEmbed(embed_dim=embed_dim // 2)
        self.patch_unembed1 = PatchUnEmbed(embed_dim=embed_dim)
        self.patch_unembed2 = PatchUnEmbed(embed_dim=embed_dim * 2)
        
        self.pos_drop0 = nn.Dropout(p=drop_rate)
        self.pos_drop1 = nn.Dropout(p=drop_rate)
        self.pos_drop2 = nn.Dropout(p=drop_rate)

        # stochastic depth
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule

        # build Residual Swin Transformer blocks (RSTB)
        self.layers0 = nn.ModuleList()
        self.layers1 = nn.ModuleList()
        self.layers2 = nn.ModuleList()
        for i_layer in range(self.num_layers):
            layer0 = RSTB(dim=embed_dim // 2,
                         input_resolution=input_resolution0,
                         depth=depths[i_layer],
                         num_heads=num_heads[i_layer],
                         window_size=window_size,
                         mlp_ratio=self.mlp_ratio,
                         qkv_bias=qkv_bias, qk_scale=qk_scale,
                         drop=drop_rate, attn_drop=attn_drop_rate,
                         drop_path=dpr[sum(depths[:i_layer]):sum(depths[:i_layer + 1])],  # no impact on SR results
                         norm_layer=norm_layer,
                         downsample=None,
                         use_checkpoint=use_checkpoint
                         )
            self.layers0.append(layer0)
        for i_layer in range(self.num_layers):
            layer1 = RSTB(dim=embed_dim,
                         input_resolution=input_resolution1,
                         depth=depths[i_layer],
                         num_heads=num_heads[i_layer],
                         window_size=window_size,
                         mlp_ratio=self.mlp_ratio,
                         qkv_bias=qkv_bias, qk_scale=qk_scale,
                         drop=drop_rate, attn_drop=attn_drop_rate,
                         drop_path=dpr[sum(depths[:i_layer]):sum(depths[:i_layer + 1])],  # no impact on SR results
                         norm_layer=norm_layer,
                         downsample=None,
                         use_checkpoint=use_checkpoint
                         )
            self.layers1.append(layer1)
        
        self.norm0 = norm_layer(embed_dim // 2)
        self.norm1 = norm_layer(embed_dim)
        self.norm2 = norm_layer(embed_dim * 2)
        self.conv_after_body0 = nn.Conv3d(embed_dim // 2, embed_dim // 2, (1, 3, 3), (1, 1, 1), (0, 1, 1))  # in 1 out 48
        self.conv_after_body1 = nn.Conv3d(embed_dim, embed_dim, (1, 3, 3), (1, 1, 1), (0, 1, 1))  # in 1 out 48
        self.conv_after_body2 = nn.Conv3d(embed_dim * 2, embed_dim * 2, (1, 3, 3), (1, 1, 1), (0, 1, 1))  # in 1 out 48
        
        self.up0 = nn.Upsample(scale_factor=(1, 2, 2), mode='trilinear', align_corners=True)
        self.up_conv0 =  nn.Sequential(
            nn.Conv3d(embed_dim * 2, embed_dim, (1, 3, 3), (1, 1, 1), (0, 1, 1)),
            nn.InstanceNorm3d(embed_dim),
            nn.LeakyReLU(0.2, False),
            nn.Conv3d(embed_dim, embed_dim, (1, 3, 3), (1, 1, 1), (0, 1, 1)),
            nn.InstanceNorm3d(embed_dim),
            nn.LeakyReLU(0.2, False))
        
        self.up1 = nn.Upsample(scale_factor=(1, 2, 2), mode='trilinear', align_corners=True)
        self.up_conv1 =  nn.Sequential(
            nn.Conv3d(embed_dim, embed_dim // 2, (1, 3, 3), (1, 1, 1), (0, 1, 1)),
            nn.InstanceNorm3d(embed_dim // 2),
            nn.LeakyReLU(0.2, False),
            nn.Conv3d(embed_dim // 2, embed_dim // 2, (1, 3, 3), (1, 1, 1), (0, 1, 1)),
            nn.InstanceNorm3d(embed_dim // 2),
            nn.LeakyReLU(0.2, False))
        self.up2 = nn.Upsample(scale_factor=(1, 2, 2), mode='trilinear', align_corners=True)
        self.up_conv2 =nn.Sequential(
            nn.Conv3d(embed_dim // 2, embed_dim // 4, (1, 3, 3), (1, 1, 1), (0, 1, 1)),
            nn.InstanceNorm3d(embed_dim // 4),
            nn.LeakyReLU(0.2, False),
            nn.Conv3d(embed_dim // 4, embed_dim // 4, (1, 3, 3), (1, 1, 1), (0, 1, 1)),
            nn.InstanceNorm3d(embed_dim // 4),
            nn.LeakyReLU(0.2, False))
        self.conv_last0 = nn.ConvTranspose3d(embed_dim * 2, embed_dim, (1, 4, 4), (1, 2, 2), (0, 1, 1))  # in 1 out 48
        self.conv_last1 = nn.ConvTranspose3d(embed_dim, embed_dim // 2, (1, 4, 4), (1, 2, 2), (0, 1, 1))  # in 1 out 48
        self.conv_last2 = nn.ConvTranspose3d(embed_dim // 2, embed_dim // 4, (1, 4, 4), (1, 2, 2), (0, 1, 1))  # in 1 out 48
        
        self.output = nn.Conv3d(embed_dim // 4, num_out_ch, kernel_size=(1, 1, 1))

        self.apply(self._init_weights)

    def forward(self, x):
        return self.double_conv(x)
    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    @torch.jit.ignore
    def no_weight_decay(self):
        return {'absolute_pos_embed'}

    @torch.jit.ignore
    def no_weight_decay_keywords(self):
        return {'relative_position_bias_table'}
    
    
    def forward_features0(self, x):
        x_size = (x.shape[2], x.shape[3], x.shape[4])
        x = self.patch_embed0(x)
        x = self.pos_drop0(x)

        for layer in self.layers0:
            x1, attn_S, attn_T = layer(x, x_size)

        x1 = self.norm0(x1)
        x1 = self.patch_unembed0(x1, x_size)
        return x1, attn_S, attn_T

    def forward_features1(self, x):
        x_size = (x.shape[2], x.shape[3], x.shape[4])
        x = self.patch_embed1(x)
        x = self.pos_drop1(x)

        for layer in self.layers1:
            x1, attn_S, attn_T = layer(x, x_size)

        x1 = self.norm1(x1)
        x1 = self.patch_unembed1(x1, x_size)
        return x1, attn_S, attn_T
        
    def forward(self, x):
        x_first = self.conv_first1(x)
        x_first = self.conv_first2(x_first)
        #x_2, _, _ = self.forward_features0(x_first)
        #res1 = self.conv_after_body0(x_2) + x_first
        x_first = self.conv_first3(x_first)
        #x_1 = self.conv1(x_first)
        #x_2 = self.conv2(x_1)
        x_3, attn_S, attn_T = self.forward_features1(x_first) 
        res1 = self.conv_after_body1(x_3) + x_first
        #res1 = self.conv_first4(res1)
        
        #res1 = self.conv3(res1)
        
        #x_4, _, _ = self.forward_features2(res1)
        #res2 = self.conv_after_body2(x_4) + res1
        #x_out = self.conv_last0(res2)
        #x_out = self.up0(res2)
        #x_out = self.up_conv0(x_out)
        x_out = self.conv_last1(res1)
        x_out = self.conv_last2(x_out)
        #x_out = self.up1(res1)
        #x_out = self.up_conv1(x_out)
        #x_out = self.up2(x_out)
        #x_out = self.up_conv2(x_out)
        
        x_out = x + self.output(x_out)

        return x_out, attn_S, attn_T

