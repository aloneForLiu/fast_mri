from Image.AttU_Net import *
import numpy as np


class ImageNet(nn.Module):
    def __init__(self, n_channels=None, n_classes=None):
        super(ImageNet, self).__init__()
        filters = np.array([24, 48, 96, 192, 384])
        self.n_channels = n_channels
        self.n_classes = n_classes

        self.Conv1 = conv_block(ch_in=n_channels, ch_out=filters[0])
        self.Conv2 = poolconv_block(ch_in=filters[0], ch_out=filters[1])
        self.Conv3 = poolconv_block(ch_in=filters[1], ch_out=filters[2])
        self.Conv4 = poolconv_block(ch_in=filters[2], ch_out=filters[3])
        self.Conv5 = poolconv_block(ch_in=filters[3], ch_out=filters[4])

        self.Up5 = up_conv(ch_in=filters[4], ch_out=filters[3])
        self.Up_conv5 = upconv_block(ch_in=filters[4], ch_out=filters[3])

        self.Up4 = up_conv(ch_in=filters[3], ch_out=filters[2])
        self.Up_conv4 = upconv_block(ch_in=filters[3], ch_out=filters[2])

        self.Up3 = up_conv(ch_in=filters[2], ch_out=filters[1])
        self.Up_conv3 = upconv_block(ch_in=filters[2], ch_out=filters[1])

        self.Up2 = up_conv(ch_in=filters[1], ch_out=filters[0])
        self.Up_conv2 = upconv_block(ch_in=filters[1], ch_out=filters[0])

        self.Conv_1x1 = Conv1x1(filters[0], n_classes)

    def forward(self, x):
        # encoding path
        x1 = self.Conv1(x)
        x2 = self.Conv2(x1)
        x3 = self.Conv3(x2)
        x4 = self.Conv4(x3)
        x5 = self.Conv5(x4)
        d5 = self.Up5(x5)
        d5 = torch.cat((x4, d5), 1)
        d5 = self.Up_conv5(d5)
        d4 = self.Up4(d5)
        d4 = torch.cat((x3, d4), 1)
        d4 = self.Up_conv4(d4)
        d3 = self.Up3(d4)
        d3 = torch.cat((x2, d3), 1)
        d3 = self.Up_conv3(d3)
        d2 = self.Up2(d3)
        d2 = torch.cat((x1, d2), 1)
        d2 = self.Up_conv2(d2)
        d1 = self.Conv_1x1(d2)

        return d1


class SensitivityNet(nn.Module):
    def __init__(self, n_channels=None, n_classes=None, scale_factor=None):
        super(SensitivityNet, self).__init__()
        filters = np.array([128, 256, 512, 1024, 2048])
        filters = filters // scale_factor
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.scale_factor = scale_factor

        self.Conv1 = conv_block(ch_in=n_channels, ch_out=filters[0])
        self.Conv2 = poolconv_block(ch_in=filters[0], ch_out=filters[1])
        self.Conv3 = poolconv_block(ch_in=filters[1], ch_out=filters[2])
        self.Conv4 = poolconv_block(ch_in=filters[2], ch_out=filters[3])
        self.Conv5 = poolconv_block(ch_in=filters[3], ch_out=filters[4])

        self.Up5 = up_conv(ch_in=filters[4], ch_out=filters[3])
        self.Up_conv5 = upconv_block(ch_in=filters[4], ch_out=filters[3])

        self.Up4 = up_conv(ch_in=filters[3], ch_out=filters[2])
        self.Up_conv4 = upconv_block(ch_in=filters[3], ch_out=filters[2])

        self.Up3 = up_conv(ch_in=filters[2], ch_out=filters[1])
        self.Up_conv3 = upconv_block(ch_in=filters[2], ch_out=filters[1])

        self.Up2 = up_conv(ch_in=filters[1], ch_out=filters[0])
        self.Up_conv2 = upconv_block(ch_in=filters[1], ch_out=filters[0])

        self.Conv_1x1 = Conv1x1(filters[0], n_classes)

    def forward(self, x):
        # encoding path
        x1 = self.Conv1(x)
        x2 = self.Conv2(x1)
        x3 = self.Conv3(x2)
        x4 = self.Conv4(x3)
        x5 = self.Conv5(x4)
        d5 = self.Up5(x5)
        d5 = torch.cat((x4, d5), 1)
        d5 = self.Up_conv5(d5)
        d4 = self.Up4(d5)
        d4 = torch.cat((x3, d4), 1)
        d4 = self.Up_conv4(d4)
        d3 = self.Up3(d4)
        d3 = torch.cat((x2, d3), 1)
        d3 = self.Up_conv3(d3)
        d2 = self.Up2(d3)
        d2 = torch.cat((x1, d2), 1)
        d2 = self.Up_conv2(d2)
        d1 = self.Conv_1x1(d2)

        return d1

class i_change_channel(nn.Module):
    def __init__(self, in_channel=None, out_channel=None):
        super(i_change_channel, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.convfirst = Convfirst(self.in_channel, self.out_channel)
        self.convlast = Convlast(self.out_channel, self.in_channel)

    def forward(self, x1=None, x2=None):
        if x1 is not None:
            x1 = self.convfirst(x1)
        if x2 is not None:
            x2 = self.convlast(x2)

        return x1, x2