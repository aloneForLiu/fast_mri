import dicom2nifti
import cv2 as cv
import numpy as np
import pydicom
import os
import nibabel as nib
from matplotlib import pyplot
import SimpleITK as sitk
import PIL.Image as img
import math

Number_1_path_PDW = '/data/liuyx/dicom/MTP_ZZJ_20230110-095120-1975_095236/gre_mtp_full_MTP_PDW_203/'
Number_2_path_PDW = '/data/liuyx/dicom/MTP_ZZH_20230111-090408-1990_090439/gre_mtp_full_MTP_PDW_203/'
Number_3_path_PDW = '/data/liuyx/dicom/MTP_ZJD_20230109-093724-1950_093807/gre_mtp_full_MTP_PDW_203/'
Number_4_path_PDW = '/data/liuyx/dicom/MTP_ZHZ_20230110-090509-1973_090811/gre_mtp_full_MTP_PDW_203/'
Number_5_path_PDW = '/data/liuyx/dicom/MTP_ZHN_20221117-140811-1698_140844/gre_mtp_full_MTP_PDW_203/'
Number_6_path_PDW = '/data/liuyx/dicom/MTP_YJW_20230110-101405-1976_101507/gre_mtp_full_MTP_PDW_203/'
Number_7_path_PDW = '/data/liuyx/dicom/MTP_XJL_20221117-134620-1697_134648/gre_mtp_full_MTP_PDW_203/'
Number_8_path_PDW = '/data/liuyx/dicom/MTP_SYH_20230110-110151-1978_110213/gre_mtp_full_MTP_PDW_203/'
Number_9_path_PDW = '/data/liuyx/dicom/MTP_OZX_20230109-102759-1952_102829/gre_mtp_full_MTP_PDW_203/'
Number_10_path_PDW = '/data/liuyx/dicom/MTP_MMC_20230109-090721-1949_091120/gre_mtp_full_MTP_PDW_203/'
Number_11_path_PDW = '/data/liuyx/dicom/MTP_LZF_20230111-093017-1991_093049/gre_mtp_full_MTP_PDW_203/'
Number_12_path_PDW = '/data/liuyx/dicom/MTP_LYX_20230109-100023-1951_100048/gre_mtp_full_MTP_PDW_203/'
Number_13_path_PDW = '/data/liuyx/dicom/MTP_LJM_20230110-103644-1977_103704/gre_mtp_full_MTP_PDW_203/'
Number_14_path_PDW = '/data/liuyx/dicom/MTP_LDD_20230111-095231-1992_095302/gre_mtp_full_MTP_PDW_203/'
Number_15_path_PDW = '/data/liuyx/dicom/MTP_HQY_20230109-110824-1955_110846/gre_mtp_full_MTP_PDW_203/'
Number_16_path_PDW = '/data/liuyx/dicom/MTP_GYN_20230110-092935-1974_092957/gre_mtp_full_MTP_PDW_203/'
Number_17_path_PDW = '/data/liuyx/dicom/MTP_GJC_20230109-104652-1953_104714/gre_mtp_full_MTP_PDW_203/'
Number_18_path_PDW = '/data/liuyx/dicom/MTP_CYX_20221117-131705-1696_131736/gre_mtp_full_MTP_PDW_203/'


Number_1_path_T1W = '/data/liuyx/dicom/MTP_ZZJ_20230110-095120-1975_095236/gre_mtp_full_MTP_T1W_204/'
Number_2_path_T1W = '/data/liuyx/dicom/MTP_ZZH_20230111-090408-1990_090439/gre_mtp_full_MTP_T1W_204/'
Number_3_path_T1W = '/data/liuyx/dicom/MTP_ZJD_20230109-093724-1950_093807/gre_mtp_full_MTP_T1W_204/'
Number_4_path_T1W = '/data/liuyx/dicom/MTP_ZHZ_20230110-090509-1973_090811/gre_mtp_full_MTP_T1W_204/'
Number_5_path_T1W = '/data/liuyx/dicom/MTP_ZHN_20221117-140811-1698_140844/gre_mtp_full_MTP_T1W_204/'
Number_6_path_T1W = '/data/liuyx/dicom/MTP_YJW_20230110-101405-1976_101507/gre_mtp_full_MTP_T1W_204/'
Number_7_path_T1W = '/data/liuyx/dicom/MTP_XJL_20221117-134620-1697_134648/gre_mtp_full_MTP_T1W_204/'
Number_8_path_T1W = '/data/liuyx/dicom/MTP_SYH_20230110-110151-1978_110213/gre_mtp_full_MTP_T1W_204/'
Number_9_path_T1W = '/data/liuyx/dicom/MTP_OZX_20230109-102759-1952_102829/gre_mtp_full_MTP_T1W_204/'
Number_10_path_T1W = '/data/liuyx/dicom/MTP_MMC_20230109-090721-1949_091120/gre_mtp_full_MTP_T1W_204/'
Number_11_path_T1W = '/data/liuyx/dicom/MTP_LZF_20230111-093017-1991_093049/gre_mtp_full_MTP_T1W_204/'
Number_12_path_T1W = '/data/liuyx/dicom/MTP_LYX_20230109-100023-1951_100048/gre_mtp_full_MTP_T1W_204/'
Number_13_path_T1W = '/data/liuyx/dicom/MTP_LJM_20230110-103644-1977_103704/gre_mtp_full_MTP_T1W_204/'
Number_14_path_T1W = '/data/liuyx/dicom/MTP_LDD_20230111-095231-1992_095302/gre_mtp_full_MTP_T1W_204/'
Number_15_path_T1W = '/data/liuyx/dicom/MTP_HQY_20230109-110824-1955_110846/gre_mtp_full_MTP_T1W_204/'
Number_16_path_T1W = '/data/liuyx/dicom/MTP_GYN_20230110-092935-1974_092957/gre_mtp_full_MTP_T1W_204/'
Number_17_path_T1W = '/data/liuyx/dicom/MTP_GJC_20230109-104652-1953_104714/gre_mtp_full_MTP_T1W_204/'
Number_18_path_T1W = '/data/liuyx/dicom/MTP_CYX_20221117-131705-1696_131736/gre_mtp_full_MTP_T1W_204/'

Number_1_path = '/data/liuyx/zzj/'
Number_2_path = '/data/liuyx/zzh/'
Number_3_path = '/data/liuyx/zjd/'
Number_4_path = '/data/liuyx/zhz/'
Number_5_path = '/data/liuyx/zhn/'
Number_6_path = '/data/liuyx/yjw/'
Number_7_path = '/data/liuyx/xjl/'
Number_8_path = '/data/liuyx/syh/'
Number_9_path = '/data/liuyx/ozx/'
Number_10_path = '/data/liuyx/mmc/'
Number_11_path = '/data/liuyx/lzf/'
Number_12_path = '/data/liuyx/lyx/'
Number_13_path = '/data/liuyx/ljm/'
Number_14_path = '/data/liuyx/ldd/'
Number_15_path = '/data/liuyx/hqy/'
Number_16_path = '/data/liuyx/gyn/'
Number_17_path = '/data/liuyx/gjc/'
Number_18_path = '/data/liuyx/cyx/'


Number_1_path_T2S = '/data/liuyx/dicom/MTP_ZZJ_20230110-095120-1975_095236/gre_mtp_full_MTP_T2Star_207/'
Number_2_path_T2S = '/data/liuyx/dicom/MTP_ZZH_20230111-090408-1990_090439/gre_mtp_full_MTP_T2Star_207/'
Number_3_path_T2S = '/data/liuyx/dicom/MTP_ZJD_20230109-093724-1950_093807/gre_mtp_full_MTP_T2Star_207/'
Number_4_path_T2S = '/data/liuyx/dicom/MTP_ZHZ_20230110-090509-1973_090811/gre_mtp_full_MTP_T2Star_207/'
Number_5_path_T2S = '/data/liuyx/dicom/MTP_ZHN_20221117-140811-1698_140844/gre_mtp_full_MTP_T2Star_207/'
Number_6_path_T2S = '/data/liuyx/dicom/MTP_YJW_20230110-101405-1976_101507/gre_mtp_full_MTP_T2Star_207/'
Number_7_path_T2S = '/data/liuyx/dicom/MTP_XJL_20221117-134620-1697_134648/gre_mtp_full_MTP_T2Star_207/'
Number_8_path_T2S = '/data/liuyx/dicom/MTP_SYH_20230110-110151-1978_110213/gre_mtp_full_MTP_T2Star_207/'
Number_9_path_T2S = '/data/liuyx/dicom/MTP_OZX_20230109-102759-1952_102829/gre_mtp_full_MTP_T2Star_207/'
Number_10_path_T2S = '/data/liuyx/dicom/MTP_MMC_20230109-090721-1949_091120/gre_mtp_full_MTP_T2Star_207/'
Number_11_path_T2S = '/data/liuyx/dicom/MTP_LZF_20230111-093017-1991_093049/gre_mtp_full_MTP_T2Star_207/'
Number_12_path_T2S = '/data/liuyx/dicom/MTP_LYX_20230109-100023-1951_100048/gre_mtp_full_MTP_T2Star_207/'
Number_13_path_T2S = '/data/liuyx/dicom/MTP_LJM_20230110-103644-1977_103704/gre_mtp_full_MTP_T2Star_207/'
Number_14_path_T2S = '/data/liuyx/dicom/MTP_LDD_20230111-095231-1992_095302/gre_mtp_full_MTP_T2Star_207/'
Number_15_path_T2S = '/data/liuyx/dicom/MTP_HQY_20230109-110824-1955_110846/gre_mtp_full_MTP_T2Star_207/'
Number_16_path_T2S = '/data/liuyx/dicom/MTP_GYN_20230110-092935-1974_092957/gre_mtp_full_MTP_T2Star_207/'
Number_17_path_T2S = '/data/liuyx/dicom/MTP_GJC_20230109-104652-1953_104714/gre_mtp_full_MTP_T2Star_207/'
Number_18_path_T2S = '/data/liuyx/dicom/MTP_CYX_20221117-131705-1696_131736/gre_mtp_full_MTP_T2Star_207/'


Number_1_path_PDMap = '/data/liuyx/dicom/MTP_ZZJ_20230110-095120-1975_095236/gre_mtp_full_MTP_PDMap_205/'
Number_2_path_PDMap = '/data/liuyx/dicom/MTP_ZZH_20230111-090408-1990_090439/gre_mtp_full_MTP_PDMap_205/'
Number_3_path_PDMap = '/data/liuyx/dicom/MTP_ZJD_20230109-093724-1950_093807/gre_mtp_full_MTP_PDMap_205/'
Number_4_path_PDMap = '/data/liuyx/dicom/MTP_ZHZ_20230110-090509-1973_090811/gre_mtp_full_MTP_PDMap_205/'
Number_5_path_PDMap = '/data/liuyx/dicom/MTP_ZHN_20221117-140811-1698_140844/gre_mtp_full_MTP_PDMap_205/'
Number_6_path_PDMap = '/data/liuyx/dicom/MTP_YJW_20230110-101405-1976_101507/gre_mtp_full_MTP_PDMap_205/'
Number_7_path_PDMap = '/data/liuyx/dicom/MTP_XJL_20221117-134620-1697_134648/gre_mtp_full_MTP_PDMap_205/'
Number_8_path_PDMap = '/data/liuyx/dicom/MTP_SYH_20230110-110151-1978_110213/gre_mtp_full_MTP_PDMap_205/'
Number_9_path_PDMap = '/data/liuyx/dicom/MTP_OZX_20230109-102759-1952_102829/gre_mtp_full_MTP_PDMap_205/'
Number_10_path_PDMap = '/data/liuyx/dicom/MTP_MMC_20230109-090721-1949_091120/gre_mtp_full_MTP_PDMap_205/'
Number_11_path_PDMap = '/data/liuyx/dicom/MTP_LZF_20230111-093017-1991_093049/gre_mtp_full_MTP_PDMap_205/'
Number_12_path_PDMap = '/data/liuyx/dicom/MTP_LYX_20230109-100023-1951_100048/gre_mtp_full_MTP_PDMap_205/'
Number_13_path_PDMap = '/data/liuyx/dicom/MTP_LJM_20230110-103644-1977_103704/gre_mtp_full_MTP_PDMap_205/'
Number_14_path_PDMap = '/data/liuyx/dicom/MTP_LDD_20230111-095231-1992_095302/gre_mtp_full_MTP_PDMap_205/'
Number_15_path_PDMap = '/data/liuyx/dicom/MTP_HQY_20230109-110824-1955_110846/gre_mtp_full_MTP_PDMap_205/'
Number_16_path_PDMap = '/data/liuyx/dicom/MTP_GYN_20230110-092935-1974_092957/gre_mtp_full_MTP_PDMap_205/'
Number_17_path_PDMap = '/data/liuyx/dicom/MTP_GJC_20230109-104652-1953_104714/gre_mtp_full_MTP_PDMap_205/'
Number_18_path_PDMap = '/data/liuyx/dicom/MTP_CYX_20221117-131705-1696_131736/gre_mtp_full_MTP_PDMap_205/'


Number_1_path_T1Map = '/data/liuyx/dicom/MTP_ZZJ_20230110-095120-1975_095236/gre_mtp_full_MTP_T1Map_201/'
Number_2_path_T1Map = '/data/liuyx/dicom/MTP_ZZH_20230111-090408-1990_090439/gre_mtp_full_MTP_T1Map_201/'
Number_3_path_T1Map = '/data/liuyx/dicom/MTP_ZJD_20230109-093724-1950_093807/gre_mtp_full_MTP_T1Map_201/'
Number_4_path_T1Map = '/data/liuyx/dicom/MTP_ZHZ_20230110-090509-1973_090811/gre_mtp_full_MTP_T1Map_201/'
Number_5_path_T1Map = '/data/liuyx/dicom/MTP_ZHN_20221117-140811-1698_140844/gre_mtp_full_MTP_T1Map_201/'
Number_6_path_T1Map = '/data/liuyx/dicom/MTP_YJW_20230110-101405-1976_101507/gre_mtp_full_MTP_T1Map_201/'
Number_7_path_T1Map = '/data/liuyx/dicom/MTP_XJL_20221117-134620-1697_134648/gre_mtp_full_MTP_T1Map_201/'
Number_8_path_T1Map = '/data/liuyx/dicom/MTP_SYH_20230110-110151-1978_110213/gre_mtp_full_MTP_T1Map_201/'
Number_9_path_T1Map = '/data/liuyx/dicom/MTP_OZX_20230109-102759-1952_102829/gre_mtp_full_MTP_T1Map_201/'
Number_10_path_T1Map = '/data/liuyx/dicom/MTP_MMC_20230109-090721-1949_091120/gre_mtp_full_MTP_T1Map_201/'
Number_11_path_T1Map = '/data/liuyx/dicom/MTP_LZF_20230111-093017-1991_093049/gre_mtp_full_MTP_T1Map_201/'
Number_12_path_T1Map = '/data/liuyx/dicom/MTP_LYX_20230109-100023-1951_100048/gre_mtp_full_MTP_T1Map_201'
Number_13_path_T1Map = '/data/liuyx/dicom/MTP_LJM_20230110-103644-1977_103704/gre_mtp_full_MTP_T1Map_201/'
Number_14_path_T1Map = '/data/liuyx/dicom/MTP_LDD_20230111-095231-1992_095302/gre_mtp_full_MTP_T1Map_201/'
Number_15_path_T1Map = '/data/liuyx/dicom/MTP_HQY_20230109-110824-1955_110846/gre_mtp_full_MTP_T1Map_201/'
Number_16_path_T1Map = '/data/liuyx/dicom/MTP_GYN_20230110-092935-1974_092957/gre_mtp_full_MTP_T1Map_201/'
Number_17_path_T1Map = '/data/liuyx/dicom/MTP_GJC_20230109-104652-1953_104714/gre_mtp_full_MTP_T1Map_201/'
Number_18_path_T1Map = '/data/liuyx/dicom/MTP_CYX_20221117-131705-1696_131736/gre_mtp_full_MTP_T1Map_201/'


Number_1_PDW_dicom_GT = '/home/liuyx/fast reconstruction of multi-contrast MRI/get_vd_mask/New_Dataset/PDW_dicom_GT/'
Number_1_T1W_dicom_GT = '/home/liuyx/fast reconstruction of multi-contrast MRI/get_vd_mask/New_Dataset/T1W_dicom_GT/'
Number_1_T2S_dicom_GT = '/home/liuyx/fast reconstruction of multi-contrast MRI/get_vd_mask/New_Dataset/T2S_dicom_GT/'
Number_1_PDMap_dicom_GT = '/home/liuyx/fast reconstruction of multi-contrast MRI/get_vd_mask/New_Dataset/PDM_dicom_GT/'
Number_1_T1Map_dicom_GT = '/home/liuyx/fast reconstruction of multi-contrast MRI/get_vd_mask/New_Dataset/T1M_dicom_GT/'
# Number_1_QSM_dicom_GT = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/QSM_dicom_GT/'

Number_1_raw_affine = [[0.823, 0, 0, -97.34],
                  [0, 0.823, 0, -124.4],
                  [0, 0, 2, -51.66],
                  [0, 0, 0, 1]]

Number_2_raw_affine = [[0.823, 0, 0, -94.42],
                  [0, 0.823, 0, -131],
                  [0, 0, 2, -40.91],
                  [0, 0, 0, 1]]

Number_3_raw_affine = [[0.823, 0, 0, -93.61],
                  [0, 0.823, 0, -122.7],
                  [0, 0, 2, -43.82],
                  [0, 0, 0, 1]]

Number_4_raw_affine = [[0.823, 0, 0, -92.63],
                  [0, 0.823, 0, -124.7],
                  [0, 0, 2, -28.46],
                  [0, 0, 0, 1]]

Number_5_raw_affine = [[0.823, 0, 0, -96.27],
                  [0, 0.823, 0, -124.7],
                  [0, 0, 2, -44.6],
                  [0, 0, 0, 1]]

Number_6_raw_affine = [[0.823, 0, 0, -78.96],
                  [0, 0.823, 0, -128.5],
                  [0, 0, 2, -34.98],
                  [0, 0, 0, 1]]

Number_7_raw_affine = [[0.823, 0, 0, -106.3],
                  [0, 0.823, 0, -112.3],
                  [0, 0, 2, -49.06],
                  [0, 0, 0, 1]]

Number_8_raw_affine = [[0.823, 0, 0, -89.11],
                  [0, 0.823, 0, -120.9],
                  [0, 0, 2, -48.24],
                  [0, 0, 0, 1]]

Number_9_raw_affine = [[0.823, 0, 0, -105.6],
                  [0, 0.823, 0, -119.9],
                  [0, 0, 2, -45.93],
                  [0, 0, 0, 1]]

Number_10_raw_affine = [[0.823, 0, 0, -89.39],
                  [0, 0.823, 0, -131.9],
                  [0, 0, 2, -33.69],
                  [0, 0, 0, 1]]

Number_11_raw_affine = [[0.823, 0, 0, -96.35],
                  [0, 0.823, 0, -122.4],
                  [0, 0, 2, -32.15],
                  [0, 0, 0, 1]]

Number_12_raw_affine = [[0.823, 0, 0, -88.38],
                  [0, 0.823, 0, -129.8],
                  [0, 0, 2, -35.9],
                  [0, 0, 0, 1]]

Number_13_raw_affine = [[0.823, 0, 0, -86],
                  [0, 0.823, 0, -128],
                  [0, 0, 2, -33.52],
                  [0, 0, 0, 1]]

Number_14_raw_affine = [[0.823, 0, 0, -101],
                  [0, 0.823, 0, -121.2],
                  [0, 0, 2, -40.45],
                  [0, 0, 0, 1]]

Number_15_raw_affine = [[0.823, 0, 0, -92.41],
                  [0, 0.823, 0, -131.2],
                  [0, 0, 2, -37.82],
                  [0, 0, 0, 1]]

Number_16_raw_affine = [[0.823, 0, 0, -95.87],
                  [0, 0.823, 0, -125],
                  [0, 0, 2, -44.51],
                  [0, 0, 0, 1]]

Number_17_raw_affine = [[0.823, 0, 0, -91.93],
                  [0, 0.823, 0, -129.9],
                  [0, 0, 2, -41.69],
                  [0, 0, 0, 1]]

Number_18_raw_affine = [[0.823, 0, 0, -97.76],
                  [0, 0.823, 0, -135.2],
                  [0, 0, 2, -39.29],
                  [0, 0, 0, 1]]


GT_path = [Number_1_path, Number_2_path, Number_3_path, Number_4_path, Number_5_path, Number_6_path, Number_7_path, Number_8_path, Number_9_path, Number_10_path, Number_11_path, Number_12_path,
               Number_13_path, Number_14_path, Number_15_path, Number_16_path, Number_17_path, Number_18_path]

# PDW_GT_path = [Number_1_path, Number_2_path, Number_3_path, Number_4_path]
# PDW_GT_path = [Number_6_path_PDW]
# PDW_save_path = [Number_1_PDW_dicom_GT]
# T1W_GT_path = [Number_6_path_T1W]
# T1W_save_path = [Number_1_T1W_dicom_GT]
# T2S_GT_path = [Number_6_path_T2S]
# T2S_save_path = [Number_1_T2S_dicom_GT]
# PDMap_GT_path = [Number_6_path_PDMap]
# PDMap_save_path = [Number_1_PDMap_dicom_GT]
# T1Map_GT_path = [Number_6_path_T1Map]
# T1Map_save_path = [Number_1_T1Map_dicom_GT]
# raw_affine_list = [Number_6_raw_affine]
# PDW_save_path = [Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT]
#
# T1W_GT_path = [Number_1_path, Number_2_path, Number_3_path, Number_4_path]
# T1W_save_path = [Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT]
#
# raw_affine_list = [Number_1_raw_affine, Number_2_raw_affine, Number_3_raw_affine, Number_4_raw_affine]

PDW_GT_path = [Number_1_path_PDW, Number_2_path_PDW, Number_3_path_PDW, Number_4_path_PDW, Number_5_path_PDW, Number_6_path_PDW, Number_7_path_PDW, Number_8_path_PDW, Number_9_path_PDW, Number_10_path_PDW, Number_11_path_PDW, Number_12_path_PDW,
               Number_13_path_PDW, Number_14_path_PDW, Number_15_path_PDW, Number_16_path_PDW, Number_17_path_PDW, Number_18_path_PDW]
PDW_save_path = [Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT,
                 Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT,
                 Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT]

T1W_GT_path = [Number_1_path_T1W, Number_2_path_T1W, Number_3_path_T1W, Number_4_path_T1W, Number_5_path_T1W, Number_6_path_T1W, Number_7_path_T1W, Number_8_path_T1W, Number_9_path_T1W, Number_10_path_T1W, Number_11_path_T1W, Number_12_path_T1W,
               Number_13_path_T1W, Number_14_path_T1W, Number_15_path_T1W, Number_16_path_T1W, Number_17_path_T1W, Number_18_path_T1W]
T1W_save_path = [Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT,
                 Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT,
                 Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT]

T2S_GT_path = [Number_1_path_T2S, Number_2_path_T2S, Number_3_path_T2S, Number_4_path_T2S, Number_5_path_T2S, Number_6_path_T2S, Number_7_path_T2S, Number_8_path_T2S, Number_9_path_T2S, Number_10_path_T2S, Number_11_path_T2S, Number_12_path_T2S,
               Number_13_path_T2S, Number_14_path_T2S, Number_15_path_T2S, Number_16_path_T2S, Number_17_path_T2S, Number_18_path_T2S]
T2S_save_path = [Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT,
                 Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT,
                 Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT]

PDMap_GT_path = [Number_1_path_PDMap, Number_2_path_PDMap, Number_3_path_PDMap, Number_4_path_PDMap, Number_5_path_PDMap, Number_6_path_PDMap, Number_7_path_PDMap, Number_8_path_PDMap, Number_9_path_PDMap, Number_10_path_PDMap,
                 Number_11_path_PDMap, Number_12_path_PDMap, Number_13_path_PDMap, Number_14_path_PDMap, Number_15_path_PDMap, Number_16_path_PDMap, Number_17_path_PDMap, Number_18_path_PDMap]
PDMap_save_path = [Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT,
                   Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT,
                   Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT]

T1Map_GT_path = [Number_1_path_T1Map, Number_2_path_T1Map, Number_3_path_T1Map, Number_4_path_T1Map, Number_5_path_T1Map, Number_6_path_T1Map, Number_7_path_T1Map, Number_8_path_T1Map, Number_9_path_T1Map, Number_10_path_T1Map,
                 Number_11_path_T1Map, Number_12_path_T1Map, Number_13_path_T1Map, Number_14_path_T1Map, Number_15_path_T1Map, Number_16_path_T1Map, Number_17_path_T1Map, Number_18_path_T1Map]
T1Map_save_path = [Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT,
                   Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT,
                   Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT]

# QSM_GT_path = [Number_1_path_QSM, Number_2_path_QSM, Number_3_path_QSM, Number_4_path_QSM]
# QSM_save_path = [Number_1_QSM_dicom_GT, Number_1_QSM_dicom_GT, Number_1_QSM_dicom_GT, Number_1_QSM_dicom_GT]

raw_affine_list = [Number_1_raw_affine, Number_2_raw_affine, Number_3_raw_affine, Number_4_raw_affine, Number_5_raw_affine, Number_6_raw_affine, Number_7_raw_affine,
                   Number_8_raw_affine, Number_9_raw_affine, Number_10_raw_affine, Number_11_raw_affine, Number_12_raw_affine, Number_13_raw_affine, Number_14_raw_affine,
                   Number_15_raw_affine, Number_16_raw_affine, Number_17_raw_affine, Number_18_raw_affine]


def Processing_dicom():

    number_norm = 0

    for path in T1Map_GT_path:
        files = os.listdir(path)  # 采用listdir来读取所有文件
        number = len(files)
        print(number)

        file_path = os.path.join(path)

        series_id = sitk.ImageSeriesReader.GetGDCMSeriesIDs(file_path)

        # GetGDCMSeriesFileNames读取序列号相同dcm文件的路径，series[0]代表第一个序列号对应的文件
        series_file_names = sitk.ImageSeriesReader.GetGDCMSeriesFileNames(file_path, series_id[0])

        series_reader = sitk.ImageSeriesReader()
        series_reader.SetFileNames(series_file_names)
        image3d = series_reader.Execute()
        Save_path = T1Map_save_path[T1Map_GT_path.index(path)] + 'GT.nii.gz'
        sitk.WriteImage(image3d, Save_path)

        Image = nib.load(os.path.join(Save_path))
        data_Image = np.float32(Image.get_fdata())

        for i in range(12, 52):
            data = data_Image[:, :, i]

        # ds = pydicom.dcmread(file_path, force=True)     # 由于缺失文件元信息头,无法直接读取,只能强行读取
        #
        # # print(ds.PatientID, ds.StudyDate, ds.Modality)
        # # print(ds.get(0x00100020))
        #
        # ds.file_meta.TransferSyntaxUID = pydicom.uid.ImplicitVRLittleEndian
        #
        # # 获取像素数据
        #
        # dcmPixelArray = ds.pixel_array             # 读取dicom文件，获得metaData

        # data = np.array(dcmPixelArray)
        #     data = data.transpose(img.ROTATE_180)
        #     data = np.transpose(data, axes=(1, 0))

            data = np.flip(data)
            data = data[4:228, 8:264]

            # if T1Map_GT_path.index(path) == 1:
            #     data = cv.copyMakeBorder(data, bottom=24, top=15, left=0, right=0, borderType=cv.BORDER_REPLICATE)
            #
            # elif T1Map_GT_path.index(path) == 2:
            #     data = cv.copyMakeBorder(data, bottom=9, top=10, left=0, right=0, borderType=cv.BORDER_REPLICATE)
            #     data = data[:, 8:264]
            #
            # elif T1Map_GT_path.index(path) == 3:
            #     data = cv.copyMakeBorder(data, bottom=13, top=12, left=0, right=0, borderType=cv.BORDER_REPLICATE)
            #     data = data[:, 8:264]

            data = data / np.max(data)
            np.save(T1Map_save_path[T1Map_GT_path.index(path)] + str(i - 12 + number_norm) + '_dicom_GT.npy', data)

            # pyplot.imshow(data, cmap=pyplot.cm.bone)
            # pyplot.show()

            img_dicom = nib.Nifti1Image(data, raw_affine_list[T1Map_GT_path.index(path)])
            nib.save(img_dicom, T1Map_save_path[T1Map_GT_path.index(path)] + str(i - 12 + number_norm) + '_dicom_GT.nii.gz')

        dicom_number = 40
        number_norm = number_norm + dicom_number


def PDW_and_T1W():
    number_norm = 0
    for path in GT_path:
        for i in range(40):
            PDWgt = np.zeros([6, 224, 256], dtype=np.float32)
            PDW = np.zeros([224, 256], dtype=np.float32)
            T1W = np.zeros([224, 256], dtype=np.float32)
            T1Wgt = np.zeros([6, 224, 256], dtype=np.float32)
            for j in range(6):
                PDW_file = os.path.join(path, str(j + 1) + '_' + str(i + 16) + '.nii.gz')
                PDW_vol = nib.load(PDW_file)
                PDWgt[j, :, :] = PDW_vol.get_fdata()
                PDW = PDW + PDWgt[j]

                T1W_file = os.path.join(path, str(j + 7) + '_' + str(i + 16) + '.nii.gz')
                T1W_vol = nib.load(T1W_file)
                T1Wgt[j, :, :] = T1W_vol.get_fdata()
                T1W = T1W + T1Wgt[j]
            PDW = PDW / 6
            T1W = T1W / 6
            np.save(PDW_save_path[GT_path.index(path)] + str(number_norm) + '_dicom_GT.npy', PDW)
            img_dicom = nib.Nifti1Image(PDW, raw_affine_list[GT_path.index(path)])
            nib.save(img_dicom, PDW_save_path[GT_path.index(path)] + str(number_norm) + '_dicom_GT.nii.gz')

            np.save(T1W_save_path[GT_path.index(path)] + str(number_norm) + '_dicom_GT.npy', T1W)
            img_dicom = nib.Nifti1Image(T1W, raw_affine_list[GT_path.index(path)])
            nib.save(img_dicom, T1W_save_path[GT_path.index(path)] + str(number_norm) + '_dicom_GT.nii.gz')

            number_norm = number_norm + 1


if __name__ =="__main__":
    # Processing_dicom()
    PDW_and_T1W()