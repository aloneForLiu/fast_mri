import os
import numpy as np

mc_kspace = '/hpc/data/home/bme/v-liuyx1/fast_reconstruction_of_multi_contrast_MRI/get_vd_mask/New_Dataset/mc_kspace/'


def load_dataset1():
    for croped_name in range(272):
        if int(croped_name) < 64:
            kspace_mc = os.path.join(mc_kspace, str(1) + '_' + str(1) + '_' + str(int(croped_name) + 8) + '.npy')
            kspace_mc = np.load(kspace_mc)
            T, C, H, W = kspace_mc.shape
            kspace = kspace_mc.reshape(-1, C, H, W)

            for i in range(15):
                K = os.path.join(mc_kspace, str(1) + '_' + str(i + 2) + '_' + str(int(croped_name) + 8) + '.npy')
                K = np.load(K)
                T, C, H, W = K.shape
                KC = K.reshape(-1, C, H, W)
                kspace = np.concatenate([kspace, KC], axis=0)

            print(kspace.shape)

            np.save(mc_kspace + str(croped_name+1) + '.kspace.npy', kspace)

        if 63 < int(croped_name) < 128:
            kspace_mc = os.path.join(mc_kspace, str(2) + '_' + str(1) + '_' + str(int(croped_name) - 60) + '.npy')
            kspace_mc = np.load(kspace_mc)
            T, C, H, W = kspace_mc.shape
            kspace = kspace_mc.reshape(-1, C, H, W)

            for i in range(11):
                K = os.path.join(mc_kspace, str(2) + '_' + str(i + 2) + '_' + str(int(croped_name) - 60) + '.npy')
                K = np.load(K)
                T, C, H, W = K.shape
                KC = K.reshape(-1, C, H, W)
                kspace = np.concatenate([kspace, KC], axis=0)

            print(kspace.shape)

            np.save(mc_kspace + str(croped_name + 1) + '.kspace.npy', kspace)



        if 127 < int(croped_name) < 208:
            kspace_mc = os.path.join(mc_kspace, str(3) + '_' + str(1) + '_' + str(int(croped_name) - 122) + '.npy')
            kspace_mc = np.load(kspace_mc)
            T, C, H, W = kspace_mc.shape
            kspace = kspace_mc.reshape(-1, C, H, W)

            for i in range(11):
                K = os.path.join(mc_kspace, str(3) + '_' + str(i + 2) + '_' + str(int(croped_name) - 122) + '.npy')
                K = np.load(K)
                T, C, H, W = K.shape
                KC = K.reshape(-1, C, H, W)
                kspace = np.concatenate([kspace, KC], axis=0)

            print(kspace.shape)

            np.save(mc_kspace + str(croped_name + 1) + '.kspace.npy', kspace)


def load_dataset3():
    for croped_name in range(64):
        if int(croped_name) < 64:
            kspace_mc = os.path.join(mc_kspace, str(4) + '_' + str(1) + '_' + str(int(croped_name) + 8) + '.npy')
            kspace_mc = np.load(kspace_mc)
            T, C, H, W = kspace_mc.shape
            kspace = kspace_mc.reshape(-1, C, H, W)

        for i in range(11):
            K = os.path.join(mc_kspace, str(4) + '_' + str(i + 2) + '_' + str(int(croped_name) + 8) + '.npy')
            K = np.load(K)
            T, C, H, W = K.shape
            KC = K.reshape(-1, C, H, W)
            print(KC.shape)
            kspace = np.concatenate([kspace, KC], axis=0)

        print(kspace.shape)

        np.save(mc_kspace + str(croped_name + 209) + '.kspace.npy', kspace)


def load_dataset4():
    for croped_name in range(720):
        kspace_mc = os.path.join(mc_kspace, str(croped_name//40 + 1) + '_' + str(1) + '_' + str(int(croped_name%40)) + '.npy')
        kspace_mc = np.load(kspace_mc)
        T, C, H, W = kspace_mc.shape
        kspace = kspace_mc.reshape(-1, C, H, W)

        for i in range(11):
            K = os.path.join(mc_kspace, str(croped_name//40 + 1) + '_' + str(i + 2) + '_' + str(int(croped_name%40)) + '.npy')
            K = np.load(K)
            T, C, H, W = K.shape
            KC = K.reshape(-1, C, H, W)
            print(KC.shape)
            kspace = np.concatenate([kspace, KC], axis=0)

        print(kspace.shape)

        np.save(mc_kspace + str(croped_name + 1) + '.kspace.npy', kspace)


if __name__ =="__main__":
    # load_dataset1()
    # load_dataset3()
    load_dataset4()


