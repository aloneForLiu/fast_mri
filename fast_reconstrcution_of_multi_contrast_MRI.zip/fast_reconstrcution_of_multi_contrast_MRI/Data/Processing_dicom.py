import dicom2nifti
import cv2 as cv
import numpy as np
import pydicom
import os
import nibabel as nib
from matplotlib import pyplot
import SimpleITK as sitk
import PIL.Image as img
import math

Number_1_path_PDW = r'D:/download/data/ForUII_MTP/UID_141293152150395_gre_mtp_ppa_ForAI/gre_mtp_ppa_ForAI_MTP_PDW/'
Number_2_path_PDW = r'D:/download/data/ForUII_MTP/UID_58713822602023_gre_mtp_PPA2x/gre_mtp_PPA2x_PDW/'
Number_3_path_PDW = r'D:/download/data/ForUII_MTP/UID_64627986959462_gre_mtp_tra/gre_mtp_tra_MTP_PDW/TE_0/'
Number_4_path_PDW = r'D:/download/data/ForUII_MTP/UID_245527714669115_gre_mtp_ppa/gre_mtp_ppa_MTP_PDW/'

Number_6_path_PDW = r'F:/20220118/MMC_20220118-203522-0535_204037/mtp_tra_1x1x2_MTP_PDW_203/'
Number_7_path_PDW = r'F:/20220118/WHY_20220118-210258-0536_210400/mtp_tra_1x1x2_MTP_PDW_203/'
Number_8_path_PDW = r'F:/20211229/lyx_20211223-112520-0497_201143/mtp_tra_1x1x2_MTP_PDW_203/'
Number_9_path_PDW = r'F:/20220118/zwc_20220118-212411-0537_212444/mtp_tra_1x1x2_MTP_PDW_203/'
Number_10_path_PDW = r'F:/20220118/zz_20220118-214316-0538_214350/mtp_tra_1x1x2_MTP_PDW_203/'
Number_11_path_PDW = r'F:/20220703/JZ_20220703-202712-0957_202909/mtp_tra_1x1x2_MTP_PDW_203/'
Number_12_path_PDW = r'F:/20220703/TX_20220703-200726-0956_200759/mtp_tra_1x1x2_MTP_PDW_203/'
Number_13_path_PDW = r'F:/20220703/XYX_20220703-205038-0958_205121/mtp_tra_1x1x2_MTP_PDW_203/'
Number_14_path_PDW = r'F:/20220704/CSY_20220704-195726-0966_195829/mtp_tra_1x1x2_MTP_PDW_203/'
Number_15_path_PDW = r'F:/20220704/LJM_20220704-201657-0967_201733/mtp_tra_1x1x2_MTP_PDW_203/'
Number_16_path_PDW = r'F:/20220710/ZJD_20220710-192948-1001_193811/mtp_tra_1x1x2_MTP_PDW_203/'
Number_17_path_PDW = r'F:/20220710/LZF_20220710-200006-1002_200049/mtp_tra_1x1x2_MTP_PDW_303/'


Number_1_path_T1W = r'D:/download/data/ForUII_MTP/UID_141293152150395_gre_mtp_ppa_ForAI/gre_mtp_ppa_ForAI_MTP_T1W/'
Number_2_path_T1W = r'D:/download/data/ForUII_MTP/UID_58713822602023_gre_mtp_PPA2x/gre_mtp_PPA2x_T1W/'
Number_3_path_T1W = r'D:/download/data/ForUII_MTP/UID_64627986959462_gre_mtp_tra/gre_mtp_tra_MTP_T1W/TE_0/'
Number_4_path_T1W = r'D:/download/data/ForUII_MTP/UID_245527714669115_gre_mtp_ppa/gre_mtp_ppa_MTP_T1W/'

Number_6_path_T1W = r'F:/20220118/MMC_20220118-203522-0535_204037/mtp_tra_1x1x2_MTP_T1W_204/'
Number_7_path_T1W = r'F:/20220118/WHY_20220118-210258-0536_210400/mtp_tra_1x1x2_MTP_T1W_204/'
Number_8_path_T1W = r'F:/20211229/lyx_20211223-112520-0497_201143/mtp_tra_1x1x2_MTP_T1W_204/'
Number_9_path_T1W = r'F:/20220118/zwc_20220118-212411-0537_212444/mtp_tra_1x1x2_MTP_T1W_204/'
Number_10_path_T1W = r'F:/20220118/zz_20220118-214316-0538_214350/mtp_tra_1x1x2_MTP_T1W_204/'
Number_11_path_T1W = r'F:/20220703/JZ_20220703-202712-0957_202909/mtp_tra_1x1x2_MTP_T1W_204/'
Number_12_path_T1W = r'F:/20220703/TX_20220703-200726-0956_200759/mtp_tra_1x1x2_MTP_T1W_204/'
Number_13_path_T1W = r'F:/20220703/XYX_20220703-205038-0958_205121/mtp_tra_1x1x2_MTP_T1W_204/'
Number_14_path_T1W = r'F:/20220704/CSY_20220704-195726-0966_195829/mtp_tra_1x1x2_MTP_T1W_204/'
Number_15_path_T1W = r'F:/20220704/LJM_20220704-201657-0967_201733/mtp_tra_1x1x2_MTP_T1W_204/'
Number_16_path_T1W = r'F:/20220710/ZJD_20220710-192948-1001_193811/mtp_tra_1x1x2_MTP_T1W_204/'
Number_17_path_T1W = r'F:/20220710/LZF_20220710-200006-1002_200049/mtp_tra_1x1x2_MTP_T1W_304/'

# Number_1_path = r'D:/download/data/UID_141293152150395/'
# Number_2_path = r'D:/download/data/UID_58713822602023/'
# Number_3_path = r'D:/download/data/UID_64627986959462/'
# Number_4_path = r'D:/download/data/UID_245527714669115/'

Number_6_path = r'D:/download/data/UID_Mancheng/'
Number_7_path = r'D:/download/data/UID_Why/'
Number_8_path = r'D:/download/data/UID_Yuxuan/'
Number_9_path = r'D:/download/data/UID_Zwc/'
Number_10_path = r'D:/download/data/UID_Zz/'
Number_11_path = r'D:/download/data/UID_Jz/'
Number_12_path = r'D:/download/data/UID_Tx/'
Number_13_path = r'D:/download/data/UID_Xyx/'
Number_14_path = r'D:/download/data/UID_Csy/'
Number_15_path = r'D:/download/data/UID_Ljm/'
Number_16_path = r'D:/download/data/UID_Zjd/'
Number_17_path = r'D:/download/data/UID_Lzf/'

Number_1_path_T2S = r'D:/download/data/ForUII_MTP/UID_141293152150395_gre_mtp_ppa_ForAI/gre_mtp_ppa_ForAI_MTP_T2Star/'
Number_2_path_T2S = r'D:/download/data/ForUII_MTP/UID_58713822602023_gre_mtp_PPA2x/gre_mtp_PPA2x_T2Star/'
Number_3_path_T2S = r'D:/download/data/ForUII_MTP/UID_64627986959462_gre_mtp_tra/gre_mtp_tra_MTP_T2Star/TE_0/'
Number_4_path_T2S = r'D:/download/data/ForUII_MTP/UID_245527714669115_gre_mtp_ppa/gre_mtp_ppa_MTP_T2Star/'

Number_6_path_T2S = r'F:/20220118/MMC_20220118-203522-0535_204037/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_7_path_T2S = r'F:/20220118/WHY_20220118-210258-0536_210400/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_8_path_T2S = r'F:/20211229/lyx_20211223-112520-0497_201143/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_9_path_T2S = r'F:/20220118/zwc_20220118-212411-0537_212444/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_10_path_T2S = r'F:/20220118/zz_20220118-214316-0538_214350/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_11_path_T2S = r'F:/20220703/JZ_20220703-202712-0957_202909/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_12_path_T2S = r'F:/20220703/TX_20220703-200726-0956_200759/mtp_tra_1x1x2_MTP_T2Star_207'
Number_13_path_T2S = r'F:/20220703/XYX_20220703-205038-0958_205121/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_14_path_T2S = r'F:/20220704/CSY_20220704-195726-0966_195829/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_15_path_T2S = r'F:/20220704/LJM_20220704-201657-0967_201733/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_16_path_T2S = r'F:/20220710/ZJD_20220710-192948-1001_193811/mtp_tra_1x1x2_MTP_T2Star_207/'
Number_17_path_T2S = r'F:/20220710/LZF_20220710-200006-1002_200049/mtp_tra_1x1x2_MTP_T2Star_307/'


Number_1_path_PDMap = r'D:/download/data/ForUII_MTP/UID_141293152150395_gre_mtp_ppa_ForAI/gre_mtp_ppa_ForAI_MTP_PDMap/'
Number_2_path_PDMap = r'D:/download/data/ForUII_MTP/UID_58713822602023_gre_mtp_PPA2x/gre_mtp_PPA2x_PDMap/'
Number_3_path_PDMap = r'D:/download/data/ForUII_MTP/UID_64627986959462_gre_mtp_tra/gre_mtp_tra_MTP_PDMap/TE_0/'
Number_4_path_PDMap = r'D:/download/data/ForUII_MTP/UID_245527714669115_gre_mtp_ppa/gre_mtp_ppa_MTP_PDMap/'

Number_6_path_PDMap = r'F:/20220118/MMC_20220118-203522-0535_204037/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_7_path_PDMap = r'F:/20220118/WHY_20220118-210258-0536_210400/mtp_tra_1x1x2_MTP_PDMap_205'
Number_8_path_PDMap = r'F:/20211229/lyx_20211223-112520-0497_201143/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_9_path_PDMap = r'F:/20220118/zwc_20220118-212411-0537_212444/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_10_path_PDMap = r'F:/20220118/zz_20220118-214316-0538_214350/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_11_path_PDMap = r'F:/20220703/JZ_20220703-202712-0957_202909/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_12_path_PDMap = r'F:/20220703/TX_20220703-200726-0956_200759/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_13_path_PDMap = r'F:/20220703/XYX_20220703-205038-0958_205121/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_14_path_PDMap = r'F:/20220704/CSY_20220704-195726-0966_195829/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_15_path_PDMap = r'F:/20220704/LJM_20220704-201657-0967_201733/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_16_path_PDMap = r'F:/20220710/ZJD_20220710-192948-1001_193811/mtp_tra_1x1x2_MTP_PDMap_205/'
Number_17_path_PDMap = r'F:/20220710/LZF_20220710-200006-1002_200049/mtp_tra_1x1x2_MTP_PDMap_305/'


Number_1_path_T1Map = r'D:/download/data/ForUII_MTP/UID_141293152150395_gre_mtp_ppa_ForAI/gre_mtp_ppa_ForAI_MTP_T1Map/'
Number_2_path_T1Map = r'D:/download/data/ForUII_MTP/UID_58713822602023_gre_mtp_PPA2x/gre_mtp_PPA2x_T1Map/'
Number_3_path_T1Map = r'D:/download/data/ForUII_MTP/UID_64627986959462_gre_mtp_tra/gre_mtp_tra_MTP_T1Map/TE_0/'
Number_4_path_T1Map = r'D:/download/data/ForUII_MTP/UID_245527714669115_gre_mtp_ppa/gre_mtp_ppa_MTP_T1Map/'

Number_6_path_T1Map = r'F:/20220118/MMC_20220118-203522-0535_204037/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_7_path_T1Map = r'F:/20220118/WHY_20220118-210258-0536_210400/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_8_path_T1Map = r'F:/20211229/lyx_20211223-112520-0497_201143/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_9_path_T1Map = r'F:/20220118/zwc_20220118-212411-0537_212444/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_10_path_T1Map = r'F:/20220118/zz_20220118-214316-0538_214350/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_11_path_T1Map = r'F:/20220703/JZ_20220703-202712-0957_202909/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_12_path_T1Map = r'F:/20220703/TX_20220703-200726-0956_200759/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_13_path_T1Map = r'F:/20220703/XYX_20220703-205038-0958_205121/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_14_path_T1Map = r'F:/20220704/CSY_20220704-195726-0966_195829/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_15_path_T1Map = r'F:/20220704/LJM_20220704-201657-0967_201733/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_16_path_T1Map = r'F:/20220710/ZJD_20220710-192948-1001_193811/mtp_tra_1x1x2_MTP_T1Map_201/'
Number_17_path_T1Map = r'F:/20220710/LZF_20220710-200006-1002_200049/mtp_tra_1x1x2_MTP_T1Map_301/'


# Number_1_path_QSM = r'D:/download/data/ForUII_MTP/UID_141293152150395_gre_mtp_ppa_ForAI/gre_mtp_ppa_ForAI_QSM/'
# Number_2_path_QSM = r'D:/download/data/ForUII_MTP/UID_58713822602023_gre_mtp_PPA2x/gre_mtp_PPA2x_QSM/'
# Number_3_path_QSM = r'D:/download/data/ForUII_MTP/UID_64627986959462_gre_mtp_tra/gre_mtp_tra_QSM/TE_0/'
# Number_4_path_QSM = r'D:/download/data/ForUII_MTP/UID_245527714669115_gre_mtp_ppa/gre_mtp_ppa_QSM/'

Number_1_PDW_dicom_GT = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/PDW_dicom_GT/'
Number_1_T1W_dicom_GT = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/T1W_dicom_GT/'
Number_1_T2S_dicom_GT = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/T2S_dicom_GT/'
Number_1_PDMap_dicom_GT = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/PDM_dicom_GT/'
Number_1_T1Map_dicom_GT = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/T1M_dicom_GT/'
Number_1_QSM_dicom_GT = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/QSM_dicom_GT/'

Number_1_raw_affine = [[0.8594, 0, 0, -109.6],
                        [0, 0.8594, 0, -115.2],
                        [0, 0, 2, -23.17],
                        [0, 0, 0, 1]]

Number_2_raw_affine = [[0.8753, 0, 0, -98.99],
                        [0, 0.8753, 0, -113.8],
                        [0, 0, 2, -7.228],
                        [0, 0, 0, 1]]

Number_3_raw_affine = [[0.8447, 0, 0, -108.3],
                        [0, 0.8447, 0, -106.1],
                        [0, 0, 2, -43.59],
                        [0, 0, 0, 1]]

Number_4_raw_affine = [[0.823, 0, 0, -97.35],
              [0, 0.823, 0, -116.2],
              [0, 0, 2, -30.34],
              [0, 0, 0, 1]]

Number_6_raw_affine = [[1, 0, 0, -122.7],
                  [0, 1, 0, -104.2],
                  [0, 0, 2, -65.31],
                  [0, 0, 0, 1]]

Number_7_raw_affine = [[1, 0, 0, -97.77],
                  [0, 1, 0, -111.6],
                  [0, 0, 2, -46.33],
                  [0, 0, 0, 1]]

Number_8_raw_affine = [[1, 0, 0, -92.86],
                  [0, 1, 0, -110.4],
                  [0, 0, 2, -47.44],
                  [0, 0, 0, 1]]

Number_9_raw_affine = [[1, 0, 0, -112.3],
                  [0, 1, 0, -107.2],
                  [0, 0, 2, -50.92],
                  [0, 0, 0, 1]]

Number_10_raw_affine = [[1, 0, 0, -114.5],
                  [0, 1, 0, -99.86],
                  [0, 0, 2, -34.76],
                  [0, 0, 0, 1]]

Number_11_raw_affine =  [[1, 0, 0, -112.4],
                  [0, 1, 0, -105.5],
                  [0, 0, 2, -34.28],
                  [0, 0, 0, 1]]

Number_12_raw_affine = [[1, 0, 0, -100.9],
                  [0, 1, 0, -111.7],
                  [0, 0, 2, -48.43],
                  [0, 0, 0, 1]]

Number_13_raw_affine = [[1, 0, 0, -116.5],
                  [0, 1, 0, -110.4],
                  [0, 0, 2, -33.51],
                  [0, 0, 0, 1]]

Number_14_raw_affine = [[1, 0, 0, -97.84],
                  [0, 1, 0, -107.6],
                  [0, 0, 2, -33.04],
                  [0, 0, 0, 1]]

Number_15_raw_affine = [[1, 0, 0, -97.14],
                  [0, 1, 0, -107.4],
                  [0, 0, 2, -47.51],
                  [0, 0, 0, 1]]

Number_16_raw_affine = [[1, 0, 0, -99.35],
                  [0, 1, 0, -111.8],
                  [0, 0, 2, -63.55],
                  [0, 0, 0, 1]]

Number_17_raw_affine = [[1, 0, 0, -98.24],
                  [0, 1, 0, -112.9],
                  [0, 0, 2, -80.7],
                  [0, 0, 0, 1]]

GT_path = [Number_6_path, Number_7_path, Number_8_path, Number_9_path, Number_10_path, Number_11_path, Number_12_path, Number_13_path, Number_14_path, Number_15_path, Number_16_path, Number_17_path]

# PDW_GT_path = [Number_1_path, Number_2_path, Number_3_path, Number_4_path]
# PDW_GT_path = [Number_6_path_PDW]
# PDW_save_path = [Number_1_PDW_dicom_GT]
# T1W_GT_path = [Number_6_path_T1W]
# T1W_save_path = [Number_1_T1W_dicom_GT]
# T2S_GT_path = [Number_6_path_T2S]
# T2S_save_path = [Number_1_T2S_dicom_GT]
# PDMap_GT_path = [Number_6_path_PDMap]
# PDMap_save_path = [Number_1_PDMap_dicom_GT]
# T1Map_GT_path = [Number_6_path_T1Map]
# T1Map_save_path = [Number_1_T1Map_dicom_GT]
# raw_affine_list = [Number_6_raw_affine]
# PDW_save_path = [Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT]
#
# T1W_GT_path = [Number_1_path, Number_2_path, Number_3_path, Number_4_path]
# T1W_save_path = [Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT]
#
# raw_affine_list = [Number_1_raw_affine, Number_2_raw_affine, Number_3_raw_affine, Number_4_raw_affine]

PDW_GT_path = [Number_6_path_PDW, Number_7_path_PDW, Number_8_path_PDW, Number_9_path_PDW, Number_10_path_PDW, Number_11_path_PDW, Number_12_path_PDW,
               Number_13_path_PDW, Number_14_path_PDW, Number_15_path_PDW, Number_16_path_PDW, Number_17_path_PDW]
PDW_save_path = [Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT,
                 Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT, Number_1_PDW_dicom_GT]

T1W_GT_path = [Number_6_path_T1W, Number_7_path_T1W, Number_8_path_T1W, Number_9_path_T1W, Number_10_path_T1W, Number_11_path_T1W, Number_12_path_T1W,
               Number_13_path_T1W, Number_14_path_T1W, Number_15_path_T1W, Number_16_path_T1W, Number_17_path_T1W]
T1W_save_path = [Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT,
                 Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT, Number_1_T1W_dicom_GT]

T2S_GT_path = [Number_6_path_T2S, Number_7_path_T2S, Number_8_path_T2S, Number_9_path_T2S, Number_10_path_T2S, Number_11_path_T2S, Number_12_path_T2S,
               Number_13_path_T2S, Number_14_path_T2S, Number_15_path_T2S, Number_16_path_T2S, Number_17_path_T2S]
T2S_save_path = [Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT,
                 Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT, Number_1_T2S_dicom_GT]

PDMap_GT_path = [Number_6_path_PDMap, Number_7_path_PDMap, Number_8_path_PDMap, Number_9_path_PDMap, Number_10_path_PDMap,
                 Number_11_path_PDMap, Number_12_path_PDMap, Number_13_path_PDMap, Number_14_path_PDMap, Number_15_path_PDMap, Number_16_path_PDMap, Number_17_path_PDMap]
PDMap_save_path = [Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT,
                   Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT, Number_1_PDMap_dicom_GT]

T1Map_GT_path = [Number_6_path_T1Map, Number_7_path_T1Map, Number_8_path_T1Map, Number_9_path_T1Map, Number_10_path_T1Map,
                 Number_11_path_T1Map, Number_12_path_T1Map, Number_13_path_T1Map, Number_14_path_T1Map, Number_15_path_T1Map, Number_16_path_T1Map, Number_17_path_T1Map]
T1Map_save_path = [Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT,
                   Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT, Number_1_T1Map_dicom_GT]

# QSM_GT_path = [Number_1_path_QSM, Number_2_path_QSM, Number_3_path_QSM, Number_4_path_QSM]
# QSM_save_path = [Number_1_QSM_dicom_GT, Number_1_QSM_dicom_GT, Number_1_QSM_dicom_GT, Number_1_QSM_dicom_GT]

raw_affine_list = [Number_6_raw_affine, Number_7_raw_affine,
                   Number_8_raw_affine, Number_9_raw_affine, Number_10_raw_affine, Number_11_raw_affine, Number_12_raw_affine, Number_13_raw_affine, Number_14_raw_affine, Number_15_raw_affine, Number_16_raw_affine, Number_17_raw_affine]


def Processing_dicom():

    number_norm = 272

    for path in PDMap_GT_path:
        files = os.listdir(path)  # 采用listdir来读取所有文件
        number = len(files)
        print(number)

        file_path = os.path.join(path)

        series_id = sitk.ImageSeriesReader.GetGDCMSeriesIDs(file_path)

        # GetGDCMSeriesFileNames读取序列号相同dcm文件的路径，series[0]代表第一个序列号对应的文件
        series_file_names = sitk.ImageSeriesReader.GetGDCMSeriesFileNames(file_path, series_id[0])

        series_reader = sitk.ImageSeriesReader()
        series_reader.SetFileNames(series_file_names)
        image3d = series_reader.Execute()
        Save_path = PDMap_save_path[PDMap_GT_path.index(path)] + 'GT.nii.gz'
        sitk.WriteImage(image3d, Save_path)

        Image = nib.load(os.path.join(Save_path))
        data_Image = np.float32(Image.get_fdata())

        for i in range(15, 55):
            data = data_Image[:, :, i]

        # ds = pydicom.dcmread(file_path, force=True)     # 由于缺失文件元信息头,无法直接读取,只能强行读取
        #
        # # print(ds.PatientID, ds.StudyDate, ds.Modality)
        # # print(ds.get(0x00100020))
        #
        # ds.file_meta.TransferSyntaxUID = pydicom.uid.ImplicitVRLittleEndian
        #
        # # 获取像素数据
        #
        # dcmPixelArray = ds.pixel_array             # 读取dicom文件，获得metaData

        # data = np.array(dcmPixelArray)
        #     data = data.transpose(img.ROTATE_180)
        #     data = np.transpose(data, axes=(1, 0))

            data = np.flip(data)
            data = data[4:196, :]

            # if T1Map_GT_path.index(path) == 1:
            #     data = cv.copyMakeBorder(data, bottom=24, top=15, left=0, right=0, borderType=cv.BORDER_REPLICATE)
            #
            # elif T1Map_GT_path.index(path) == 2:
            #     data = cv.copyMakeBorder(data, bottom=9, top=10, left=0, right=0, borderType=cv.BORDER_REPLICATE)
            #     data = data[:, 8:264]
            #
            # elif T1Map_GT_path.index(path) == 3:
            #     data = cv.copyMakeBorder(data, bottom=13, top=12, left=0, right=0, borderType=cv.BORDER_REPLICATE)
            #     data = data[:, 8:264]

            data = data / 800
            np.save(PDMap_save_path[PDMap_GT_path.index(path)] + str(i - 15 + number_norm) + '_dicom_GT.npy', data)

            # pyplot.imshow(data, cmap=pyplot.cm.bone)
            # pyplot.show()

            img_dicom = nib.Nifti1Image(data, raw_affine_list[PDMap_GT_path.index(path)])
            nib.save(img_dicom, PDMap_save_path[PDMap_GT_path.index(path)] + str(i - 15 + number_norm) + '_dicom_GT.nii.gz')

        dicom_number = 40
        number_norm = number_norm + dicom_number


def PDW_and_T1W():
    number_norm = 272
    for path in GT_path:
        for i in range(40):
            PDWgt = np.zeros([8, 192, 224], dtype=np.float32)
            PDW = np.zeros([192, 224], dtype=np.float32)
            T1W = np.zeros([192, 224], dtype=np.float32)
            T1Wgt = np.zeros([8, 192, 224], dtype=np.float32)
            for j in range(8):
                PDW_file = os.path.join(path, str(j + 1) + '_' + str(i + 15) + '.nii.gz')
                PDW_vol = nib.load(PDW_file)
                PDWgt[j, :, :] = PDW_vol.get_fdata()
                PDW = PDW + PDWgt[j]

                T1W_file = os.path.join(path, str(j + 9) + '_' + str(i + 15) + '.nii.gz')
                T1W_vol = nib.load(T1W_file)
                T1Wgt[j, :, :] = T1W_vol.get_fdata()
                T1W = T1W + T1Wgt[j]
            PDW = PDW / 8
            T1W = T1W / 8
            np.save(PDW_save_path[GT_path.index(path)] + str(number_norm) + '_dicom_GT.npy', PDW)
            img_dicom = nib.Nifti1Image(PDW, raw_affine_list[GT_path.index(path)])
            nib.save(img_dicom, PDW_save_path[GT_path.index(path)] + str(number_norm) + '_dicom_GT.nii.gz')

            np.save(T1W_save_path[GT_path.index(path)] + str(number_norm) + '_dicom_GT.npy', T1W)
            img_dicom = nib.Nifti1Image(T1W, raw_affine_list[GT_path.index(path)])
            nib.save(img_dicom, T1W_save_path[GT_path.index(path)] + str(number_norm) + '_dicom_GT.nii.gz')

            number_norm = number_norm + 1


if __name__ =="__main__":
    Processing_dicom()
    # PDW_and_T1W()