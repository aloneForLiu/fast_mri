import os
import numpy as np


def load_parameter_dicom(PDW_parameter_path, T1W_parameter_path, T2S_parameter_path, PDM_parameter_path, T1M_parameter_path, mode, index):
    if mode == 0:
        index = index + 40
        croped_name = str(index - 1)
        PDW = os.path.join(PDW_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        PDW = np.load(PDW)
        T2S = os.path.join(T2S_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        T2S = np.load(T2S)
        T1W = os.path.join(T1W_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        T1W = np.load(T1W)
        PDM = os.path.join(PDM_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        PDM = np.load(PDM)
        T1M = os.path.join(T1M_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        T1M = np.load(T1M)

    if mode == 1:
        index = index + 0
        croped_name = str(index - 1)
        PDW = os.path.join(PDW_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        PDW = np.load(PDW)
        T2S = os.path.join(T2S_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        T2S = np.load(T2S)
        T1W = os.path.join(T1W_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        T1W = np.load(T1W)
        PDM = os.path.join(PDM_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        PDM = np.load(PDM)
        T1M = os.path.join(T1M_parameter_path, croped_name + '_' + 'dicom_GT' + '.npy')
        T1M = np.load(T1M)

    return [PDW, T2S, T1W, PDM, T1M]