import os as os
import numpy as np
import cv2 as cv

mc_kspace = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/mc_kspace/'


def C_MTP1():
    filenames = ['UID141293152150395_RO256_FA0_TR0_Echo0_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA0_TR1_Echo0_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA0_TR1_Echo1_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA0_TR1_Echo2_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA0_TR1_Echo3_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA0_TR1_Echo4_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA0_TR1_Echo5_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA0_TR1_Echo6_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA1_TR0_Echo0_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA1_TR1_Echo0_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA1_TR1_Echo1_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA1_TR1_Echo2_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA1_TR1_Echo3_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA1_TR1_Echo4_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA1_TR1_Echo5_PE256_SPE80_CHA32',
               'UID141293152150395_RO256_FA1_TR1_Echo6_PE256_SPE80_CHA32', ]
    p = 0

    os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

    for filename in filenames:
        fullpath = 'D:/download/data/' + filename + '.bin'
        a = np.fromfile(fullpath, dtype=np.float32).reshape(32, 80, 256, 256, 2)
        p = p + 1
        mck_s = np.zeros([2, 32, 256, 256, 80], dtype=np.float32)
        result = a[:, :, :, :, 0] + 1j*a[:, :, :, :, 1]

        for i in range(32):
            for j in range(256):
                result[i, :, :, j] = np.fft.fftshift(np.fft.ifft2(result[i, :, :, j]))
        result = np.transpose(result, axes=(0, 2, 3, 1))
        result = np.flip(result)
        result = np.abs(result)

        for i in range(32):
            for j in range(80):
                kspace = np.complex64(np.fft.fftshift(np.fft.fft2(result[i, :, :, j])))
                mck_s[0, i, :, :, j] = kspace.real
                mck_s[1, i, :, :, j] = kspace.imag

        for j in range(80):
            np.save(mc_kspace + str(1) + '_' + str(p) + '_' + str(j) + '.npy', mck_s[:, :, :, :, j])

def C_MTP2():
    filenames = ['UID58713822602023_RO256_FA0_TR0_Echo0_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA0_TR1_Echo0_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA0_TR1_Echo1_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA0_TR1_Echo2_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA0_TR1_Echo3_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA0_TR1_Echo4_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA1_TR0_Echo0_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA1_TR1_Echo0_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA1_TR1_Echo1_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA1_TR1_Echo1_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA1_TR1_Echo3_PE217_SPE73_CHA24',
                'UID58713822602023_RO256_FA1_TR1_Echo4_PE217_SPE73_CHA24',]
    p = 0

    os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

    for filename in filenames:
        fullpath = 'D:/download/data/' + filename + '.bin'
        a = np.fromfile(fullpath, dtype=np.float32).reshape(24, 73, 217, 256, 2)
        p = p + 1
        mck_s = np.zeros([2, 24, 256, 256, 73], dtype=np.float32)
        result = a[:, :, :, :, 0] + 1j*a[:, :, :, :, 1]

        for i in range(24):
            for j in range(256):
                result[i, :, :, j] = np.fft.fftshift(np.fft.ifft2(result[i, :, :, j]))
        result = np.transpose(result, axes=(0, 2, 3, 1))
        result = np.flip(result)
        result = np.abs(result)

        for i in range(24):
            for l in range(73):
                image = cv.copyMakeBorder(result[i, :, :, l], bottom=24, top=15, left=0, right=0, borderType=cv.BORDER_REPLICATE)
                kspace = np.complex64(np.fft.fftshift(np.fft.fft2(image)))
                mck_s[0, i, :, :, l] = kspace.real
                mck_s[1, i, :, :, l] = kspace.imag

        for j in range(73):
            np.save(mc_kspace + str(2) + '_' + str(p) + '_' + str(j) + '.npy', mck_s[:, :, :, :, j])


def C_MTP3():
    filenames = ['UID64627986959462_RO272_FA0_TR0_Echo0_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA0_TR1_Echo0_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA0_TR1_Echo1_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA0_TR1_Echo2_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA0_TR1_Echo3_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA0_TR1_Echo4_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA1_TR0_Echo0_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA1_TR1_Echo0_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA1_TR1_Echo1_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA1_TR1_Echo2_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA1_TR1_Echo3_PE237_SPE92_CHA24',
                'UID64627986959462_RO272_FA1_TR1_Echo4_PE237_SPE92_CHA24',]
    p = 0

    os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

    for filename in filenames:
        fullpath = 'D:/download/data/' + filename + '.bin'
        a = np.fromfile(fullpath, dtype=np.float32).reshape(24, 92, 237, 272, 2)
        p = p + 1
        mck_s = np.zeros([2, 24, 256, 256, 92], dtype=np.float32)
        result = a[:, :, :, :, 0] + 1j*a[:, :, :, :, 1]

        for i in range(24):
            for j in range(272):
                result[i, :, :, j] = np.fft.fftshift(np.fft.ifft2(result[i, :, :, j]))
        result = np.transpose(result, axes=(0, 2, 3, 1))
        result = np.flip(result)
        result = np.abs(result)

        for i in range(24):
            for l in range(92):
                image = cv.copyMakeBorder(result[i, :, :, l], bottom=9, top=10, left=0, right=0, borderType=cv.BORDER_REPLICATE)
                kspace = np.complex64(np.fft.fftshift(np.fft.fft2(image[:, 8:264])))
                mck_s[0, i, :, :, l] = kspace.real
                mck_s[1, i, :, :, l] = kspace.imag

        for j in range(92):
            np.save(mc_kspace + str(3) + '_' + str(p) + '_' + str(j) + '.npy', mck_s[:, :, :, :, j])

def C_MTP4():
    filenames = ['UID245527714669115_RO272_FA0_TR0_Echo0_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA0_TR1_Echo0_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA0_TR1_Echo1_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA0_TR1_Echo2_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA0_TR1_Echo3_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA0_TR1_Echo4_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA1_TR0_Echo0_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA1_TR1_Echo0_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA1_TR1_Echo1_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA1_TR1_Echo2_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA1_TR1_Echo3_PE244_SPE80_CHA32',
                'UID245527714669115_RO272_FA1_TR1_Echo4_PE244_SPE80_CHA32',]
    p = 0

    os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

    for filename in filenames:
        fullpath = 'D:/download/data/' + filename + '.bin'
        a = np.fromfile(fullpath, dtype=np.float32).reshape(32, 80, 244, 272, 2)
        p = p + 1
        mck_s = np.zeros([2, 32, 256, 256, 80], dtype=np.float32)
        result = a[:, :, :, :, 0] + 1j*a[:, :, :, :, 1]

        for i in range(32):
            for j in range(272):
                result[i, :, :, j] = np.fft.fftshift(np.fft.ifft2(result[i, :, :, j]))
        result = np.transpose(result, axes=(0, 2, 3, 1))
        result = np.flip(result)
        result = np.abs(result)

        for i in range(32):
            for l in range(80):
                image = cv.copyMakeBorder(result[i, :, :, l], bottom=6, top=6, left=0, right=0, borderType=cv.BORDER_REPLICATE)
                kspace = np.complex64(np.fft.fftshift(np.fft.fft2(image[:, 8:264])))
                mck_s[0, i, :, :, l] = kspace.real
                mck_s[1, i, :, :, l] = kspace.imag

        for j in range(80):
            np.save(mc_kspace + str(4) + '_' + str(p) + '_' + str(j) + '.npy', mck_s[:, :, :, :, j])

if __name__ =="__main__":

    C_MTP1()
    C_MTP2()
    C_MTP3()
    C_MTP4()
