import torch.nn as nn
import numpy as np


def modelsize(model, type_size=4):

    total = sum([param.nelement() for param in model.parameters() if param.requires_grad])
    print("Number of parameter: %.2fM" % (total / 1e6))

    # para = sum([np.prod(list(p.size())) for p in model.parameters() if p.requires_grad])
# print('Model {} : params: {:4f}M'.format(model._get_name(), para * type_size / 1000 / 1000))

# input_ = input.clone()
# input_.requires_grad_(requires_grad=False)
#
# mods = list(model.modules())
# # print(mods)
# print(len(mods))
# out_sizes = []
#
# for i in range(0, len(mods)):
# 	m = mods[i]
# 	if isinstance(m, nn.ReLU):    # isinstance() 函数来判断一个对象是否是一个已知的类型，类似 type()
# 		if m.inplace:
# 			continue
# 	out = m(input_)
# 	out_sizes.append(np.array(out.size()))
# 	input_ = out
# total_nums = 0
# for i in range(len(out_sizes)):
# 	s = out_sizes[i]
# 	nums = np.prod(np.array(s))
# 	total_nums += nums
#
# print('Model {} : intermedite variables: {:3f} M (without backward)'
# 	  .format(model._get_name(), total_nums * type_size / 1000 / 1000))
# print('Model {} : intermedite variables: {:3f} M (with backward)'
# 	  .format(model._get_name(), total_nums * type_size * 2 / 1000 / 1000))



