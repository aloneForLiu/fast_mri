import os
import numpy as np


def load_dataset(groundtruth_kspace, groundtruth_image, index, mode, mc_kspace, Mask):

	if mode == 0:
		index = index + 40
		croped_name = str(index)
		kspace_groundtruth = os.path.join(groundtruth_kspace, croped_name + '.kspace.npy')
		kspace_groundtruth = np.load(kspace_groundtruth)
		img_groundtruth = os.path.join(groundtruth_image, croped_name + '.image.npy')
		img_groundtruth = np.load(img_groundtruth)
		kspace_mc = os.path.join(mc_kspace, croped_name + '.kspace.npy')
		kspace_mc = np.load(kspace_mc)
		mask = os.path.join(Mask, 'vd_8x_Mask.npy')
		mask = np.load(mask)

	if mode == 1:
		index = index + 0
		croped_name = str(index)
		kspace_groundtruth = os.path.join(groundtruth_kspace, croped_name + '.kspace.npy')
		kspace_groundtruth = np.load(kspace_groundtruth)
		img_groundtruth = os.path.join(groundtruth_image, croped_name + '.image.npy')
		img_groundtruth = np.load(img_groundtruth)

		kspace_mc = os.path.join(mc_kspace, croped_name + '.kspace.npy')
		kspace_mc = np.load(kspace_mc)
		mask = os.path.join(Mask, 'vd_8x_Mask.npy')
		mask = np.load(mask)

	return [kspace_groundtruth, img_groundtruth, kspace_mc, mask]
	


	



