import os
import numpy as np
groundtruth_kspace = '/hpc/data/home/bme/v-liuyx1/fast_reconstruction_of_multi_contrast_MRI/get_vd_mask/New_Dataset/groundtruth_kspace/'
groundtruth_image = '/hpc/data/home/bme/v-liuyx1/fast_reconstruction_of_multi_contrast_MRI/get_vd_mask/New_Dataset/groundtruth_image/'


def load_dataset4():
    for croped_name in range(720):

        kspace_groundtruth = os.path.join(groundtruth_kspace, str(croped_name//40+1) + '_' + str(1) + '_' + str(int(croped_name%40)) + '.npy')
        kspace_groundtruth = np.load(kspace_groundtruth)
        img_groundtruth = os.path.join(groundtruth_image, str(croped_name//40+1) + '_' + str(1) + '_' + str(int(croped_name%40)) + '.npy')
        img_groundtruth = np.load(img_groundtruth)

        for i in range(11):
            T = os.path.join(groundtruth_kspace, str(croped_name//40+1) + '_' + str(i + 2) + '_' + str(int(croped_name%40)) + '.npy')
            T = np.load(T)
            kspace_groundtruth = np.concatenate([kspace_groundtruth, T], axis=0)
            Z = os.path.join(groundtruth_image, str(croped_name//40+1) + '_' + str(i + 2) + '_' + str(int(croped_name%40)) + '.npy')
            Z = np.load(Z)
            img_groundtruth = np.concatenate([img_groundtruth, Z], axis=0)
        print(kspace_groundtruth.shape)
        print(img_groundtruth.shape)

        np.save(groundtruth_kspace + str(croped_name + 1) + '.kspace.npy', kspace_groundtruth)
        np.save(groundtruth_image + str(croped_name + 1) + '.image.npy', img_groundtruth)


if __name__ =="__main__":
    # load_dataset1()
    # # load_dataset2()
    # load_dataset3()
    load_dataset4()


