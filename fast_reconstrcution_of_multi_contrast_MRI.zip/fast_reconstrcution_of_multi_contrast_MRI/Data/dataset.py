import numpy as np
import torch
from torch.utils.data import Dataset
from Data.predata_Data import load_dataset
from Data.Load_parameter_dicom import load_parameter_dicom
from Mask_Pattern.common_masks import *


class MRIDataset(Dataset):
    """loading MRI data"""

    def __init__(self, args, t_num, mode):
        self.args = args
        self.t_num = t_num
        self.mode = mode
        self.groundtruth_image = args.groundtruth_image
        self.groundtruth_kspace = args.groundtruth_kspace
        self.mc_kspace = args.mc_kspace
        self.Mask = args.MASK
        self.PDW_parameter_path = args.PDW_parameter_path
        self.T1W_parameter_path = args.T1W_parameter_path
        self.T2S_parameter_path = args.T2S_parameter_path
        self.PDM_parameter_path = args.PDM_parameter_path
        self.T1M_parameter_path = args.T1M_parameter_path

        # random noise:
        self.noise_val = args.noise_val

    def __len__(self):
        return self.t_num

    def crop_toshape(self, kspace_cplx):
        if kspace_cplx.shape[1] == self.img_size:
            return kspace_cplx
        if kspace_cplx.shape[1] % 2 == 1:
            kspace_cplx = kspace_cplx[:, :-1, :-1]
        crop = int((kspace_cplx.shape[1] - self.img_size)/2)
        kspace_cplx = kspace_cplx[:, crop:-crop, crop:-crop]
        return kspace_cplx

    def Para_crop_toshape(self, kspace_cplx):
        if kspace_cplx.shape[1] == self.img_size:
            return kspace_cplx
        if kspace_cplx.shape[1] % 2 == 1:
            kspace_cplx = kspace_cplx[:, :-1, :-1]
        crop = int((kspace_cplx.shape[1] - self.img_size) / 2)
        kspace_cplx = kspace_cplx[:, crop:-crop, crop:-crop]
        return kspace_cplx

    # @classmethod
    def slice_preprocess(self, kspace_cplx):

        kspace = self.crop_toshape(kspace_cplx)
        spower = np.sum(kspace ** 2) / kspace.size
        npower = self.noise_val[0] / (1 - self.noise_val[0]) * spower
        noise = np.random.normal(0, self.noise_val[1] ** 0.5, kspace.shape) * np.sqrt(npower)

        return kspace + noise

    def __getitem__(self, index):
        index = index + 1
        [target_Kspace, target_img, kspace_mc, Mask] = load_dataset(self.groundtruth_kspace, self.groundtruth_image, index, self.mode, self.mc_kspace, self.Mask)

        [PDW, T2S, T1W, PDM, T1M] = load_parameter_dicom(self.PDW_parameter_path, self.T1W_parameter_path, self.T2S_parameter_path, self.PDM_parameter_path, self.T1M_parameter_path, self.mode, index)

        return {'target_Kspace': torch.from_numpy(target_Kspace), 'target_img': torch.from_numpy(target_img), 'PDW': torch.from_numpy(PDW), 'T2S': torch.from_numpy(T2S),
                'T1W': torch.from_numpy(T1W), 'PDM': torch.from_numpy(PDM), 'T1M': torch.from_numpy(T1M), 'kspace_mc': torch.from_numpy(kspace_mc), 'Mask': torch.from_numpy(Mask)}

