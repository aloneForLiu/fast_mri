import h5py
import numpy as np
import nibabel as nib
from Mask_Pattern.common_masks import *
import cv2 as cv
import SimpleITK as sitk
import math
mat_path = r'D:/download/data/Lzf.mat'
save_path = r'D:/download/data/UID_Lzf/'

eps = 1e-8

groundtruth_kspace = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/groundtruth_kspace/'
groundtruth_image = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/groundtruth_image/'
mc_kspace = r'D:/download/fast reconstruction of multi-contrast MRI/get_vd_mask/5/mc_kspace/'

def isfloat(str):
    try:
        float(str)
        return True
    except ValueError:
        return False
def Get_Mat():
    mat_data = h5py.File(mat_path, 'r')
    np.seterr(divide='ignore', invalid='ignore')

    raw_affine = [[1, 0, 0, -98.24],
                  [0, 1, 0, -112.9],
                  [0, 0, 2, -80.7],
                  [0, 0, 0, 1]]
    raw_kspace_real = np.zeros([17, 370, 7, 70, 200], dtype=np.float32)
    raw_kspace_imag = np.zeros([17, 370, 7, 70, 200], dtype=np.float32)
    kspace = np.zeros([17, 450, 7, 70, 200], dtype=np.complex64)
    kspace_change = np.zeros([17, 224, 7, 70, 192], dtype=np.complex64)
    image = np.zeros([17, 192, 7, 224, 70], dtype=np.complex64)
    mck_s = np.zeros([2, 17, 192, 7, 224, 70], dtype=np.float32)
    img_if = np.zeros([2, 192, 224], dtype=np.float32)
    img_kf = np.zeros([2, 192, 224], dtype=np.float32)

    x = list(mat_data.keys())
    print(mat_data)
    print(x[0])
    print(x)
    raw_data = mat_data[x[0]]
    print(raw_data)
    print(raw_data.shape)
    raw_data = np.squeeze(raw_data)
    print(raw_data.shape)
    raw_data = raw_data[:, :, 0, 0, :, :, :]
    print(isfloat(raw_data[1, 1, 1, 1, 1][0]))

    for i in range(raw_kspace_real.shape[0]):
        for j in range(raw_kspace_real.shape[1]):
            for o in range(raw_kspace_real.shape[3]):
                for k in range(raw_kspace_real.shape[4]):
                    raw_kspace_real[i, j, 0, o, k] = raw_data[i, j, 0, o, k][0]
                    raw_kspace_imag[i, j, 0, o, k] = raw_data[i, j, 0, o, k][1]

    for i in range(raw_kspace_real.shape[0]):
        for o in range(raw_kspace_real.shape[3]):
            kspace[i, :, 0, o, :] = cv.copyMakeBorder(raw_kspace_real[i, :, 0, o, :], bottom=40, top=40, left=0,
                                                      right=0, borderType=cv.BORDER_CONSTANT, value=0) + \
                                    1j * cv.copyMakeBorder(raw_kspace_imag[i, :, 0, o, :], bottom=40, top=40, left=0,
                                                           right=0, borderType=cv.BORDER_CONSTANT, value=0)

        kspace[i, :, 0, :, :] = np.fft.fftshift(np.fft.ifftn(kspace[i, :, 0, :, :]))
        kspace_change[i, :, 0, :, :] = kspace[i, 113:337, 0, :, 4:196]
        image[i, :, 0, :, :] = np.transpose(kspace_change[i, :, 0, :, :], axes=(2, 0, 1))
        image[i, :, 0, :, :] = np.flip(image[i, :, 0, :, :])
        for o in range(image.shape[4]):
            image[i, :, 0, :, o] = np.fft.fft2(image[i, :, 0, :, o])
            image[i, :, 0, :, o] = (image[i, :, 0, :, o]) / 800
            mck_s[0, i, :, 0, :, o] = image[i, :, 0, :, o].real
            mck_s[1, i, :, 0, :, o] = image[i, :, 0, :, o].imag
            image[i, :, 0, :, o] = np.fft.ifft2(image[i, :, 0, :, o])
    for o in range(15, 55):
        np.save(mc_kspace + str(16) + '_' + str(1) + '_' + str(o-15) + '.npy', mck_s[:, :, :, 0, :, o])

    for i in range(15, 55):
        img_sos_all = np.float32(np.sqrt(np.sum(np.square(np.abs(image[:, :, 0, :, i])), axis=0)))  # 线圈关键步骤
        # img_sos_all = (img_sos_all - np.min(img_sos_all)) / (np.max(img_sos_all) - np.min(img_sos_all))

        '''Save nibImage'''
        img_sosI = nib.Nifti1Image(img_sos_all, raw_affine)
        # nib.save(img_sosI, path + str(p) + '_' + str(i) + '_' + 'Under_sampled.nii.gz')
        nib.save(img_sosI, save_path + str(1) + '_' + str(i) + '.nii.gz')

        img_sos_allksp = np.fft.fft2(img_sos_all)  # 变为k空间
        s = np.zeros([192, 224], dtype=np.complex64)  # 指定数据类型为复数
        s.real = np.array(img_sos_allksp.real)
        s.imag = np.array(img_sos_allksp.imag)

        img_back = np.fft.ifft2(s)
        im = np.zeros([192, 224], dtype=np.complex64)
        im.real = img_back.real
        im.imag = img_back.imag

        # 出来的是复数，取绝对值，转化成实数
        # img_back = np.abs(im)

        '''Save numpy'''
        img_kf[0, :, :] = s.real
        img_kf[1, :, :] = s.imag

        img_if[0, :, :] = im.real
        img_if[1, :, :] = im.imag

        np.save(groundtruth_kspace + str(16) + '_' + str(1) + '_' + str(i - 15) + '.npy', img_kf)
        np.save(groundtruth_image + str(16) + '_' + str(1) + '_' + str(i - 15) + '.npy', img_if)


def Get_Mat2():
    mat_data = h5py.File(mat_path, 'r')
    np.seterr(divide='ignore', invalid='ignore')

    raw_affine = [[1, 0, 0, -98.24],
                  [0, 1, 0, -112.9],
                  [0, 0, 2, -80.7],
                  [0, 0, 0, 1]]
    raw_kspace_real = np.zeros([17, 370, 7, 70, 200], dtype=np.float32)
    raw_kspace_imag = np.zeros([17, 370, 7, 70, 200], dtype=np.float32)
    kspace = np.zeros([17, 450, 7, 70, 200], dtype=np.complex64)
    kspace_change = np.zeros([17, 224, 7, 70, 192], dtype=np.complex64)
    image = np.zeros([17, 192, 7, 224, 70], dtype=np.complex64)
    mck_s = np.zeros([2, 17, 192, 7, 224, 70], dtype=np.float32)

    img_if = np.zeros([2, 192, 224], dtype=np.float32)
    img_kf = np.zeros([2, 192, 224], dtype=np.float32)

    x = list(mat_data.keys())
    print(mat_data)
    print(x[0])
    print(x)
    raw_data = mat_data[x[0]]
    print(raw_data)
    print(raw_data.shape)
    raw_data = np.squeeze(raw_data)
    print(raw_data.shape)
    raw_data = raw_data[:, :, 0, 1, :, :, :]
    print(isfloat(raw_data[1, 1, 1, 1, 1][0]))

    for n in range(raw_kspace_real.shape[2]):
        for i in range(raw_kspace_real.shape[0]):
            for j in range(raw_kspace_real.shape[1]):
                for o in range(raw_kspace_real.shape[3]):
                    for k in range(raw_kspace_real.shape[4]):
                        raw_kspace_real[i, j, n, o, k] = raw_data[i, j, n, o, k][0]
                        raw_kspace_imag[i, j, n, o, k] = raw_data[i, j, n, o, k][1]

        for i in range(raw_kspace_real.shape[0]):
            for o in range(raw_kspace_real.shape[3]):
                kspace[i, :, n, o, :] = cv.copyMakeBorder(raw_kspace_real[i, :, n, o, :], bottom=40, top=40, left=0,
                                                          right=0, borderType=cv.BORDER_CONSTANT, value=0) + \
                                        1j * cv.copyMakeBorder(raw_kspace_imag[i, :, n, o, :], bottom=40, top=40,
                                                               left=0,
                                                               right=0, borderType=cv.BORDER_CONSTANT, value=0)

            kspace[i, :, n, :, :] = np.fft.fftshift(np.fft.ifftn(kspace[i, :, n, :, :]))
            kspace_change[i, :, n, :, :] = kspace[i, 113:337, n, :, 4:196]
            image[i, :, n, :, :] = np.transpose(kspace_change[i, :, n, :, :], axes=(2, 0, 1))
            image[i, :, n, :, :] = np.flip(image[i, :, n, :, :])
            for o in range(image.shape[4]):
                image[i, :, n, :, o] = np.fft.fft2(image[i, :, n, :, o])
                image[i, :, n, :, o] = (image[i, :, n, :, o]) / 800
                mck_s[0, i, :, n, :, o] = image[i, :, n, :, o].real
                mck_s[1, i, :, n, :, o] = image[i, :, n, :, o].imag
                image[i, :, n, :, o] = np.fft.ifft2(image[i, :, n, :, o])
        for o in range(15, 55):
            np.save(mc_kspace + str(16) + '_' + str(2+n) + '_' + str(o - 15) + '.npy', mck_s[:, :, :, n, :, o])

        for i in range(15, 55):
            img_sos_all = np.float32(np.sqrt(np.sum(np.square(np.abs(image[:, :, n, :, i])), axis=0)))  # 线圈关键步骤
            # img_sos_all = (img_sos_all - np.min(img_sos_all)) / (np.max(img_sos_all) - np.min(img_sos_all))

            '''Save nibImage'''
            img_sosI = nib.Nifti1Image(img_sos_all, raw_affine)
            # nib.save(img_sosI, path + str(p) + '_' + str(i) + '_' + 'Under_sampled.nii.gz')
            nib.save(img_sosI, save_path + str(2 + n) + '_' + str(i) + '.nii.gz')

            img_sos_allksp = np.fft.fft2(img_sos_all)  # 变为k空间
            s = np.zeros([192, 224], dtype=np.complex64)  # 指定数据类型为复数
            s.real = np.array(img_sos_allksp.real)
            s.imag = np.array(img_sos_allksp.imag)

            img_back = np.fft.ifft2(s)
            im = np.zeros([192, 224], dtype=np.complex64)
            im.real = img_back.real
            im.imag = img_back.imag

            # 出来的是复数，取绝对值，转化成实数
            # img_back = np.abs(im)

            '''Save numpy'''
            img_kf[0, :, :] = s.real
            img_kf[1, :, :] = s.imag

            img_if[0, :, :] = im.real
            img_if[1, :, :] = im.imag

            np.save(groundtruth_kspace + str(16) + '_' + str(2 + n) + '_' + str(i - 15) + '.npy', img_kf)
            np.save(groundtruth_image + str(16) + '_' + str(2 + n) + '_' + str(i - 15) + '.npy', img_if)


if __name__ == "__main__":

    Get_Mat()
    Get_Mat2()