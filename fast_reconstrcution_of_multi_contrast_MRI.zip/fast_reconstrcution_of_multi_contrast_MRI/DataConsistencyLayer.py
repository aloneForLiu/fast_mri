import torch
import torch.fft
import torch.nn as nn


class Aclass(nn.Module):
    def __init__(self, device):
        super(Aclass, self).__init__()
        self.device = device
        self.lambd = nn.Parameter(torch.tensor(0.3), requires_grad=True)

    def myAtA(self, img, Mask, SensitivityMap, option):

        img = img.view(SensitivityMap.size()[0], 1, SensitivityMap.size()[2], SensitivityMap.size()[3])
        coil_image1 = img * SensitivityMap
        coil_image1 = coil_image1.view(-1, SensitivityMap.size()[2], SensitivityMap.size()[3])
        coil_kspace1 = torch.fft.fft2(coil_image1[0::1, :, :])
        coil_kspace1 = coil_kspace1.view(SensitivityMap.size()[0], SensitivityMap.size()[1], SensitivityMap.size()[2], SensitivityMap.size()[3])
        if option == 1:
            real = coil_kspace1.real * Mask
            imag = coil_kspace1.imag * Mask
        if option == 0:
            real = coil_kspace1.real * Mask
            imag = coil_kspace1.imag * Mask
        DC_kspace1 = real + 1j * imag
        DC_kspace1 = DC_kspace1.view(-1, SensitivityMap.size()[2], SensitivityMap.size()[3])
        DC_image1 = torch.fft.ifft2(DC_kspace1[0::1, :, :]).to(dtype=torch.complex64)
        DC_image1 = DC_image1.view(SensitivityMap.size()[0], SensitivityMap.size()[1], SensitivityMap.size()[2], SensitivityMap.size()[3])
        coilComb = torch.sum(DC_image1 * SensitivityMap.conj(), dim=1)
        coilComb = coilComb.view(SensitivityMap.size()[0], 1, SensitivityMap.size()[2], SensitivityMap.size()[3])
        coilComb = coilComb + self.lambd * img
        coilComb = coilComb.view(SensitivityMap.size()[0], SensitivityMap.size()[2], SensitivityMap.size()[3])

        return coilComb

    def body(self, p, Mask, SensitivityMap, x, r, rTr, option):
        Ap = self.myAtA(p, Mask, SensitivityMap, option)
        alpha = rTr / (torch.sum(torch.conj(p[0::1, :, :]) * Ap[0::1, :, :], dim=(1, 2))).real
        alpha = alpha.view(alpha.size()[0], 1, 1)
        x = x + alpha * p
        r = r - alpha * Ap
        rTrNew = (torch.sum(torch.conj(r[0::1, :, :]) * r[0::1, :, :], dim=(1, 2))).real
        beta = rTrNew / rTr
        beta = beta.view(alpha.size()[0], 1, 1)
        p = r + beta * p

        return x, r, p, rTrNew

    def forward(self, img,  Mask, SensitivityMap, option):
        x = torch.zeros_like(img)
        i = 0
        r = img
        p = img
        rTr = torch.sum(torch.conj(r[0::1, :, :]) * r[0::1, :, :], dim=(1, 2)).real
        while i < 10 and torch.mean(rTr) > 1e-10:
            x, r, p, rTr = self.body(p, Mask, SensitivityMap, x, r, rTr, option)
            i = i + 1
        x = x.cuda()
        return x


def DataConsistencyLayermethod_kspace(rec_Kspace, device):

    img = torch.zeros((rec_Kspace.size()), dtype=torch.float32)
    all_ksp = torch.fft.ifft2(rec_Kspace[0, 0, 0::1, :, :] + 1j * rec_Kspace[0, 1, 0::1, :, :])
    img[0, 0, 0::1, :, :] = all_ksp.real
    img[0, 1, 0::1, :, :] = all_ksp.imag

    img = img.cuda()

    return img


def DataConsistencyLayermethod_image(predicted_img, device, Mask, SensitivityMap, Input_I, option):

    A = Aclass(device)
    kspace = torch.zeros((predicted_img.size()), dtype=torch.float32)
    all_ksp = torch.zeros((12, 224, 256)).to(dtype=torch.complex64).cuda()
    all_ksp[0::1, :, :] = predicted_img[0, 0, 0::1, :, :] + 1j * predicted_img[0, 1, 0::1, :, :]
    rhs = Input_I + A.lambd * all_ksp

    image = A(rhs, Mask, SensitivityMap, option)
    image = torch.abs((image))

    Input_K1 = torch.fft.fft2(image[0::1, :, :])

    kspace[0, 0, :, :, :] = Input_K1.real
    kspace[0, 1, :, :, :] = Input_K1.imag

    kspace = kspace.cuda()

    return kspace


# def inverse_module(PDMap, T1Map, T2SMap, fz, xw):
#     angle1 = 4
#     angle2 = 16
#     TR1 = TR2 = 35
#     x = torch.zeros_like(fz, dtype=torch.complex64)
#     TE = [3.02, 3.02, 7, 9.66, 13.64, 16.3, 20.28, 22.94]
#     E1 = torch.exp(-TR1 / T1Map)
#     E2 = E1
#     for i in range(8):
#         x[:, i, :, :] = PDMap * torch.sin(angle1) * ((1 - E2) + ((1 - E1) * E2 * torch.cos(angle1))) / (1 - E1 * E2 * torch.cos(angle1) * torch.cos(angle1)) * torch.exp(-TE[i] / T2SMap)\
#              * torch.exp(-1j * (fz[:, i, :, :] * TE[0] + xw[:, i, :, :]))
#
#     for i in range(8):
#         x[:, i+8, :, :] = PDMap * torch.sin(angle2) * ((1 - E2) + ((1 - E1) * E2 * torch.cos(angle2))) / (1 - E1 * E2 * torch.cos(angle2) * torch.cos(angle2)) * torch.exp(-TE[i] / T2SMap)\
#              * torch.exp(-1j * (fz[:, i+8, :, :] * TE[0] + xw[:, i+8, :, :]))
#
#     return torch.abs(x)
