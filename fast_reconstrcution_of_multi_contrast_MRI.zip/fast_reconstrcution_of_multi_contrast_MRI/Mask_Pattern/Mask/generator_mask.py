from fastmri.data.subsample import RandomMaskFunc, EquiSpacedMaskFunc, MaskFunc
from fastmri.data import transforms as T
import numpy as np
import torch as torch
import matplotlib
import matplotlib.pyplot as plt


def EquiSpacedMask():
    mask_func = EquiSpacedMaskFunc(center_fractions=[0.04], accelerations=[8])
    return mask_func


def generator_EquiSpaced():

    mask_func = EquiSpacedMask()
    kspace_mc = np.ones([1, 224, 256])
    kspace_mc = torch.from_numpy(kspace_mc)

    masked_kspace, last_tensor_mask, _ = T.apply_mask(kspace_mc, mask_func)
    masked_kspace = masked_kspace.squeeze(0)
    np.save('/hpc/data/home/bme/v-liuyx1/fast_reconstruction_of_multi_contrast_MRI/Mask_Pattern/Mask/' + 'Mask.npy', masked_kspace)


def generator_EquiSpaced2():

    mask_func = EquiSpacedMask()
    kspace_mc = np.ones([1, 224, 256])
    kspace_mc = torch.from_numpy(kspace_mc)

    masked_kspace, last_tensor_mask, _ = T.apply_mask(kspace_mc, mask_func)
    masked_kspace = masked_kspace.squeeze(0)

    masked_kspace = masked_kspace.numpy()
    num_cols = masked_kspace.shape[-2]
    print(num_cols)
    plt.imshow(masked_kspace.transpose(1, 0), cmap='gray')
    plt.show()
    print(np.sum(masked_kspace) / (224 * 256))


if __name__ =="__main__":
    generator_EquiSpaced()
    generator_EquiSpaced2()