import torch
import torch.nn as nn
import random
import numpy as np
from Image.ImageNet import SensitivityNet


def define_parameter():
    num_params = 5
    # 生成16个随机数
    params = [random.random() for _ in range(num_params)]
    
    # 计算随机数之和
    sum_params = sum(params)
    
    # 归一化
    normalized_params = [param/sum_params for param in params]
    
    # 将归一化后的参数转换为Tensor
    tensor_params = torch.tensor(normalized_params, requires_grad=True)
    
    tensor_params = torch.softmax(tensor_params, dim=0)
    
    return tensor_params
    
def y_value(a, x, k):
        return 1 / (1 + k * torch.exp(-a * x))
        
        
def add_sampling_point(Nx, Ny, rate, mask):   
    mid_x = int(Nx / 2)
    interval_x = int(np.around(Nx / np.sqrt(rate) / 2))
    mid_y = int(Ny / 2)
    interval_y = int(np.around(Ny / np.sqrt(rate) / 2))
    mask[:, :, mid_x - interval_x: mid_x + interval_x, mid_y - interval_y:mid_y + interval_y] = 1
    
    return mask
        
class Memc_LOUPE(nn.Module):
    def __init__(self, input_shape, slope, sample_slope, device, sparsity, noise_val):
        super(Memc_LOUPE, self).__init__()
        self.input_shape = input_shape
        self.slope = slope
        self.device = device
        self.sparsity = sparsity

        self.param1 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param2 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param3 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param4 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param5 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param6 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param7 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param8 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param9 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param10 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param11 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        self.param12 = torch.nn.Parameter((-torch.log(1. / torch.rand(self.input_shape, dtype=torch.float32) - 1.) / self.slope), requires_grad=True)
        
        self.sample_slope = sample_slope
        
        self.noise_val = noise_val
        self.SensitivityMapNet = SensitivityNet(n_channels=128, n_classes=128, scale_factor=1)
        
    def calculate_Mask(self, kspace_mc, option):
        params = [self.param1, self.param2, self.param3, self.param4, self.param5, self.param6, self.param7, self.param8, self.param9, self.param10, self.param11, self.param12]
        temsor_params = torch.zeros_like(kspace_mc).to(device=self.device, dtype=torch.float32)
        threshs = torch.zeros_like(kspace_mc).to(device=self.device, dtype=torch.float32)
        for i in range(kspace_mc.size()[1]):
            temsor_params[:, i, :, :, :] = params[i]
            thresh = torch.rand([1, 224, 256], dtype=torch.float32).to(device=self.device)
            threshs[:, i, :, :, :] = thresh
        
        last_tensor_mask = torch.zeros_like(kspace_mc).to(device=self.device, dtype=torch.float32)
        mask_tensor = torch.zeros_like(kspace_mc).to(device=self.device, dtype=torch.float32)
        thresh_tensor = torch.zeros_like(kspace_mc).to(device=self.device, dtype=torch.float32)
        prob_mask_tensor = torch.zeros_like(kspace_mc).to(device=self.device, dtype=torch.float32)
        mask_tensor = torch.zeros_like(kspace_mc).to(device=self.device, dtype=torch.float32)

        xbar_number = []
        for i in range(kspace_mc.size()[1]):
            logit_weights = 0 * kspace_mc[:, i, :, :, :] + temsor_params[:, i, :, :, :]
            #mask_add_sampling_point = add_sampling_point(logit_weights.size()[2], logit_weights.size()[3], (kspace_mc.size()[1]), logit_weights)
            #mask_add_sampling_point[mask_add_sampling_point > 1] = 1
            logit_weights = y_value(self.slope, logit_weights, 1)
            
            prob_mask_tensor[:, i, :, :, :] = logit_weights
            #prob_mask_tensor[:, i, :, :, :] = torch.sigmoid(self.slope * logit_weights)
            xbar = torch.mean(prob_mask_tensor[:, i, :, :, :])
            xbar = xbar.view(1)
            xbar_number.append(xbar)
           
        prob_m_tensor_angle1 = 0
        prob_m_tensor_angle2 = 0
        xbar1 = 0
        xbar2 = 0
        #tensor_xbar_number = torch.tensor(xbar_number)
        #tensor_params = torch.softmax(tensor_xbar_number, dim=0)
        prob_mask = torch.zeros_like(kspace_mc).to(device=self.device, dtype=torch.float32)
        
        for i in range(1, 6):
            prob_m_tensor_angle1 = prob_mask_tensor[:, i, :, :, :] + prob_m_tensor_angle1
            xbar1 = xbar_number[i] + xbar1
        for i in range(7, 12):
            prob_m_tensor_angle2 = prob_mask_tensor[:, i, :, :, :] + prob_m_tensor_angle2
            xbar2 = xbar_number[i] + xbar2
        
        r1 = self.sparsity / (xbar_number[0])
        beta1 = (1 - self.sparsity) / (1 - (xbar_number[0]))
        le1 = (torch.less_equal(r1, 1)).to(dtype=torch.float32)
        mask_tensor[:, 0, :, :, :] = (le1 * prob_mask_tensor[:, 0, :, :, :]) * r1 + (1 - le1) * (1 - (1 - (prob_mask_tensor[:, 0, :, :, :])) * beta1)
        
        r2 = self.sparsity / (xbar_number[6])
        beta2 = (1 - self.sparsity) / (1 - (xbar_number[6]))
        le2 = (torch.less_equal(r2, 1)).to(dtype=torch.float32)
        mask_tensor[:, 6, :, :, :] = (le2 * prob_mask_tensor[:, 6, :, :, :]) * r2 + (1 - le2) * (1 - (1 - (prob_mask_tensor[:, 6, :, :, :])) * beta2)
            
        for i in range(1, 6):
            
            prob_mask[:, i, :, :, :] = prob_m_tensor_angle1 * (1/5)
            sparsity = self.sparsity 
        
            r = sparsity / (xbar1 * (1/5))
            beta = (1 - sparsity) / (1 - (xbar1 * (1/5)))
            le = (torch.less_equal(r, 1)).to(dtype=torch.float32)
            mask_tensor[:, i, :, :, :] = (le * prob_mask[:, i, :, :, :]) * r + (1 - le) * (1 - (1 - (prob_mask[:, i, :, :, :])) * beta)
            
            
        for i in range(7, 12):
            prob_mask[:, i, :, :, :] = prob_m_tensor_angle2 * (1/5)
            sparsity = self.sparsity
        
            r = sparsity / (xbar2 * (1/5))
            beta = (1 - sparsity) / (1 - (xbar2 * (1/5)))
            le = (torch.less_equal(r, 1)).to(dtype=torch.float32)
            mask_tensor[:, i, :, :, :] = (le * prob_mask[:, i, :, :, :]) * r + (1 - le) * (1 - (1 - (prob_mask[:, i, :, :, :])) * beta)
            
        thresh_tensor = 0 * mask_tensor + threshs

        if option:
            #last_tensor_mask = y_value(self.sample_slope, (mask_tensor - thresh_tensor), kspace_mc.size()[1])
            for i in range(kspace_mc.size()[1]):
                last_tensor_mask[:, i, :, :, :] = y_value(self.sample_slope, (mask_tensor[:, i, :, :, :] - thresh_tensor[:, i, :, :, :]), 1)
                #last_tensor_mask[:, i, :, :, :] = torch.sigmoid(self.sample_slope * (mask_tensor[:, i, :, :, :] - thresh_tensor[:, i, :, :, :]))

        else:
            for i in range(kspace_mc.size()[1]):
                last_tensor_mask[:, i, :, :, :] = ((mask_tensor[:, i, :, :, :]) > (thresh_tensor[:, i, :, :, :])) + 0

        return last_tensor_mask.cuda()

    def get_noise(self, kspace):

        spower = torch.sum(kspace ** 2) / kspace.size
        npower = self.noise_val[0] / (1 - self.noise_val[0]) * spower
        noise = torch.randn(0, self.noise_val[1] ** 0.5, kspace.shape) * torch.sqrt(npower)

        return kspace + noise

    def forward(self, kspace_mc, option, Mask):

        Kspace = torch.zeros(1, 2, int(kspace_mc.size()[1] / 2), kspace_mc.size()[3], kspace_mc.size()[4]).to(dtype=torch.float32).cuda()

        # Get Mask
        last_tensor_mask = self.calculate_Mask(kspace_mc[:, 0::2, :, :, :], option=option)
        #last_tensor_mask = Mask

        # Get Coil Under_sampled K_space
        if option == 1:
            
            real = kspace_mc[:, 0::2, :, :, :] * last_tensor_mask
            imag = kspace_mc[:, 1::2, :, :, :] * last_tensor_mask
        if option == 0:
            real = kspace_mc[:, 0::2, :, :, :] * last_tensor_mask
            imag = kspace_mc[:, 1::2, :, :, :] * last_tensor_mask

        real = real.view(-1, kspace_mc.size()[3], kspace_mc.size()[4])
        imag = imag.view(-1, kspace_mc.size()[3], kspace_mc.size()[4])

        # Get Coil Under_sampled Image
        image_mc = torch.fft.ifft2(real[0::1, :, :] + 1j * imag[0::1, :, :]).to(dtype=torch.complex64)
        image_mc = image_mc.view(int(kspace_mc.size()[1] / 2), kspace_mc.size()[2], kspace_mc.size()[3], kspace_mc.size()[4])
        image_Net = torch.mean(image_mc, dim=0).view(1, kspace_mc.size()[2], kspace_mc.size()[3], kspace_mc.size()[4])
        imge_Net_realAndimag = torch.cat([image_Net.real, image_Net.imag], dim=1)

        # get coil image form U-Net
        image_Net_out = self.SensitivityMapNet(imge_Net_realAndimag)
        image_Net_out_real = image_Net_out[:, 0:64, :, :]
        image_Net_out_imag = image_Net_out[:, 64:128, :, :]
        image_Net_out_coil = image_Net_out_real + 1j * image_Net_out_imag

        combine_image_out = torch.sqrt(torch.sum(torch.square(torch.abs(image_Net_out_coil[0, :, :, :])), dim=0))

        # Sensitivity Map
        SensitivityMap = image_Net_out_coil / (combine_image_out.view(1, 1, kspace_mc.size()[3], kspace_mc.size()[4]))
        SensitivityMap = SensitivityMap.repeat(12, 1, 1, 1)

        # coil combine
        combine_image = torch.sum(image_mc[0::1, :, :, :] * SensitivityMap.conj(), dim=1)
        # combine_image = torch.sqrt(torch.sum(torch.square(torch.abs(image_mc[0::1, :, :, :])), dim=1))

        # Input K_space
        Input_K = torch.fft.fft2(combine_image[0::1, :, :])

        Kspace[0, 0, :, :, :] = Input_K.real
        Kspace[0, 1, :, :, :] = Input_K.imag

        # Input Image
        Input_I = torch.fft.ifft2(Kspace[0, 0, 0::1, :, :] + 1j * Kspace[0, 1, 0::1, :, :])

        return last_tensor_mask, Kspace, Input_I, SensitivityMap, image_mc
