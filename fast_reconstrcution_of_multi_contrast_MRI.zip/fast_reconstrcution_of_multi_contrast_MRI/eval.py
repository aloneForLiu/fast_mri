import torch
from tqdm.auto import tqdm
from math import log10
from PIL import Image
import cv2
import nibabel as nib
import os as os
import logging
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import os
from skimage.metrics import structural_similarity, peak_signal_noise_ratio
# matplotlib.use('TkAgg')

Mask_output_test = '/hpc/data/home/bme/v-liuyx1/The_latest/fast_reconstrcution_of_multi_contrast_MRI_Newdata/output/CG_Coil/J=1/change_sample/8x/'
Coil_output_test = '/hpc/data/home/bme/v-liuyx1/The_latest/fast_reconstrcution_of_multi_contrast_MRI_Newdata/output/CG_Coil/J=1/change_sample/8x/Coil/'
output_test = '/hpc/data/home/bme/v-liuyx1/The_latest/fast_reconstrcution_of_multi_contrast_MRI_Newdata/output/CG_Coil/J=1/change_sample/8x/'
Decrease_test = '/hpc/data/home/bme/v-liuyx1/The_latest/fast_reconstrcution_of_multi_contrast_MRI_Newdata/output/CG_Coil/J=1/change_sample/8x D/'
output_Para = '/hpc/data/home/bme/v-liuyx1/The_latest/fast_reconstrcution_of_multi_contrast_MRI_Newdata/output/CG_Coil/J=1/change_sample/8x P/'
Decrease_Para = '/hpc/data/home/bme/v-liuyx1/The_latest/fast_reconstrcution_of_multi_contrast_MRI_Newdata/output/CG_Coil/J=1/change_sample/8x PD/'
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'


def _error(actual: np.ndarray, predicted: np.ndarray):
    """ Simple error """
    return actual - predicted


def mse(actual: np.ndarray, predicted: np.ndarray):
    """ Mean Squared Error """
    return np.mean(np.square(_error(actual, predicted)))


def rmse(actual: np.ndarray, predicted: np.ndarray):
    """ Root Mean Squared Error """
    return np.sqrt(mse(actual, predicted))


def nrmse_matrix(actual: np.ndarray, predicted: np.ndarray):
    """ Normalized Root Mean Squared Error """
    return rmse(actual, predicted) / (actual.max() - actual.min())


def visulize_attention_ratio(img_path, attention_mask, ratio=0.5, cmap="jet", i=None):
    """
    img_path: 读取图片的位置
    attention_mask: 2-D 的numpy矩阵
    ratio:  放大或缩小图片的比例，可选
    cmap:   attention map的style，可选
    """
    # load the image
    print("load image from: ", img_path)
    # load the image
    src_us_file = os.path.join(img_path, str(i) + '_' + str(20) + 'Rec' + '.nii.gz')
    src_us_vol = nib.load(src_us_file)
    src_us_vol = src_us_vol.get_fdata()
    img = Image.fromarray(src_us_vol)
    img_h, img_w = img.size[0], img.size[1]

    # scale the image
    img_h, img_w = int(img_h * ratio), int(img_w * ratio)
    img = img.resize((img_h, img_w))

    # normalize the attention mask
    mask = cv2.resize(attention_mask, (img_h, img_w))
    normed_mask = mask / mask.max()
    normed_mask = ((normed_mask * img) * 255).astype('uint8')
    plt.imshow(np.flip(normed_mask).transpose(1, 0), alpha=0.5, interpolation='nearest', cmap=cmap)
    plt.colorbar()
    plt.show()


def eval_net(net_G, net_P, net_T2S, net_T, net_PDM, net_T1M, loader, criterion, args, epoch):
    net_G.eval()
    net_P.eval()
    net_T2S.eval()
    net_T.eval()
    net_PDM.eval()
    net_T1M.eval()
    device = args.device
    n_val = len(loader)  # number of batch
    tot_FullLoss = 0
    tot_ImL2 = 0
    tot_ImL1 = 0
    tot_psnr = 0
    tot_ssim = 0
    tot_nrmse = 0
    tot_T2S_loss = 0
    tot_PDM_loss = 0
    tot_T1M_loss = 0
    PDW_tot_psnr = 0
    T2S_tot_psnr = 0
    T1W_tot_psnr = 0
    PDM_tot_psnr = 0
    T1M_tot_psnr = 0
    tot_ssim_PDW = 0
    tot_ssim_T2S = 0
    tot_ssim_T1W = 0
    tot_ssim_PDM = 0
    tot_ssim_T1M = 0
    tot_nrmse_PDW = 0
    tot_nrmse_T2S = 0
    tot_nrmse_T1W = 0
    tot_nrmse_PDM = 0
    tot_nrmse_T1M = 0
    number = 0

    raw_affine = [[0.823, 0, 0, -97.34],
                  [0, 0.823, 0, -124.4],
                  [0, 0, 2, -51.66],
                  [0, 0, 0, 1]]
                  
    for batch in tqdm(loader):
        kspace_mc = batch['kspace_mc'].to(dtype=torch.float32).cuda()
        full_Kspace = batch['target_Kspace']
        full_img1 = batch['target_img']
        full_Kspace = full_Kspace.to(dtype=torch.float32).cuda()
        full_img = full_img1.to(dtype=torch.float32).cuda()
        Mask = batch['Mask'].to(device=args.device, dtype=torch.float32)
        PDW = batch['PDW'].to(dtype=torch.float32).cuda()
        T2S = batch['T2S'].to(dtype=torch.float32).cuda()
        T1W = batch['T1W'].to(dtype=torch.float32).cuda()
        PDM = batch['PDM'].to(dtype=torch.float32).cuda()
        T1M = batch['T1M'].to(dtype=torch.float32).cuda()

        PDW = PDW.view(-1, 1, PDW.size()[1], PDW.size()[2])
        T2S = T2S.view(-1, 1, T2S.size()[1], T2S.size()[2])
        T1W = T1W.view(-1, 1, T1W.size()[1], T1W.size()[2])
        PDM = PDM.view(-1, 1, PDM.size()[1], PDM.size()[2])
        T1M = T1M.view(-1, 1, T1M.size()[1], T1M.size()[2])

        with torch.no_grad():

            DC_Rec_img2, rec_Kspace2, last_tensor_mask, _, attn_S, attn_T, SensitivityMap_new4, SensitivityMap_new3, SensitivityMap_new2, SensitivityMap_new1, SensitivityMap = net_G(kspace_mc, Mask, epoch, option=0)
            print(torch.sum(last_tensor_mask) / (args.batch_size * 64 * 12 * 224 * 256))

            Output_PDW = net_P(DC_Rec_img2)
            Output_T1W = net_T(DC_Rec_img2)
            Output_T2S = net_T2S(DC_Rec_img2)
            Output_PDM = net_PDM(DC_Rec_img2)
            Output_T1M = net_T1M(DC_Rec_img2)

        FullLoss, ImL2, ImL1, K_spaceL2, _ = criterion.calc_gen_loss(DC_Rec_img2, rec_Kspace2, full_img, full_Kspace)

        T2S_loss, T2S_loss2 = criterion.calc_T2S_loss(Output_T2S, T2S)
        PDM_loss, PDM_loss2 = criterion.calc_PDM_loss(Output_PDM, PDM)
        T1M_loss, T1M_loss2 = criterion.calc_T1M_loss(Output_T1M, T1M)

        tot_FullLoss += FullLoss.item()

        tot_ImL2 += ImL2.item()
        tot_ImL1 += ImL1.item()

        tot_T2S_loss += T2S_loss.item()
        tot_PDM_loss += PDM_loss.item()
        tot_T1M_loss += T1M_loss.item()
        
        DC_Rec_img2 = DC_Rec_img2.squeeze()
        DC_Rec_img2 = DC_Rec_img2.cpu().detach().numpy()
        
        last_tensor_mask = last_tensor_mask.squeeze()
        last_tensor_mask = last_tensor_mask.cpu().detach().numpy()

        SensitivityMap_new4 = SensitivityMap_new4.squeeze()
        SensitivityMap_new4 = SensitivityMap_new4.cpu().detach().numpy()

        SensitivityMap_new3 = SensitivityMap_new3.squeeze()
        SensitivityMap_new3 = SensitivityMap_new3.cpu().detach().numpy()

        SensitivityMap_new2 = SensitivityMap_new2.squeeze()
        SensitivityMap_new2 = SensitivityMap_new2.cpu().detach().numpy()

        SensitivityMap_new1 = SensitivityMap_new1.squeeze()
        SensitivityMap_new1 = SensitivityMap_new1.cpu().detach().numpy()

        SensitivityMap = SensitivityMap.squeeze()
        SensitivityMap = SensitivityMap.cpu().detach().numpy()

        attn_S = attn_S.squeeze()
        attn_S = attn_S.cpu().detach().numpy()

        attn_T = attn_T.squeeze()
        attn_T = attn_T.cpu().detach().numpy()

        Output_PDW = Output_PDW.squeeze()
        Output_PDW = Output_PDW.cpu().detach().numpy()
        Output_PDW = np.abs(Output_PDW)
        Output_T2S = Output_T2S.squeeze()
        Output_T2S = Output_T2S.cpu().detach().numpy()
        Output_T2S = np.abs(Output_T2S)
        Output_T1W = Output_T1W.squeeze()
        Output_T1W = Output_T1W.cpu().detach().numpy()
        Output_T1W = np.abs(Output_T1W)
        Output_PDM = Output_PDM.squeeze()
        Output_PDM = Output_PDM.cpu().detach().numpy()
        Output_PDM = np.abs(Output_PDM)
        Output_T1M = Output_T1M.squeeze()
        Output_T1M = Output_T1M.cpu().detach().numpy()
        Output_T1M = np.abs(Output_T1M)

        PDW = PDW.squeeze()
        PDW = PDW.cpu().detach().numpy()
        T1W = T1W.squeeze()
        T1W = T1W.cpu().detach().numpy()
        T2S = T2S.squeeze()
        T2S = T2S.cpu().detach().numpy()
        PDM = PDM.squeeze()
        PDM = PDM.cpu().detach().numpy()
        T1M = T1M.squeeze()
        T1M = T1M.cpu().detach().numpy()

        full_img = full_img.squeeze()
        full_img = full_img.cpu().detach().numpy()
        
        for i in range(args.batch_size):

            psnr = peak_signal_noise_ratio(full_img[i, :, : ,:], DC_Rec_img2[i, :, : ,:], data_range=(np.max(full_img[i, :, : ,:]) - np.min(full_img[i, :, : ,:])))
            tot_psnr += psnr
            
            PDW_psnr = peak_signal_noise_ratio(PDW[i, : ,:], Output_PDW[i, : ,:], data_range=(np.max(PDW[i, : ,:]) - np.min(PDW[i, : ,:])))
            PDW_tot_psnr += PDW_psnr
            T2S_psnr = peak_signal_noise_ratio(T2S[i, : ,:], Output_T2S[i, : ,:], data_range=(np.max(T2S[i, : ,:]) - np.min(T2S[i, : ,:])))
            T2S_tot_psnr += T2S_psnr
            T1W_psnr = peak_signal_noise_ratio(T1W[i, : ,:], Output_T1W[i, : ,:], data_range=(np.max(T1W[i, : ,:]) - np.min(T1W[i, : ,:])))
            T1W_tot_psnr += T1W_psnr
            PDM_psnr = peak_signal_noise_ratio(PDM[i, : ,:], Output_PDM[i, : ,:], data_range=(np.max(PDM[i, : ,:]) - np.min(PDM[i, : ,:])))
            PDM_tot_psnr += PDM_psnr
            T1M_psnr = peak_signal_noise_ratio(T1M[i, : ,:], Output_T1M[i, : ,:], data_range=(np.max(T1M[i, : ,:]) - np.min(T1M[i, : ,:])))
            T1M_tot_psnr += T1M_psnr
        
        for i in range(args.batch_size):
            ssim = structural_similarity(full_img[i, :, : ,:], DC_Rec_img2[i, :, : ,:], multichannel=True)
            tot_ssim += ssim
    
            ssim_PDW = structural_similarity(PDW[i, : ,:], Output_PDW[i, : ,:])
            tot_ssim_PDW += ssim_PDW
            ssim_T2S = structural_similarity(T2S[i, : ,:], Output_T2S[i, : ,:])
            tot_ssim_T2S += ssim_T2S
            ssim_T1W = structural_similarity(T1W[i, : ,:], Output_T1W[i, : ,:])
            tot_ssim_T1W += ssim_T1W
            ssim_PDM = structural_similarity(PDM[i, : ,:], Output_PDM[i, : ,:])
            tot_ssim_PDM += ssim_PDM
            ssim_T1M = structural_similarity(T1M[i, : ,:], Output_T1M[i, : ,:])
            tot_ssim_T1M += ssim_T1M

        nrmse = nrmse_matrix(full_img, DC_Rec_img2)
        tot_nrmse += nrmse

        nrmse_PDW = nrmse_matrix(PDW, Output_PDW)
        tot_nrmse_PDW += nrmse_PDW
        nrmse_T2S = nrmse_matrix(T2S, Output_T2S)
        tot_nrmse_T2S += nrmse_T2S
        nrmse_T1W = nrmse_matrix(T1W, Output_T1W)
        tot_nrmse_T1W += nrmse_T1W
        nrmse_PDM = nrmse_matrix(PDM, Output_PDM)
        tot_nrmse_PDM += nrmse_PDM
        nrmse_T1M = nrmse_matrix(T1M, Output_T1M)
        tot_nrmse_T1M += nrmse_T1M

        aBS_rec = np.zeros([args.batch_size, int(DC_Rec_img2.shape[1] / 2), DC_Rec_img2.shape[2], DC_Rec_img2.shape[3]], dtype=np.float32)
        aBS_full = np.zeros([args.batch_size, int(full_img.shape[1] / 2), full_img.shape[2], full_img.shape[3]], dtype=np.float32)

        for i in range(int(DC_Rec_img2.shape[1] / 2)):
            aBS_rec[:, i, :, :] = np.abs(DC_Rec_img2[:, 2 * i, :, :] + 1j * DC_Rec_img2[:, 2 * i + 1, :, :])
            aBS_full[:, i, :, :] = np.abs(full_img[:, 2 * i, :, :] + 1j * full_img[:, 2 * i + 1, :, :])

        Decrease = aBS_full - aBS_rec
        
        for i in range(args.batch_size):
            Output_PDM[i, : ,:] = (Output_PDM[i, : ,:] - np.min(Output_PDM[i, : ,:])) / (np.max(Output_PDM[i, : ,:]) - np.min(Output_PDM[i, : ,:]))
            PDM[i, : ,:] = (PDM[i, : ,:] - np.min(PDM[i, : ,:])) / (np.max(PDM[i, : ,:]) - np.min(PDM[i, : ,:]))
            Output_T2S[i, : ,:] = (Output_T2S[i, : ,:] - np.min(Output_T2S[i, : ,:])) / (np.max(Output_T2S[i, : ,:]) - np.min(Output_T2S[i, : ,:]))
            T2S[i, : ,:] = (T2S[i, : ,:] - np.min(T2S[i, : ,:])) / (np.max(T2S[i, : ,:]) - np.min(T2S[i, : ,:]))
            Output_T1M[i, : ,:] = (Output_T1M[i, : ,:] - np.min(Output_T1M[i, : ,:])) / (np.max(Output_T1M[i, : ,:]) - np.min(Output_T1M[i, : ,:]))
            T1M[i, : ,:] = (T1M[i, : ,:] - np.min(T1M[i, : ,:])) / (np.max(T1M[i, : ,:]) - np.min(T1M[i, : ,:]))

        Decrease_PDW = PDW - Output_PDW
        Decrease_T2S = T2S - Output_T2S
        Decrease_T1W = T1W - Output_T1W
        Decrease_PDM = PDM - Output_PDM
        Decrease_T1M = T1M - Output_T1M

        if epoch >= 0:
            for i in range(args.batch_size):
                save_T1 = nib.Nifti1Image(np.abs(Output_PDW[i, : ,:]), raw_affine)
                save_T1.to_filename(os.path.join(output_Para, str(number) + 'PDW_Rec' + '.nii.gz'))
                Decrease_img = nib.Nifti1Image(Decrease_PDW[i, : ,:], raw_affine)
                Decrease_img.to_filename(os.path.join(Decrease_Para, str(number) + 'PDW_Dec' + '.nii.gz'))
    
                save_T1 = nib.Nifti1Image(np.abs(Output_T2S[i, : ,:]), raw_affine)
                save_T1.to_filename(os.path.join(output_Para, str(number) + 'T2S_Rec' + '.nii.gz'))
                Decrease_img = nib.Nifti1Image(Decrease_T2S[i, : ,:], raw_affine)
                Decrease_img.to_filename(os.path.join(Decrease_Para, str(number) + 'T2S_Dec' + '.nii.gz'))
    
                save_T1 = nib.Nifti1Image(np.abs(Output_T1W[i, : ,:]), raw_affine)
                save_T1.to_filename(os.path.join(output_Para, str(number) + 'T1W_Rec' + '.nii.gz'))
                Decrease_img = nib.Nifti1Image(Decrease_T1W[i, : ,:], raw_affine)
                Decrease_img.to_filename(os.path.join(Decrease_Para, str(number) + 'T1W_Dec' + '.nii.gz'))
    
                save_T1 = nib.Nifti1Image(np.abs(Output_PDM[i, : ,:]), raw_affine)
                save_T1.to_filename(os.path.join(output_Para, str(number) + 'PDM_Rec' + '.nii.gz'))
                Decrease_img = nib.Nifti1Image(Decrease_PDM[i, : ,:], raw_affine)
                Decrease_img.to_filename(os.path.join(Decrease_Para, str(number) + 'PDM_Dec' + '.nii.gz'))
    
                save_T1 = nib.Nifti1Image(np.abs(Output_T1M[i, : ,:]), raw_affine)
                save_T1.to_filename(os.path.join(output_Para, str(number) + 'T1M_Rec' + '.nii.gz'))
                Decrease_img = nib.Nifti1Image(Decrease_T1M[i, : ,:], raw_affine)
                Decrease_img.to_filename(os.path.join(Decrease_Para, str(number) + 'T1M_Dec' + '.nii.gz'))

                for idx in range(aBS_rec.shape[1]):
                    save_T1 = nib.Nifti1Image(aBS_rec[i, idx, :, :], raw_affine)
                    save_T1.to_filename(os.path.join(output_test, str(idx) + '_' + str(number) + 'Rec' + '.nii.gz'))
                    Decrease_img = nib.Nifti1Image(Decrease[i, idx, :, :], raw_affine)
                    Decrease_img.to_filename(os.path.join(Decrease_test, str(idx) + '_' + str(number) + 'Dec' + '.nii.gz'))
            
                number = number + 1
        
        for i in range(64):
            NSensitivityMap_new4 = nib.Nifti1Image(np.abs((np.flip(SensitivityMap_new4[0, i, :, :]))), raw_affine)
            NSensitivityMap_new4.to_filename(os.path.join(Coil_output_test, str(i) + 'SensitivityMap_new4' + '.nii.gz'))
            NSensitivityMap_new3 = nib.Nifti1Image(np.abs((np.flip(SensitivityMap_new3[0, i, :, :]))), raw_affine)
            NSensitivityMap_new3.to_filename(os.path.join(Coil_output_test, str(i) + 'SensitivityMap_new3' + '.nii.gz'))
            NSensitivityMap_new2 = nib.Nifti1Image(np.abs((np.flip(SensitivityMap_new2[0, i, :, :]))), raw_affine)
            NSensitivityMap_new2.to_filename(os.path.join(Coil_output_test, str(i) + 'SensitivityMap_new2' + '.nii.gz'))
            NSensitivityMap_new1 = nib.Nifti1Image(np.abs((np.flip(SensitivityMap_new1[0, i, :, :]))), raw_affine)
            NSensitivityMap_new1.to_filename(os.path.join(Coil_output_test, str(i) + 'SensitivityMap_new1' + '.nii.gz'))
            NSensitivityMap = nib.Nifti1Image(np.abs((np.flip(SensitivityMap[0, i, :, :]))), raw_affine)
            NSensitivityMap.to_filename(os.path.join(Coil_output_test, str(i) + 'SensitivityMap' + '.nii.gz'))


        # Create output dir
        try:
            os.mkdir(Mask_output_test + '_' + str(epoch) + '_' + 'testMask')
            logging.info('Created checkpoint directory')
        except OSError:
            pass
            
        for i in range(last_tensor_mask.shape[0]):
            for j in range(last_tensor_mask.shape[1]):
                if number == 20:
                    save_Mask = nib.Nifti1Image(last_tensor_mask[i, j, 0, :, :], np.diag([1, 1, 1, 1]))
                    save_Mask.to_filename(os.path.join(Mask_output_test + '_' + str(epoch) + '_' + 'testMask', str(i) + '_' + str(j) + '_' + str(number) + '_Mask.nii.gz'))


    net_G.train()
    net_P.train()
    net_T2S.train()
    net_T.train()
    net_PDM.train()
    net_T1M.train()

    return tot_FullLoss / n_val, tot_ImL2 / n_val, tot_ImL1 / n_val, \
           tot_psnr / (args.batch_size * n_val), tot_ssim / (args.batch_size * n_val), tot_nrmse / (args.batch_size * n_val), PDW_tot_psnr / (args.batch_size * n_val), \
           T2S_tot_psnr / (args.batch_size * n_val), T1W_tot_psnr / (args.batch_size * n_val), PDM_tot_psnr / (args.batch_size * n_val), T1M_tot_psnr / (args.batch_size * n_val), \
           tot_ssim_PDW / (args.batch_size * n_val), tot_ssim_T2S / (args.batch_size * n_val), tot_ssim_T1W / (args.batch_size * n_val), tot_ssim_PDM / (args.batch_size * n_val), tot_ssim_T1M / (args.batch_size * n_val), \
           tot_nrmse_PDW / n_val, tot_nrmse_T2S / n_val, tot_nrmse_T1W / n_val, tot_nrmse_PDM / n_val, tot_nrmse_T1M / n_val, \
           tot_T2S_loss / n_val,  tot_PDM_loss / n_val, tot_T1M_loss / n_val

